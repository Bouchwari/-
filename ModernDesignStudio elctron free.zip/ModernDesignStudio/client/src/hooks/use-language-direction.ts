import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

type Direction = "ltr" | "rtl";

export function useLanguageDirection() {
  const { i18n } = useTranslation();
  const [direction, setDirection] = useState<Direction>("ltr");

  useEffect(() => {
    const currentLanguage = i18n.language;
    const isRtl = currentLanguage === "ar";
    setDirection(isRtl ? "rtl" : "ltr");
    
    // Set direction attribute on html element
    document.documentElement.setAttribute("dir", isRtl ? "rtl" : "ltr");
    
    // Apply RTL-specific styles if needed
    if (isRtl) {
      document.body.classList.add("rtl");
    } else {
      document.body.classList.remove("rtl");
    }
  }, [i18n.language]);

  return { direction };
}