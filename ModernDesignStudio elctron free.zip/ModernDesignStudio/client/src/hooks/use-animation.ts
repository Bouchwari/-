import { useEffect, useState } from 'react';

export function useAnimation(options: {
  duration?: number;
  delay?: number;
  animation?: 'fadeIn' | 'slideInUp' | 'slideInRight' | 'slideInLeft' | 'scaleUp';
  stagger?: number;
  count?: number;
}) {
  const {
    duration = 500,
    delay = 0,
    animation = 'fadeIn',
    stagger = 100,
    count = 1
  } = options;
  
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, delay);
    
    return () => clearTimeout(timer);
  }, [delay]);
  
  const getAnimationClass = (index = 0) => {
    if (!isVisible) {
      return 'opacity-0';
    }
    
    const animationMap = {
      fadeIn: 'animate-fade-in',
      slideInUp: 'animate-slide-in-up',
      slideInRight: 'animate-slide-in-right',
      slideInLeft: 'animate-slide-in-left',
      scaleUp: 'animate-scale-up'
    };
    
    const baseClass = animationMap[animation];
    const delayClass = index > 0 ? `animation-delay-${index * stagger}ms` : '';
    
    return `${baseClass} ${delayClass}`;
  };
  
  const getItemProps = (index = 0) => {
    return {
      className: getAnimationClass(index),
      style: {
        animationDuration: `${duration}ms`,
        animationDelay: `${delay + (index * stagger)}ms`,
      }
    };
  };
  
  const getContainerProps = () => {
    return {
      className: isVisible ? '' : 'opacity-0',
    };
  };
  
  const animationItems = Array.from({ length: count }).map((_, i) => getItemProps(i));
  
  return {
    isVisible,
    getAnimationClass,
    getItemProps,
    getContainerProps,
    animationItems,
  };
}
