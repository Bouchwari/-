import { useEffect, useRef, useState } from 'react';
import { motion, useInView, useMotionValue, useSpring, useTransform } from 'framer-motion';

interface AnimatedCounterProps {
  from: number;
  to: number;
  duration?: number;
  delay?: number;
  formatFn?: (value: number) => string;
  className?: string;
}

export function AnimatedCounter({
  from,
  to,
  duration = 2,
  delay = 0,
  formatFn = (value) => value.toLocaleString(),
  className = 'text-3xl font-bold',
}: AnimatedCounterProps) {
  const nodeRef = useRef<HTMLSpanElement>(null);
  const inView = useInView(nodeRef, { once: false, amount: 0.3 });
  const [hasAnimated, setHasAnimated] = useState(false);
  
  const count = useMotionValue(from);
  const rounded = useTransform(count, (value) => formatFn(Math.round(value)));
  
  // Enhanced spring animation settings for more elastic feel
  const springOptions = {
    damping: 30,         // Less damping for more bounce
    stiffness: 100,      // More stiffness for faster initial movement
    mass: 0.8,           // Less mass for more responsiveness
    velocity: 10,        // Initial velocity for more dramatic start
    restDelta: 0.001     // Smaller restDelta for smoother finish
  };
  
  const spring = useSpring(count, springOptions);
  
  useEffect(() => {
    if (inView && !hasAnimated) {
      setTimeout(() => {
        count.set(to);
        setHasAnimated(true);
      }, delay * 1000);
    }
  }, [inView, hasAnimated, count, to, delay]);
  
  // Reset animation when component goes out of view and comes back
  useEffect(() => {
    if (!inView && hasAnimated) {
      // Only reset if we've already animated once and now not in view
      setHasAnimated(false);
      count.set(from);
    }
  }, [inView, hasAnimated, from, count]);
  
  return (
    <span ref={nodeRef} className={className}>
      <motion.span
        style={{ display: 'inline-block' }}
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ 
          type: "spring", 
          stiffness: 300, 
          damping: 20,
          delay: delay
        }}
      >
        {rounded}
      </motion.span>
    </span>
  );
}
