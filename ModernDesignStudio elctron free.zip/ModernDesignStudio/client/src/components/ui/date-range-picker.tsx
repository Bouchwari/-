import * as React from "react";
import { format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import { DateRange } from "react-day-picker";
import { useTranslation } from "react-i18next";

import { cn } from "../../lib/utils";
import { useLanguageDirection } from "../../hooks/use-language-direction";
import { Button } from "./button";
import { Calendar } from "./calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "./popover";

interface DatePickerWithRangeProps {
  selected: DateRange | undefined;
  onSelect: (date: DateRange | undefined) => void;
  className?: string;
}

export function DatePickerWithRange({
  selected,
  onSelect,
  className,
}: DatePickerWithRangeProps) {
  const { t } = useTranslation();
  const { direction } = useLanguageDirection();
  const isRtl = direction === 'rtl';

  // Format the date in a way that's appropriate for the current locale
  const formatDate = (date: Date) => {
    return format(date, "dd/MM/yyyy");
  };
  
  // Format the date range with proper RTL support
  const formatDateRange = () => {
    if (!selected?.from) return t('common.dateRangePlaceholder');
    
    if (selected.to) {
      const fromFormatted = formatDate(selected.from);
      const toFormatted = formatDate(selected.to);
      
      // In RTL languages like Arabic, the date order is reversed
      return isRtl 
        ? `${toFormatted} - ${fromFormatted}`
        : `${fromFormatted} - ${toFormatted}`;
    }
    
    return formatDate(selected.from);
  };

  return (
    <div className={cn("grid gap-2", className)}>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant={"outline"}
            className={cn(
              "w-full font-normal",
              isRtl 
                ? "justify-end text-right" 
                : "justify-start text-left",
              !selected && "text-muted-foreground"
            )}
          >
            <CalendarIcon className={cn(isRtl ? "ml-2" : "mr-2", "h-4 w-4")} />
            {formatDateRange()}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align={isRtl ? "end" : "start"}>
          <Calendar
            initialFocus
            mode="range"
            selected={selected}
            onSelect={onSelect}
            numberOfMonths={1}
            dir={isRtl ? 'rtl' : 'ltr'}
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}