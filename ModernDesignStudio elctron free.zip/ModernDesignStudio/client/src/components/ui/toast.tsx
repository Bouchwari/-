import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { cn } from "@/lib/utils";
import * as React from "react";

interface ToastProps {
  id: string;
  title?: React.ReactNode;
  description?: React.ReactNode;
  action?: React.ReactNode;
  type?: 'success' | 'error' | 'warning' | 'info';
  onClose?: (id: string) => void;
  children?: React.ReactNode;
  className?: string;
}

const toastTypeClasses = {
  success: 'bg-green-50 border-green-200 text-green-800',
  error: 'bg-red-50 border-red-200 text-red-800',
  warning: 'bg-yellow-50 border-yellow-200 text-yellow-800',
  info: 'bg-blue-50 border-blue-200 text-blue-800',
};

const toastIcons = {
  success: <span className="ri-checkbox-circle-line text-green-500 text-xl"></span>,
  error: <span className="ri-error-warning-line text-red-500 text-xl"></span>,
  warning: <span className="ri-alert-line text-yellow-500 text-xl"></span>,
  info: <span className="ri-information-line text-blue-500 text-xl"></span>,
};

// Custom toast context for Shadcn integration
const ToastContext = React.createContext<{
  toasts: ToastProps[];
  addToast: (toast: Omit<ToastProps, "id">) => void;
  removeToast: (id: string) => void;
}>({
  toasts: [],
  addToast: () => {},
  removeToast: () => {},
});

// ToastProvider component for context
export function ToastProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [toasts, setToasts] = React.useState<ToastProps[]>([]);

  const addToast = React.useCallback((toast: Omit<ToastProps, "id">) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, ...toast }]);
  }, []);

  const removeToast = React.useCallback((id: string) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  }, []);

  return (
    <ToastContext.Provider value={{ toasts, addToast, removeToast }}>
      {children}
    </ToastContext.Provider>
  );
}

// Components for Toast UI
export function Toast({ id, title, description, type = 'info', onClose, children, className }: ToastProps) {
  const context = React.useContext(ToastContext);
  const handleClose = () => {
    if (onClose) {
      onClose(id);
    } else if (context) {
      context.removeToast(id);
    }
  };

  return (
    <motion.div
      className={cn(`flex items-start rounded-lg border px-4 py-3 shadow-lg ${toastTypeClasses[type]}`, className)}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <div className="ml-3 mr-3">{toastIcons[type]}</div>
      <div className="flex-1">
        {children || (
          <>
            {title && <h4 className="font-medium">{title}</h4>}
            {description && <p className="text-sm mt-1">{description}</p>}
          </>
        )}
      </div>
      <button 
        onClick={handleClose}
        className="ml-auto text-gray-400 hover:text-gray-500"
      >
        <X size={16} />
      </button>
    </motion.div>
  );
}

// ToastClose component for shadcn
export function ToastClose() {
  const { id } = React.useContext(ToastActionContext);
  const { removeToast } = React.useContext(ToastContext);

  return (
    <button 
      onClick={() => removeToast(id)}
      className="ml-auto text-gray-400 hover:text-gray-500"
    >
      <X size={16} />
    </button>
  );
}

// ToastTitle component for shadcn
export function ToastTitle({ children }: { children: React.ReactNode }) {
  return <h4 className="font-medium">{children}</h4>;
}

// ToastDescription component for shadcn
export function ToastDescription({ children }: { children: React.ReactNode }) {
  return <p className="text-sm mt-1">{children}</p>;
}

// ToastViewport component for shadcn
export function ToastViewport() {
  const { toasts, removeToast } = React.useContext(ToastContext);

  return (
    <div className="fixed bottom-4 left-4 z-50 flex flex-col space-y-2">
      <AnimatePresence>
        {toasts.map((toast) => (
          <Toast key={toast.id} {...toast} onClose={removeToast} />
        ))}
      </AnimatePresence>
    </div>
  );
}

// Action context for toast actions
const ToastActionContext = React.createContext<{ id: string }>({ id: "" });

// Original ToastContainer for compatibility
interface ToastContainerProps {
  toasts: ToastProps[];
  onClose: (id: string) => void;
}

export function ToastContainer({ toasts, onClose }: ToastContainerProps) {
  return (
    <div className="fixed bottom-4 left-4 z-50 flex flex-col space-y-2">
      <AnimatePresence>
        {toasts.map((toast) => (
          <Toast key={toast.id} {...toast} onClose={onClose} />
        ))}
      </AnimatePresence>
    </div>
  );
}
