import { motion } from 'framer-motion';
import { AnimatedCounter } from '@/components/ui/animated-counter';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface KpiCardProps {
  title: string;
  value: number;
  change?: {
    value: number;
    isPositive: boolean;
  };
  subtitle?: string;
  icon: string;
  iconColor: "primary" | "secondary" | "warning" | "destructive" | "success";
  index?: number;
}

export function KpiCard({
  title,
  value,
  change,
  subtitle,
  icon,
  iconColor,
  index = 0,
}: KpiCardProps) {
  const iconColorMap = {
    primary: "bg-primary/10 text-primary",
    secondary: "bg-secondary/10 text-secondary",
    warning: "bg-yellow-100 text-amber-500",
    destructive: "bg-red-100 text-destructive",
    success: "bg-green-100 text-green-600",
  };
  
  const changeColorClass = change?.isPositive 
    ? "text-green-600" 
    : "text-destructive";
  
  const cardVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { 
        duration: 0.5, 
        delay: index * 0.1,
        ease: [0.43, 0.13, 0.23, 0.96],
        when: "beforeChildren",
        staggerChildren: 0.1
      }
    },
    hover: { 
      y: -4,
      boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
      transition: { duration: 0.2, ease: "easeOut" }
    }
  };
  
  const iconVariants = {
    hidden: { scale: 0.6, opacity: 0 },
    visible: { 
      scale: 1, 
      opacity: 1,
      transition: { 
        type: "spring",
        stiffness: 300,
        damping: 15
      }
    },
    hover: { 
      scale: 1.1,
      rotate: [0, -10, 10, -5, 5, 0],
      transition: { duration: 0.5 }
    }
  };
  
  const contentVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { duration: 0.3 }
    }
  };
  
  const changeVariants = {
    hidden: { opacity: 0, x: change?.isPositive ? -10 : 10 },
    visible: { 
      opacity: 1, 
      x: 0,
      transition: { 
        type: "spring", 
        stiffness: 500,
        damping: 25, 
        delay: 0.3 + (index * 0.1) 
      }
    }
  };

  return (
    <motion.div
      className="h-full"
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      whileHover="hover"
    >
      <Card className="p-6 h-full hover-elevation overflow-hidden">
        <div className="flex justify-between items-start mb-4">
          <motion.h3 
            variants={contentVariants}
            className="text-muted-foreground font-medium"
          >
            {title}
          </motion.h3>
          <motion.div 
            variants={iconVariants}
            className={cn("w-12 h-12 rounded-full flex items-center justify-center", iconColorMap[iconColor])}
          >
            <i className={cn(icon, "text-xl")}></i>
          </motion.div>
        </div>
        
        <div className="flex items-end mb-1">
          <motion.div variants={contentVariants}>
            <AnimatedCounter 
              from={0} 
              to={value} 
              className="text-3xl font-bold font-kufi" 
              delay={index * 0.1}
              formatFn={(val) => {
                // Add suffix if necessary (e.g. د.م. for currency)
                if (title.includes('ميزانية') || title.includes('Budget')) {
                  return `${val.toLocaleString()} د.م.`;
                }
                return val.toLocaleString();
              }}
            />
          </motion.div>
          
          {change && (
            <motion.div 
              variants={changeVariants}
              className={cn("flex items-center mr-2 text-sm font-medium", changeColorClass)}
            >
              <i className={`ri-arrow-${change.isPositive ? 'up' : 'down'}-s-line ml-1`}></i>
              <span>{change.value}%</span>
            </motion.div>
          )}
        </div>
        
        {subtitle && (
          <motion.p 
            variants={contentVariants}
            className="text-sm text-muted-foreground"
          >
            {subtitle}
          </motion.p>
        )}
        
        {/* Decorative gradient overlay for visual interest */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary/10 to-transparent opacity-70"></div>
      </Card>
    </motion.div>
  );
}
