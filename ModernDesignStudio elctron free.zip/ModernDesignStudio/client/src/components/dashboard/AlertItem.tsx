import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { cn } from '@/lib/utils';

type AlertType = 'error' | 'warning' | 'info' | 'success';

interface AlertItemProps {
  title: string;
  description: string;
  type: AlertType;
  actionLabel?: string;
  actionIcon?: string;
  onAction?: () => void;
  index?: number;
}

export function AlertItem({
  title,
  description,
  type,
  actionLabel,
  actionIcon,
  onAction,
  index = 0,
}: AlertItemProps) {
  const alertStyles: Record<AlertType, string> = {
    error: 'bg-red-50 border-red-200 text-red-800',
    warning: 'bg-yellow-50 border-yellow-200 text-yellow-800',
    info: 'bg-blue-50 border-blue-200 text-blue-800',
    success: 'bg-green-50 border-green-200 text-green-800',
  };
  
  const iconStyles: Record<AlertType, string> = {
    error: 'ri-error-warning-line text-red-500',
    warning: 'ri-alert-line text-yellow-500',
    info: 'ri-information-line text-blue-500',
    success: 'ri-checkbox-circle-line text-green-500',
  };
  
  const buttonStyles: Record<AlertType, string> = {
    error: 'bg-white hover:bg-red-50 text-red-500 border border-red-200',
    warning: 'bg-white hover:bg-yellow-50 text-yellow-500 border border-yellow-200',
    info: 'bg-white hover:bg-blue-50 text-blue-500 border border-blue-200',
    success: 'bg-white hover:bg-green-50 text-green-500 border border-green-200',
  };
  
  const alertVariants = {
    hidden: { x: -30, opacity: 0 },
    visible: { 
      x: 0, 
      opacity: 1,
      transition: { 
        type: "spring",
        stiffness: 260,
        damping: 20,
        delay: 0.5 + index * 0.15,
        duration: 0.5
      }
    },
    hover: { 
      scale: 1.02,
      boxShadow: "0 10px 30px -5px rgba(0, 0, 0, 0.1)",
      transition: { duration: 0.2 }
    }
  };
  
  const iconVariants = {
    hidden: { scale: 0, opacity: 0 },
    visible: { 
      scale: 1, 
      opacity: 1,
      transition: { 
        type: "spring",
        stiffness: 300,
        damping: 10,
        delay: 0.6 + index * 0.15
      }
    },
    hover: {
      rotate: [0, -10, 10, -5, 0],
      transition: { duration: 0.5 }
    }
  };
  
  const contentVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.3,
        delay: 0.7 + index * 0.15
      }
    }
  };
  
  const buttonVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { 
        type: "spring",
        stiffness: 500,
        damping: 25,
        delay: 0.8 + index * 0.15
      }
    },
    hover: { 
      scale: 1.05,
      transition: { duration: 0.2 }
    },
    tap: { 
      scale: 0.95 
    }
  };

  // Helper function to determine border style based on alert type
  const getBorderGradient = (type: AlertType) => {
    const gradientMap = {
      error: 'from-red-300 to-red-100',
      warning: 'from-yellow-300 to-yellow-100',
      info: 'from-blue-300 to-blue-100',
      success: 'from-green-300 to-green-100'
    };
    
    return `bg-gradient-to-r ${gradientMap[type]}`;
  };

  return (
    <motion.div
      variants={alertVariants}
      initial="hidden"
      animate="visible"
      whileHover="hover"
      className="relative overflow-hidden"
    >
      <Alert className={cn("flex items-center", alertStyles[type], "pr-6 relative overflow-hidden")}>
        {/* Decorative left border with gradient */}
        <div className={cn("absolute left-0 top-0 bottom-0 w-1", getBorderGradient(type))}></div>
        
        <motion.div 
          className="ml-4 text-2xl"
          variants={iconVariants}
        >
          <i className={iconStyles[type]}></i>
        </motion.div>
        
        <motion.div className="ml-3" variants={contentVariants}>
          <AlertTitle className="font-kufi">{title}</AlertTitle>
          <AlertDescription className="text-sm">{description}</AlertDescription>
        </motion.div>
        
        {actionLabel && (
          <motion.div 
            className="ml-auto"
            variants={buttonVariants}
            whileHover="hover"
            whileTap="tap"
          >
            <Button
              className={cn(buttonStyles[type], "transition-all duration-300")}
              variant="outline"
              size="sm"
              onClick={onAction}
            >
              {actionIcon && <i className={cn(actionIcon, "ml-1 transition-transform duration-300 group-hover:rotate-12")}></i>}
              <span>{actionLabel}</span>
            </Button>
          </motion.div>
        )}
        
        {/* Subtle background pattern for visual interest */}
        <div className="absolute -right-10 -bottom-10 w-40 h-40 opacity-10 rounded-full" 
          style={{
            background: `radial-gradient(circle, ${type === 'error' ? 'rgba(239,68,68,0.6)' : 
              type === 'warning' ? 'rgba(245,158,11,0.6)' : 
              type === 'info' ? 'rgba(59,130,246,0.6)' : 
              'rgba(34,197,94,0.6)'} 0%, transparent 70%)`
          }}
        ></div>
      </Alert>
    </motion.div>
  );
}
