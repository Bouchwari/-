import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguageDirection } from '@/hooks/use-language-direction';
import Chart from 'chart.js/auto';
import { useTranslation } from 'react-i18next';

interface ChartCardProps {
  title: string;
  type: 'bar' | 'line' | 'pie' | 'doughnut';
  data: {
    labels: string[];
    datasets: Array<{
      label: string;
      data: number[];
      backgroundColor?: string | string[];
      borderColor?: string;
      borderWidth?: number;
      fill?: boolean;
      tension?: number;
    }>;
  };
  height?: number;
  index?: number;
}

export function ChartCard({
  title,
  type,
  data,
  height = 300,
  index = 0,
}: ChartCardProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  const { direction } = useLanguageDirection();
  const { i18n } = useTranslation();
  
  useEffect(() => {
    if (chartRef.current) {
      // Destroy previous chart instance if exists
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
      
      // Create new chart with premium styling
      const ctx = chartRef.current.getContext('2d');
      if (ctx) {
        // Add gradient for bar charts or handle CSS vars for pie/doughnut
        const gradients: (CanvasGradient | null)[] = [];
        if (ctx) {
          data.datasets.forEach((dataset, index) => {
            if (dataset.backgroundColor) {
              if (typeof dataset.backgroundColor === 'string') {
                const colorStr = dataset.backgroundColor as string;
                
                // Convert CSS custom property to actual color
                let actualColor = colorStr;
                if (colorStr.includes('var(--chart-')) {
                  // Directly map chart variables to fixed colors
                  if (colorStr === 'hsl(var(--chart-1))') {
                    actualColor = 'hsl(205, 90%, 54%)';
                  } else if (colorStr === 'hsl(var(--chart-2))') {
                    actualColor = 'hsl(93, 58%, 40%)';
                  } else if (colorStr === 'hsl(var(--chart-3))') {
                    actualColor = 'hsl(36, 100%, 50%)';
                  } else if (colorStr === 'hsl(var(--chart-4))') {
                    actualColor = 'hsl(262, 83%, 58%)';
                  } else if (colorStr === 'hsl(var(--chart-5))') {
                    actualColor = 'hsl(0, 100%, 50%)';
                  } else {
                    actualColor = 'hsl(205, 90%, 54%)'; // Fallback to primary color
                  }
                }
                
                const gradient = ctx.createLinearGradient(0, 0, 0, 400);
                gradient.addColorStop(0, actualColor);
                gradient.addColorStop(1, actualColor.replace('54%)', '74%)').replace('40%)', '60%)').replace('50%)', '70%)').replace('58%)', '78%)'));
                gradients[index] = gradient;
              } else if (Array.isArray(dataset.backgroundColor)) {
                // For doughnut/pie charts with an array of colors
                const fixedColors = dataset.backgroundColor.map((color: string) => {
                  if (typeof color === 'string' && color.includes('var(--chart-')) {
                    if (color === 'hsl(var(--chart-1))') return 'hsl(205, 90%, 54%)';
                    if (color === 'hsl(var(--chart-2))') return 'hsl(93, 58%, 40%)';
                    if (color === 'hsl(var(--chart-3))') return 'hsl(36, 100%, 50%)';
                    if (color === 'hsl(var(--chart-4))') return 'hsl(262, 83%, 58%)';
                    if (color === 'hsl(var(--chart-5))') return 'hsl(0, 100%, 50%)';
                    return 'hsl(205, 90%, 54%)'; // Fallback
                  }
                  return color;
                });
                
                // For pie/doughnut we don't use gradients, we directly set the colors
                dataset.backgroundColor = fixedColors;
                gradients[index] = null;
              } else {
                gradients[index] = null;
              }
            } else {
              gradients[index] = null;
            }
          });
        }
        
        // Premium styling options
        chartInstance.current = new Chart(ctx, {
          type,
          data: {
            ...data,
            datasets: data.datasets.map((dataset, index) => {
              // Apply gradients for bar charts
              if (type === 'bar' && gradients[index]) {
                return {
                  ...dataset,
                  backgroundColor: gradients[index]
                };
              }
              return dataset;
            })
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: {
              duration: 2000,
              easing: 'easeOutQuart'
            },
            layout: {
              padding: {
                top: 10,
                right: 15,
                bottom: 10,
                left: 15
              }
            },
            plugins: {
              legend: {
                position: 'top',
                align: 'start',
                labels: {
                  boxWidth: 15,
                  boxHeight: 15,
                  padding: 15,
                  usePointStyle: true,
                  pointStyle: 'circle',
                  font: {
                    family: 'Noto Kufi Arabic, Noto Sans, sans-serif',
                    size: 12
                  }
                }
              },
              tooltip: {
                rtl: direction === 'rtl',
                textDirection: direction,
                backgroundColor: 'rgba(24, 24, 27, 0.9)',
                padding: 12,
                cornerRadius: 8,
                titleFont: {
                  family: 'Noto Kufi Arabic, Noto Sans, sans-serif',
                  size: 14,
                  weight: 'bold'
                },
                bodyFont: {
                  family: 'Noto Kufi Arabic, Noto Sans, sans-serif',
                  size: 13
                },
                displayColors: true,
                boxPadding: 5,
                usePointStyle: true,
                callbacks: {
                  label: function(context) {
                    let label = context.dataset.label || '';
                    if (label) {
                      label += ': ';
                    }
                    if (context.parsed.y !== null) {
                      label += type === 'bar' ? 
                        new Intl.NumberFormat('ar-MA', { 
                          style: 'currency', 
                          currency: 'MAD',
                          minimumFractionDigits: 0
                        }).format(context.parsed.y) :
                        context.parsed.y;
                    }
                    return label;
                  }
                }
              }
            },
            scales: {}
          }
        });
      }
    }
    
    // Cleanup
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [type, data, direction, i18n.language]);
  
  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.6,
        delay: 0.3 + index * 0.1,
        ease: [0.25, 0.1, 0.25, 1],
        when: "beforeChildren"
      }
    },
    hover: { 
      scale: 1.01,
      boxShadow: "0 10px 30px -5px rgba(0, 0, 0, 0.1)",
      transition: { duration: 0.3, ease: "easeOut" }
    }
  };
  
  const contentVariants = {
    hidden: { opacity: 0, scale: 0.98 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { 
        duration: 0.4,
        delay: 0.1
      }
    }
  };
  
  const titleVariants = {
    hidden: { opacity: 0, x: -5 },
    visible: { 
      opacity: 1, 
      x: 0,
      transition: { 
        duration: 0.3,
        delay: 0.05
      }
    }
  };
  
  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      whileHover="hover"
      className="h-full"
    >
      <Card className="overflow-hidden h-full">
        <CardHeader className="pb-2 relative">
          <motion.div variants={titleVariants}>
            <CardTitle className="font-kufi flex items-center">
              {title}
              <motion.div
                className="ml-2 h-1.5 w-10 rounded-full bg-primary/20"
                animate={{
                  width: [10, 40, 10],
                  opacity: [0.6, 1, 0.6],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
            </CardTitle>
          </motion.div>
          
          {/* Decorative gradient overlay for visual interest */}
          <div className="absolute top-0 right-0 h-1 w-full bg-gradient-to-l from-primary/40 to-transparent"></div>
        </CardHeader>
        <CardContent>
          <motion.div 
            style={{ height: `${height}px` }} 
            className="chart-container" 
            dir="ltr"
            variants={contentVariants}
          >
            <canvas ref={chartRef}></canvas>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
