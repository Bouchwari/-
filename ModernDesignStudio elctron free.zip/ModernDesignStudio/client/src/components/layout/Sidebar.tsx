import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { cn, avatarFallbackInitials } from '@/lib/utils';
import { 
  LayoutDashboard, 
  Package, 
  FileText, 
  Truck, 
  Wrench, 
  Settings, 
  Building2, 
  ChevronLeft, 
  ChevronRight, 
  LogOut,
  Info,
  FileQuestion,
  BarChart3
} from 'lucide-react';
import { useMediaQuery } from '@/hooks/use-media-query';
import { Badge } from '@/components/ui/badge';
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from '@/components/ui/tooltip';

interface SidebarLink {
  href: string;
  label: string;
  icon: React.ReactNode;
  badge?: {
    text: string;
    variant: 'default' | 'secondary' | 'destructive' | 'outline';
  };
  isNew?: boolean;
}

export default function Sidebar() {
  const [location] = useLocation();
  const { t } = useTranslation();
  const [expanded, setExpanded] = useState(true);
  const [isHovering, setIsHovering] = useState<string | null>(null);
  const isMobile = useMediaQuery('(max-width: 768px)');
  
  // Auto-collapse sidebar on mobile
  useEffect(() => {
    if (isMobile) {
      setExpanded(false);
    } else {
      setExpanded(true);
    }
  }, [isMobile]);
  
  const sidebarLinks: SidebarLink[] = [
    { 
      href: '/', 
      label: t('sidebar.dashboard'), 
      icon: <LayoutDashboard className="h-5 w-5" /> 
    },
    { 
      href: '/inventory', 
      label: t('sidebar.inventory'), 
      icon: <Package className="h-5 w-5" />,
      badge: { text: '53', variant: 'default' }
    },
    { 
      href: '/requests', 
      label: t('sidebar.requests'), 
      icon: <FileText className="h-5 w-5" />,
      badge: { text: '3', variant: 'destructive' }
    },
    { 
      href: '/distribution', 
      label: t('sidebar.distribution'), 
      icon: <Truck className="h-5 w-5 flip-x" /> 
    },
    { 
      href: '/maintenance', 
      label: t('sidebar.maintenance'), 
      icon: <Wrench className="h-5 w-5" /> 
    },
    { 
      href: '/reports', 
      label: t('sidebar.reports'), 
      icon: <BarChart3 className="h-5 w-5" />,
      isNew: true
    },
    { 
      href: '/settings', 
      label: t('sidebar.settings'), 
      icon: <Settings className="h-5 w-5" /> 
    },
  ];

  const variants = {
    expanded: { width: '16rem' },
    collapsed: { width: '4.5rem' }
  };
  
  const sidebarItemVariants = {
    expanded: { opacity: 1, x: 0 },
    collapsed: { opacity: 0, x: -10 }
  };
  
  const logoVariants = {
    expanded: { opacity: 1, x: 0 },
    collapsed: { opacity: 0, x: -10 }
  };
  
  return (
    <motion.aside
      variants={variants}
      initial={expanded ? 'expanded' : 'collapsed'}
      animate={expanded ? 'expanded' : 'collapsed'}
      className="bg-white dark:bg-slate-900/95 border-r border-r-border/50 shadow-sm h-full hidden md:flex flex-col overflow-hidden transition-all"
    >
      {/* Header with Logo */}
      <motion.div 
        className="p-4 border-b border-b-border/50 flex items-center justify-between"
        whileHover={{ backgroundColor: 'rgba(0,0,0,0.01)' }}
      >
        <div className="flex items-center">
          <motion.div 
            className="relative w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-lg flex items-center justify-center text-white shadow-md overflow-hidden"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Building2 className="h-5 w-5 z-10" />
            <motion.div 
              className="absolute inset-0 bg-gradient-to-tr from-primary-foreground/10 to-transparent opacity-0"
              animate={{ 
                opacity: [0, 0.5, 0], 
                rotate: [0, 5, 0] 
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 4, 
                ease: "easeInOut" 
              }}
            />
          </motion.div>
          
          <AnimatePresence>
            {expanded && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="ml-3"
              >
                <motion.h1 
                  className="font-kufi font-bold text-lg"
                  initial={{ y: 0 }}
                  whileHover={{ y: -1 }}
                >
                  {t('app.title')}
                </motion.h1>
                <p className="text-xs text-muted-foreground">
                  {t('app.subtitle')}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        <motion.button 
          onClick={() => setExpanded(!expanded)}
          className="h-7 w-7 rounded-full flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          {expanded ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        </motion.button>
      </motion.div>
      
      {/* Navigation Links */}
      <nav className="flex-1 py-4 overflow-y-auto">
        <TooltipProvider delayDuration={100}>
          <ul className="space-y-1 px-2">
            {sidebarLinks.map((link) => {
              const isActive = location === link.href;
              
              return (
                <li key={link.href}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div onClick={(e) => {
                        e.preventDefault();
                        window.location.href = link.href;
                      }}>
                        <motion.div
                          className={cn(
                            "flex w-full items-center px-3 py-2 rounded-md transition-all cursor-pointer",
                            "hover:bg-gray-100 dark:hover:bg-gray-800 relative overflow-hidden group",
                            isActive 
                              ? "bg-primary/10 text-primary font-medium shadow-sm" 
                              : "text-muted-foreground"
                          )}
                          onHoverStart={() => setIsHovering(link.href)}
                          onHoverEnd={() => setIsHovering(null)}
                          whileHover={{ x: 2 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          {/* Active indicator */}
                          {isActive && (
                            <motion.div 
                              className="absolute left-0 top-0 bottom-0 w-1 bg-primary rounded-full" 
                              layoutId="activeIndicator"
                              transition={{ type: "spring", stiffness: 300, damping: 30 }}
                            />
                          )}
                          
                          {/* Link content */}
                          <div className={`${isActive ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground'} transition-colors flex items-center justify-center`}>
                            {link.icon}
                          </div>
                          
                          {/* Animated hover background for active items */}
                          {isActive && isHovering === link.href && (
                            <motion.div 
                              className="absolute inset-0 bg-primary/5 rounded-md"
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              exit={{ opacity: 0 }}
                              transition={{ duration: 0.2 }}
                            />
                          )}
                          
                          {/* Label */}
                          <AnimatePresence>
                            {expanded && (
                              <motion.div
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -10 }}
                                transition={{ duration: 0.15 }}
                                className="ml-3 flex-1 flex items-center justify-between"
                              >
                                <span className="text-sm whitespace-nowrap">{link.label}</span>
                                
                                {/* Badge */}
                                {link.badge && (
                                  <Badge variant={link.badge.variant} className="ml-2 px-1 py-0 h-5">
                                    {link.badge.text}
                                  </Badge>
                                )}
                                
                                {/* New indicator */}
                                {link.isNew && (
                                  <span className="ml-2 px-1.5 py-0.5 rounded-sm text-[10px] bg-secondary text-secondary-foreground font-medium animate-pulse-custom">
                                    {t('common.new')}
                                  </span>
                                )}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </motion.div>
                      </div>
                    </TooltipTrigger>
                    {!expanded && (
                      <TooltipContent side="right" className="font-medium">
                        <p>{link.label}</p>
                        {link.badge && (
                          <Badge variant={link.badge.variant} className="ml-1 px-1 py-0 h-4">
                            {link.badge.text}
                          </Badge>
                        )}
                      </TooltipContent>
                    )}
                  </Tooltip>
                </li>
              );
            })}
          </ul>
        </TooltipProvider>
        
        {/* Help & Support Section */}
        <div className="mt-6 px-3">
          <AnimatePresence>
            {expanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <h3 className="text-xs font-medium uppercase text-muted-foreground ml-2 mb-2">
                  {t('sidebar.helpSupport')}
                </h3>
              </motion.div>
            )}
          </AnimatePresence>
          
          <TooltipProvider>
            <ul className="space-y-1">
              <Tooltip>
                <TooltipTrigger asChild>
                  <motion.div
                    className="flex items-center px-3 py-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-muted-foreground cursor-pointer"
                    whileHover={{ x: 2 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <FileQuestion className="h-5 w-5" />
                    
                    <AnimatePresence>
                      {expanded && (
                        <motion.span
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -10 }}
                          transition={{ duration: 0.15 }}
                          className="ml-3 text-sm"
                        >
                          {t('sidebar.documentation')}
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </motion.div>
                </TooltipTrigger>
                {!expanded && (
                  <TooltipContent side="right">
                    <p>{t('sidebar.documentation')}</p>
                  </TooltipContent>
                )}
              </Tooltip>
              
              <Tooltip>
                <TooltipTrigger asChild>
                  <motion.div
                    className="flex items-center px-3 py-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-muted-foreground cursor-pointer"
                    whileHover={{ x: 2 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Info className="h-5 w-5" />
                    
                    <AnimatePresence>
                      {expanded && (
                        <motion.span
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -10 }}
                          transition={{ duration: 0.15 }}
                          className="ml-3 text-sm"
                        >
                          {t('sidebar.about')}
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </motion.div>
                </TooltipTrigger>
                {!expanded && (
                  <TooltipContent side="right">
                    <p>{t('sidebar.about')}</p>
                  </TooltipContent>
                )}
              </Tooltip>
            </ul>
          </TooltipProvider>
        </div>
      </nav>
      
      {/* User Profile */}
      <motion.div 
        className="border-t border-t-border/50 p-3"
        whileHover={{ backgroundColor: 'rgba(0,0,0,0.01)' }}
      >
        <div className="flex items-center gap-2">
          <motion.div 
            className="relative w-9 h-9 rounded-full bg-gradient-to-br from-primary/80 to-primary flex items-center justify-center text-white shadow-sm overflow-hidden cursor-pointer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="z-10 font-medium text-sm">
              {avatarFallbackInitials('محمد المغربي')}
            </span>
            <motion.div 
              className="absolute inset-0 bg-gradient-to-tr from-primary-foreground/10 to-transparent opacity-0"
              animate={{ opacity: [0, 0.2, 0] }}
              transition={{ repeat: Infinity, duration: 3 }}
            />
          </motion.div>
          
          <AnimatePresence>
            {expanded && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="flex-1 overflow-hidden"
              >
                <p className="text-sm font-medium truncate">محمد المغربي</p>
                <p className="text-xs text-muted-foreground truncate">{t('common.administrator')}</p>
              </motion.div>
            )}
          </AnimatePresence>
          
          <AnimatePresence>
            {expanded && (
              <motion.button
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.15 }}
                className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-muted-foreground"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <LogOut className="h-4 w-4" />
              </motion.button>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </motion.aside>
  );
}
