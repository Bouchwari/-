import { Calendar, LogOut, MenuIcon, Bell, Settings, Search, SunIcon, MoonIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTranslation } from 'react-i18next';
import { LanguageSwitcher } from '@/components/ui/language-switcher';
import { motion, AnimatePresence } from 'framer-motion';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn, avatarFallbackInitials } from '@/lib/utils';
import { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { ar, fr, enUS } from 'date-fns/locale';
import { Badge } from '@/components/ui/badge';

interface HeaderProps {
  currentPath: string;
}

export default function Header({ currentPath }: HeaderProps) {
  const { t, i18n } = useTranslation();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isSearchActive, setIsSearchActive] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [notificationsCount, setNotificationsCount] = useState(3);
  
  // Update time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    
    return () => clearInterval(timer);
  }, []);
  
  // Get locale for date-fns based on i18n language
  const getLocale = () => {
    switch (i18n.language) {
      case 'ar':
        return ar;
      case 'fr':
        return fr;
      default:
        return enUS;
    }
  };
  
  // Map paths to titles
  const pathTitles: Record<string, string> = {
    '/': t('pages.dashboard'),
    '/inventory': t('pages.inventory'),
    '/requests': t('pages.requests'),
    '/distribution': t('pages.distribution'),
    '/maintenance': t('pages.maintenance'),
    '/settings': t('pages.settings'),
  };
  
  const pageTitle = pathTitles[currentPath] || t('pages.notFound');
  
  // Notification items (simulate real notifications)
  const notifications = [
    { 
      id: 1, 
      title: t('notifications.inventoryLow'),
      description: t('notifications.inventoryLowDesc'),
      time: '10m',
      type: 'warning'
    },
    { 
      id: 2, 
      title: t('notifications.newRequest', {teacher: 'ليلى أحمد'}),
      description: t('notifications.newRequestDesc'),
      time: '25m',
      type: 'info'
    },
    { 
      id: 3, 
      title: t('notifications.maintenanceComplete'),
      description: t('notifications.maintenanceCompleteDesc'),
      time: '1h',
      type: 'success'
    }
  ];
  
  // Toggle dark mode
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };
  
  return (
    <header className="bg-white dark:bg-slate-950/90 border-b shadow-sm backdrop-blur-sm py-2 px-4 md:px-6 flex items-center justify-between sticky top-0 z-10 transition-all duration-200">
      {/* Left side - Title and Search */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden mr-2 hover:bg-slate-100 dark:hover:bg-slate-800"
          aria-label="Toggle sidebar"
        >
          <MenuIcon className="h-5 w-5" />
        </Button>
        
        <motion.div
          layout
          className="flex items-center"
        >
          <AnimatePresence initial={false} mode="wait">
            {!isSearchActive ? (
              <motion.h1 
                key="page-title"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.2 }}
                className="text-xl font-kufi font-bold flex items-center"
              >
                <span>{pageTitle}</span>
                <motion.div
                  className="ml-2 h-1 w-5 rounded-full bg-primary/30"
                  initial={{ width: 5 }}
                  animate={{ width: [5, 20, 5] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                />
              </motion.h1>
            ) : (
              <motion.div 
                key="search-input"
                initial={{ opacity: 0, width: 100 }}
                animate={{ opacity: 1, width: 300 }}
                exit={{ opacity: 0, width: 100 }}
                className="relative"
              >
                <Input
                  type="text"
                  placeholder={t('common.searchPlaceholder')}
                  className="pl-9 pr-4 py-2 rounded-full"
                  autoFocus
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </motion.div>
            )}
          </AnimatePresence>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSearchActive(!isSearchActive)}
            className="ml-2 rounded-full h-8 w-8 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            {isSearchActive ? (
              <motion.span 
                initial={{ rotate: -90 }}
                animate={{ rotate: 0 }}
              >
                ×
              </motion.span>
            ) : (
              <Search className="h-4 w-4" />
            )}
          </Button>
        </motion.div>
      </div>
      
      {/* Right side - Actions, User menu, Language */}
      <div className="flex items-center gap-1 md:gap-2">
        {/* Current time with localization */}
        <div className="hidden md:flex items-center mr-2 px-2 py-1 bg-gray-50 dark:bg-gray-800/30 rounded-md">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center text-xs text-muted-foreground">
                  <Calendar className="h-3 w-3 mr-1.5" />
                  <time>{format(currentTime, 'EEEE, p', { locale: getLocale() })}</time>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>{format(currentTime, 'PPP', { locale: getLocale() })}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      
        {/* Dark Mode Toggle */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={toggleDarkMode}
                className="relative h-8 w-8 rounded-full overflow-hidden"
              >
                <motion.div
                  animate={{ rotate: isDarkMode ? 0 : 180 }}
                  transition={{ type: "spring", stiffness: 200, damping: 10 }}
                >
                  {isDarkMode ? 
                    <SunIcon className="h-4 w-4 text-yellow-400" /> : 
                    <MoonIcon className="h-4 w-4 text-slate-700" />
                  }
                </motion.div>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{isDarkMode ? t('common.lightMode') : t('common.darkMode')}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        {/* Language Switcher */}
        <LanguageSwitcher />
        
        {/* Notifications */}
        <DropdownMenu>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="relative h-8 w-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <Bell className="h-4 w-4" />
                    {notificationsCount > 0 && (
                      <motion.div 
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute -top-1 -right-1 flex items-center justify-center"
                      >
                        <Badge variant="destructive" className="h-4 min-w-4 flex items-center justify-center rounded-full text-[10px] px-[5px]">
                          {notificationsCount}
                        </Badge>
                      </motion.div>
                    )}
                  </Button>
                </DropdownMenuTrigger>
              </TooltipTrigger>
              <TooltipContent>
                <p>{t('common.notifications')}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <DropdownMenuContent align="end" className="w-80">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="font-medium">{t('notifications.title')}</h3>
              <Button variant="ghost" size="sm" className="h-auto py-1 px-2 text-xs hover:bg-slate-100 dark:hover:bg-slate-800">
                {t('notifications.markAllRead')}
              </Button>
            </div>
            
            <div className="py-2 max-h-[300px] overflow-y-auto">
              {notifications.map((notification) => (
                <div 
                  key={notification.id}
                  className="px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer border-b border-border/40 last:border-none transition-colors"
                >
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium">{notification.title}</span>
                    <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">{notification.time}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{notification.description}</p>
                </div>
              ))}
            </div>
            
            <div className="p-2 border-t">
              <Button variant="outline" size="sm" className="w-full">
                {t('notifications.viewAll')}
              </Button>
            </div>
          </DropdownMenuContent>
        </DropdownMenu>
        
        {/* User Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              className="relative h-8 w-8 rounded-full ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              <motion.div 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/70 to-primary flex items-center justify-center text-white font-medium text-sm overflow-hidden"
              >
                <motion.span
                  initial={{ y: 0 }}
                  whileHover={{ y: [-1, 1, -1] }}
                  transition={{ repeat: Infinity, duration: 1 }}
                >
                  {avatarFallbackInitials('محمد المغربي')}
                </motion.span>
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-tr from-primary-foreground/10 to-transparent opacity-0"
                  whileHover={{ opacity: 0.5 }}
                  transition={{ duration: 0.2 }}
                />
              </motion.div>
            </Button>
          </DropdownMenuTrigger>
          
          <DropdownMenuContent align="end" className="w-56">
            <div className="flex flex-col items-center p-4 border-b">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/70 to-primary flex items-center justify-center text-white font-medium text-xl mb-2">
                {avatarFallbackInitials('محمد المغربي')}
              </div>
              <p className="font-medium">محمد المغربي</p>
              <p className="text-xs text-muted-foreground">مدير المدرسة</p>
            </div>
            
            <div className="p-2">
              <DropdownMenuItem className="cursor-pointer">
                <Settings className="mr-2 h-4 w-4" />
                <span>{t('common.profile')}</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer">
                <Calendar className="mr-2 h-4 w-4" />
                <span>{t('common.activity')}</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="cursor-pointer text-destructive">
                <LogOut className="mr-2 h-4 w-4" />
                <span>{t('common.logout')}</span>
              </DropdownMenuItem>
            </div>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
