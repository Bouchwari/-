import { useTranslation } from "react-i18next";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { ChartCard } from "@/components/dashboard/ChartCard";
import { AlertItem } from "@/components/dashboard/AlertItem";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { t } = useTranslation();
  const { toast } = useToast();

  // Define dashboard data type
  type DashboardData = {
    inventory: {
      total: number;
      change: {
        value: number;
        isPositive: boolean;
      };
    };
    requests: {
      pending: number;
      total: number;
    };
    maintenance: {
      total: number;
      overdue: number;
    };
  };

  // Fetch dashboard data
  const { data, isLoading, error } = useQuery<DashboardData>({
    queryKey: ["/api/dashboard"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Handle errors with onError callback instead of during render
  if (error) {
    // Use a setTimeout to avoid React state updates during render
    setTimeout(() => {
      toast({
        title: t("errors.loadFailed"),
        description: error.message,
        variant: "destructive",
      });
    }, 0);
  }

  // Premium color palette for charts
  const premiumColors = {
    // Vibrant but sophisticated colors with opacity variations
    primary: "rgba(99, 102, 241, 1)", // Indigo
    primaryLight: "rgba(99, 102, 241, 0.15)",
    secondary: "rgba(244, 114, 182, 1)", // Pink
    secondaryLight: "rgba(244, 114, 182, 0.15)",
    tertiary: "rgba(16, 185, 129, 1)", // Emerald
    tertiaryLight: "rgba(16, 185, 129, 0.15)",
    quaternary: "rgba(245, 158, 11, 1)", // Amber
    quaternaryLight: "rgba(245, 158, 11, 0.15)",
    quinary: "rgba(139, 92, 246, 1)", // Purple
    quinaryLight: "rgba(139, 92, 246, 0.15)",
  };

  // Inventory distribution chart data
  const inventoryChartData = {
    labels: [
      t("months.jan"),
      t("months.feb"),
      t("months.mar"),
      t("months.apr"),
      t("months.may"),
      t("months.jun"),
    ],
    datasets: [
      {
        label: t("dashboard.charts.stationery"),
        data: [120, 150, 180, 195, 210, 235],
        backgroundColor: premiumColors.primary,
        borderWidth: 0,
        borderRadius: 6,
        hoverBackgroundColor: "rgba(99, 102, 241, 0.8)",
      },
      {
        label: t("dashboard.charts.technology"),
        data: [50, 58, 62, 65, 70, 78],
        backgroundColor: premiumColors.secondary,
        borderWidth: 0,
        borderRadius: 6,
        hoverBackgroundColor: "rgba(244, 114, 182, 0.8)",
      },
      {
        label: t("dashboard.charts.furniture"),
        data: [30, 32, 36, 40, 42, 45],
        backgroundColor: premiumColors.tertiary,
        borderWidth: 0,
        borderRadius: 6,
        hoverBackgroundColor: "rgba(16, 185, 129, 0.8)",
      },
    ],
  };

  // Maintenance frequency chart data with enhanced styling
  const maintenanceChartData = {
    labels: [
      t("months.jan"),
      t("months.feb"),
      t("months.mar"),
      t("months.apr"),
      t("months.may"),
      t("months.jun"),
    ],
    datasets: [
      {
        label: t("dashboard.charts.computers"),
        data: [5, 8, 4, 7, 6, 9],
        borderColor: premiumColors.primary,
        backgroundColor: premiumColors.primaryLight,
        borderWidth: 2,
        pointBackgroundColor: premiumColors.primary,
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
        tension: 0.4,
        fill: true,
      },
      {
        label: t("dashboard.charts.labEquipment"),
        data: [3, 5, 7, 4, 6, 3],
        borderColor: premiumColors.secondary,
        backgroundColor: premiumColors.secondaryLight,
        borderWidth: 2,
        pointBackgroundColor: premiumColors.secondary,
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
        tension: 0.4,
        fill: true,
      },
      {
        label: t("dashboard.charts.furniture"),
        data: [2, 4, 3, 6, 9, 5],
        borderColor: premiumColors.tertiary,
        backgroundColor: premiumColors.tertiaryLight,
        borderWidth: 2,
        pointBackgroundColor: premiumColors.tertiary,
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
        tension: 0.4,
        fill: true,
      },
    ],
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <h1 className="text-2xl font-bold font-kufi mb-2">
          {t("dashboard.welcome")}
        </h1>
        <p className="text-muted-foreground">{t("dashboard.subtitle")}</p>
      </motion.div>

      {/* KPI Cards Section */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
      >
        {isLoading ? (
          <>
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="p-6 h-full">
                <div className="flex justify-between items-start mb-4">
                  <Skeleton className="h-6 w-24" />
                  <Skeleton className="w-12 h-12 rounded-full" />
                </div>
                <Skeleton className="h-9 w-32 mb-2" />
                <Skeleton className="h-4 w-20" />
              </Card>
            ))}
          </>
        ) : (
          <>
            <KpiCard
              title={t("dashboard.kpi.totalInventory")}
              value={data?.inventory?.total ?? 842}
              change={{
                value: data?.inventory?.change?.value ?? 5.2,
                isPositive: data?.inventory?.change?.isPositive ?? true,
              }}
              subtitle={t("dashboard.kpi.items")}
              icon="ri-archive-line"
              iconColor="primary"
              index={0}
            />

            <KpiCard
              title={t("dashboard.kpi.pendingRequests")}
              value={data?.requests?.pending ?? 24}
              change={{ value: 12.3, isPositive: false }}
              subtitle={t("dashboard.kpi.awaitingApproval")}
              icon="ri-time-line"
              iconColor="warning"
              index={1}
            />

            <KpiCard
              title={t("dashboard.kpi.maintenanceTasks")}
              value={data?.maintenance?.total ?? 12}
              subtitle={`${data?.maintenance?.overdue ?? 3} ${t("dashboard.kpi.overdueTasks")}`}
              icon="ri-tools-line"
              iconColor="destructive"
              index={2}
            />
          </>
        )}
      </motion.div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {isLoading ? (
          <>
            {[1, 2].map((i) => (
              <Card key={i}>
                <CardHeader className="pb-2">
                  <Skeleton className="h-6 w-48" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-[300px] w-full" />
                </CardContent>
              </Card>
            ))}
          </>
        ) : (
          <>
            <ChartCard
              title={t("dashboard.charts.inventoryDistribution")}
              type="bar"
              data={inventoryChartData}
              index={0}
            />

            <ChartCard
              title={t("dashboard.charts.maintenanceFrequency")}
              type="line"
              data={maintenanceChartData}
              index={1}
            />
          </>
        )}
      </div>

      {/* Alerts Section */}
      <div className="space-y-6">
        <h2 className="font-kufi font-bold text-lg">
          {t("dashboard.alerts.title")}
        </h2>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-24 w-full" />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            <AlertItem
              title={t("dashboard.alerts.lowStock.title")}
              description={t("dashboard.alerts.lowStock.description")}
              type="error"
              actionLabel={t("dashboard.alerts.lowStock.action")}
              actionIcon="ri-shopping-cart-line"
              index={0}
            />

            <AlertItem
              title={t("dashboard.alerts.maintenanceOverdue.title")}
              description={t("dashboard.alerts.maintenanceOverdue.description")}
              type="warning"
              actionLabel={t("dashboard.alerts.maintenanceOverdue.action")}
              actionIcon="ri-calendar-check-line"
              index={1}
            />

            <AlertItem
              title={t("dashboard.alerts.newEquipment.title")}
              description={t("dashboard.alerts.newEquipment.description")}
              type="info"
              actionLabel={t("dashboard.alerts.newEquipment.action")}
              actionIcon="ri-eye-line"
              index={2}
            />
          </div>
        )}
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>{t("dashboard.recentActivity.title")}</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-start">
                  <Skeleton className="h-10 w-10 rounded-full mr-3" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {/* Activity Item */}
              <motion.div
                className="flex items-start"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
              >
                <div className="bg-green-100 text-green-600 rounded-full p-2 ml-3">
                  <i className="ri-checkbox-circle-line"></i>
                </div>
                <div className="flex-1">
                  <p className="text-gray-800">
                    <span className="font-medium">أحمد العلوي</span>
                    <span> {t("dashboard.recentActivity.distributed")}</span>
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {t("dashboard.recentActivity.twoHoursAgo")}
                  </p>
                </div>
              </motion.div>

              {/* Activity Item */}
              <motion.div
                className="flex items-start"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
              >
                <div className="bg-blue-100 text-blue-600 rounded-full p-2 ml-3">
                  <i className="ri-file-add-line"></i>
                </div>
                <div className="flex-1">
                  <p className="text-gray-800">
                    <span className="font-medium">سعيد المنصوري</span>
                    <span> {t("dashboard.recentActivity.requested")}</span>
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {t("dashboard.recentActivity.yesterday")}
                  </p>
                </div>
              </motion.div>

              {/* Activity Item */}
              <motion.div
                className="flex items-start"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
              >
                <div className="bg-yellow-100 text-yellow-600 rounded-full p-2 ml-3">
                  <i className="ri-tools-line"></i>
                </div>
                <div className="flex-1">
                  <p className="text-gray-800">
                    <span className="font-medium">
                      {t("dashboard.recentActivity.maintenance")}
                    </span>
                    <span> {t("dashboard.recentActivity.projectors")}</span>
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {t("dashboard.recentActivity.twoDaysAgo")}
                  </p>
                </div>
              </motion.div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
