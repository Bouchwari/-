import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { cn } from '../lib/utils';
import { 
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  TooltipProps,
  Sector
} from 'recharts';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "../components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { DateRange } from 'react-day-picker';
import { DatePickerWithRange } from '../components/ui/date-range-picker';
import { addMonths, subMonths } from 'date-fns';
import { Loader2 } from 'lucide-react';
import { Badge } from '../components/ui/badge';
import { useLanguageDirection } from '../hooks/use-language-direction';

// Define colors
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

// Define simple percent formatter for pie chart
const percentFormatter = (value: number) => `${(value * 100).toFixed(0)}%`;

export default function Reports() {
  const { t } = useTranslation();
  const { direction } = useLanguageDirection();
  const isRtl = direction === 'rtl';
  
  // State for tab and filters
  const [activeTab, setActiveTab] = useState<string>('inventory');
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subMonths(new Date(), 6),
    to: new Date()
  });
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(undefined);
  const [selectedDepartment, setSelectedDepartment] = useState<string | undefined>(undefined);
  
  // Fetch reports data
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/reports', activeTab, dateRange, selectedCategory, selectedDepartment],
    queryFn: async () => {
      // In a real app, we would pass these as query parameters
      return fetch('/api/reports').then(res => res.json());
    }
  });
  
  // Fetch departments for filter
  const { data: departmentsData } = useQuery({
    queryKey: ['/api/departments'],
    queryFn: async () => {
      return fetch('/api/departments').then(res => res.json());
    }
  });
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-10rem)]">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-10rem)]">
        <h3 className="text-xl font-medium mb-2">{t('common.error')}</h3>
        <p className="text-muted-foreground">{t('reports.errorMessage')}</p>
      </div>
    );
  }
  
  // Extract active data based on selected tab
  const activeData = data ? data[activeTab] : null;
  
  // Create category options based on active tab
  const getCategoryOptions = () => {
    switch (activeTab) {
      case 'inventory':
        return [
          { value: 'all', label: t('inventory.categories.all') },
          { value: 'books', label: t('inventory.categories.books') },
          { value: 'stationery', label: t('inventory.categories.stationery') },
          { value: 'laboratory', label: t('inventory.categories.laboratory') },
          { value: 'equipment', label: t('inventory.categories.equipment') },
          { value: 'furniture', label: t('inventory.categories.furniture') },
          { value: 'electronics', label: t('inventory.categories.electronics') },
        ];
      case 'maintenance':
        return [
          { value: 'all', label: t('maintenance.categories.all') },
          { value: 'computers', label: t('maintenance.categories.computers') },
          { value: 'labEquipment', label: t('maintenance.categories.labEquipment') },
          { value: 'furniture', label: t('maintenance.categories.furniture') },
          { value: 'facilities', label: t('maintenance.categories.facilities') },
        ];
      case 'distribution':
      case 'requests':
        return [];
      default:
        return [];
    }
  };
  
  // Custom tooltip formatter
  const CustomTooltip = ({ active, payload, label }: TooltipProps<any, any>) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background p-3 border border-border rounded-md shadow-md">
          <p className="font-medium">{`${label}`}</p>
          {payload.map((entry, index) => (
            <p key={`item-${index}`} style={{ color: entry.color }}>
              {`${entry.name}: ${entry.value}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-1">
        <h1 className="text-3xl font-bold tracking-tight">{t('reports.title')}</h1>
        <p className="text-muted-foreground">{t('reports.subtitle')}</p>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        {/* Filters and tabs */}
        <Card>
          <CardHeader className="pb-4">
            <CardTitle>{t('reports.filters.title')}</CardTitle>
            <CardDescription>{t('reports.filters.description')}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="w-full md:w-1/3">
                <label className="text-sm font-medium mb-1 block">{t('reports.filters.dateRange')}</label>
                <DatePickerWithRange
                  selected={dateRange}
                  onSelect={setDateRange}
                  className="w-full"
                />
              </div>
              
              {getCategoryOptions().length > 0 && (
                <div className="w-full md:w-1/3">
                  <label className="text-sm font-medium mb-1 block">{t('reports.filters.category')}</label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('reports.filters.categoryPlaceholder')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectLabel>{t('reports.filters.categories')}</SelectLabel>
                        {getCategoryOptions().map(option => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
              )}
              
              {(activeTab === 'distribution' || activeTab === 'requests') && (
                <div className="w-full md:w-1/3">
                  <label className="text-sm font-medium mb-1 block">{t('reports.filters.department')}</label>
                  <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('reports.filters.departmentPlaceholder')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectLabel>{t('reports.filters.departments')}</SelectLabel>
                        <SelectItem value="all">{t('reports.filters.allDepartments')}</SelectItem>
                        {departmentsData?.departments?.map((dept: any) => (
                          <SelectItem key={dept.id} value={dept.id}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
            
            <div className="mt-6">
              <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-4 w-full">
                  <TabsTrigger value="inventory">
                    {t('reports.tabs.inventory')}
                  </TabsTrigger>
                  <TabsTrigger value="distribution">
                    {t('reports.tabs.distribution')}
                  </TabsTrigger>
                  <TabsTrigger value="maintenance">
                    {t('reports.tabs.maintenance')}
                  </TabsTrigger>
                  <TabsTrigger value="requests">
                    {t('reports.tabs.requests')}
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>
        
        {/* Main report content */}
        {activeData && (
          <div className="space-y-6">
            {/* Summary cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {activeData.summary.map((item: any, index: number) => (
                <Card key={index} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      {t(`reports.${activeTab}.summary.${item.label}`)}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{item.value}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {/* Charts section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Bar chart */}
              <Card>
                <CardHeader>
                  <CardTitle>{t(`reports.${activeTab}.charts.byCategory`)}</CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart 
                      data={activeData.chartData}
                      layout={isRtl ? 'vertical' : 'horizontal'}
                      margin={isRtl 
                        ? { top: 5, right: 30, left: 30, bottom: 5 } 
                        : { top: 5, right: 30, left: 20, bottom: 5 }
                      }
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      {isRtl ? (
                        <>
                          <XAxis type="number" />
                          <YAxis 
                            dataKey="name" 
                            type="category" 
                            width={100} 
                            tick={{ fontSize: 12 }}
                          />
                        </>
                      ) : (
                        <>
                          <XAxis dataKey="name" />
                          <YAxis />
                        </>
                      )}
                      <Tooltip content={<CustomTooltip />} />
                      <Legend 
                        verticalAlign={isRtl ? "top" : "bottom"}
                        align={isRtl ? "right" : "center"}
                      />
                      <Bar dataKey="value" fill="#0088FE" name={t(`reports.${activeTab}.charts.value`)} />
                      {activeTab === 'inventory' && (
                        <Bar dataKey="usage" fill="#00C49F" name={t(`reports.${activeTab}.charts.usage`)} />
                      )}
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              {/* Pie chart */}
              <Card>
                <CardHeader>
                  <CardTitle>{t(`reports.${activeTab}.charts.distribution`)}</CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart margin={{ top: 20, right: 20, left: 20, bottom: 20 }}>
                      <Pie
                        data={activeData.pieData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        outerRadius={60}
                        innerRadius={0}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={false}
                      >
                        {activeData.pieData.map((entry: any, index: number) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomTooltip />} />
                      <Legend
                        verticalAlign="bottom"
                        align="center"
                        layout="horizontal"
                        wrapperStyle={{ 
                          paddingTop: 20,
                          fontSize: 12,
                          width: '90%',
                          margin: '0 auto'
                        }}
                        iconSize={10}
                        itemStyle={{
                          marginBottom: 5,
                          marginRight: 10
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              {/* Trend chart */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>{t(`reports.${activeTab}.charts.trend`)}</CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={activeData.trendData}
                      margin={isRtl 
                        ? { top: 5, right: 30, left: 30, bottom: 5 } 
                        : { top: 5, right: 30, left: 20, bottom: 5 }
                      }
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="name" 
                        tick={{ fontSize: 12 }}
                      />
                      <YAxis 
                        width={isRtl ? 60 : 40}
                        tick={{ fontSize: 12 }}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend 
                        verticalAlign={isRtl ? "top" : "bottom"}
                        align={isRtl ? "right" : "center"}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#0088FE" 
                        activeDot={{ r: 8 }}
                        name={t(`reports.${activeTab}.charts.value`)}
                      />
                      {activeTab === 'inventory' && (
                        <Line 
                          type="monotone" 
                          dataKey="demand" 
                          stroke="#FF8042" 
                          name={t(`reports.${activeTab}.charts.demand`)}
                        />
                      )}
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
            
            {/* Top items and insights */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Top items */}
              <Card>
                <CardHeader>
                  <CardTitle>{t(`reports.${activeTab}.topItems.title`)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {activeData.topItems.map((item: any, index: number) => (
                      <li key={index} className="flex items-center justify-between">
                        <div className="flex items-center">
                          <span className={cn(
                            "h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium",
                            isRtl ? "ml-3" : "mr-3"
                          )}>
                            {index + 1}
                          </span>
                          <span>{item.name}</span>
                        </div>
                        <Badge variant="outline">{item.value}</Badge>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
              
              {/* Insights */}
              <Card>
                <CardHeader>
                  <CardTitle>{t(`reports.${activeTab}.insights.title`)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {activeData.insights.map((insight: string, index: number) => (
                      <li key={index} className="flex items-start">
                        <span className={cn(
                          "h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0 mt-0.5",
                          isRtl ? "ml-3" : "mr-3"
                        )}>
                          <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-4 w-4">
                            <path d="M7.5 0.875C5.49797 0.875 3.57907 1.66983 2.16853 3.08036C0.757998 4.4909 0 6.43528 0 8.4375C0 10.4397 0.757998 12.3841 2.16853 13.7946C3.57907 15.2052 5.49797 16 7.5 16C9.50203 16 11.4209 15.2052 12.8315 13.7946C14.242 12.3841 15 10.4397 15 8.4375C15 6.43528 14.242 4.4909 12.8315 3.08036C11.4209 1.66983 9.50203 0.875 7.5 0.875ZM6.79688 11.5625L3.67188 8.4375L4.76562 7.34375L6.79688 9.375L10.8594 5.3125L11.9531 6.40625L6.79688 11.5625Z" fill="currentColor" />
                          </svg>
                        </span>
                        <span className="flex-1">{insight}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}