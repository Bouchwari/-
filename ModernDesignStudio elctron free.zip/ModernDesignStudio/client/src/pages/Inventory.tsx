import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { DataTable } from '@/components/ui/data-table';
import { Button } from '@/components/ui/button';
import { Search, Plus, FileDown, Printer, Barcode, QrCode, Check } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useQuery, useMutation } from '@tanstack/react-query';
import { getQueryFn, apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { ItemStatus, ItemClassification, InventoryItem } from '@/types';

// Form schema with Zod
const addItemFormSchema = z.object({
  name: z.string().min(2, { message: "Item name must be at least 2 characters" }),
  serialNumber: z.string().min(4, { message: "Serial number must be at least 4 characters" }),
  inventoryNumber: z.string().min(3, { message: "Inventory number is required" }),
  classification: z.enum(['A', 'B', 'C', 'D', 'E', 'I'] as const),
  category: z.string().min(1, { message: "Please select a category" }),
  location: z.string().min(1, { message: "Location is required" }),
  status: z.enum(['new', 'fair', 'worn', 'maintenance', 'low-stock'] as const),
  quantity: z.number().min(1, { message: "Quantity must be at least 1" }),
});

type ItemFormValues = z.infer<typeof addItemFormSchema>;

export default function Inventory() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [addItemOpen, setAddItemOpen] = useState(false);
  const [formStep, setFormStep] = useState(0);
  
  // Form setup
  const form = useForm<ItemFormValues>({
    resolver: zodResolver(addItemFormSchema),
    defaultValues: {
      name: '',
      serialNumber: '',
      inventoryNumber: '',
      classification: 'A',
      category: 'furniture',
      location: '',
      status: 'new',
      quantity: 1,
    },
  });
  
  // Add item mutation
  const addItemMutation = useMutation({
    mutationFn: async (data: ItemFormValues) => {
      const response = await apiRequest('/api/inventory', {
        method: 'POST',
        body: JSON.stringify(data),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      setAddItemOpen(false);
      form.reset();
      toast({
        title: t('inventory.itemAdded'),
        description: t('inventory.itemAddedDescription'),
      });
    },
    onError: (error: any) => {
      toast({
        title: t('errors.addFailed'),
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Form submit handler
  const onSubmit = (data: ItemFormValues) => {
    addItemMutation.mutate(data);
  };
  
  // Fetch inventory data
  const { data, isLoading, error } = useQuery<{ items: InventoryItem[] }>({
    queryKey: ['/api/inventory'],
    queryFn: getQueryFn({ on401: 'throw' }),
  });
  
  if (error) {
    toast({
      title: t('errors.loadFailed'),
      description: error.message,
      variant: 'destructive',
    });
  }
  
  // Filter data based on selected category
  const filteredData = selectedCategory === 'all' 
    ? data?.items 
    : data?.items?.filter((item: InventoryItem) => item.category === selectedCategory);
  
  // Status badge styling
  const getStatusBadge = (status: ItemStatus) => {
    type BadgeVariant = "default" | "destructive" | "outline" | "secondary";
    
    const statusMap: Record<ItemStatus, { variant: BadgeVariant, label: string }> = {
      new: { variant: "secondary", label: t('inventory.status.new') },
      fair: { variant: "secondary", label: t('inventory.status.fair') },
      worn: { variant: "outline", label: t('inventory.status.worn') },
      maintenance: { variant: "default", label: t('inventory.status.maintenance') },
      "low-stock": { variant: "destructive", label: t('inventory.status.lowStock') },
    };
    
    const config = statusMap[status] || { variant: "outline" as BadgeVariant, label: status };
    
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };
  
  // Table columns
  const columns = [
    {
      header: t('inventory.table.item'),
      accessorKey: 'name',
      cell: (item: InventoryItem) => (
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center mr-3">
            <i className={`ri-${item.icon || 'archive-line'} text-xl`}></i>
          </div>
          <div>
            <div className="font-medium">{item.name}</div>
            <div className="text-sm text-muted-foreground">SKU-{item.id}</div>
          </div>
        </div>
      ),
    },
    {
      header: t('inventory.table.category'),
      accessorKey: 'category',
    },
    {
      header: t('inventory.table.location'),
      accessorKey: 'location',
    },
    {
      header: t('inventory.table.status'),
      accessorKey: 'status',
      cell: (item: InventoryItem) => getStatusBadge(item.status),
    },
    {
      header: t('inventory.table.quantity'),
      accessorKey: 'quantity',
    },
    {
      header: t('inventory.table.lastUpdated'),
      accessorKey: 'lastUpdated',
      cell: (item: InventoryItem) => (
        <span className="text-muted-foreground">{item.lastUpdated}</span>
      ),
    },
    {
      header: t('inventory.table.actions'),
      accessorKey: 'actions',
      cell: (item: InventoryItem) => (
        <div className="flex space-x-2 rtl:space-x-reverse">
          <Button size="icon" variant="ghost">
            <i className="ri-edit-line text-primary"></i>
          </Button>
          <Button size="icon" variant="ghost">
            <i className="ri-delete-bin-line text-destructive"></i>
          </Button>
        </div>
      ),
    },
  ];
  
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-2xl font-bold font-kufi mb-2">{t('inventory.title')}</h1>
        <p className="text-muted-foreground">{t('inventory.subtitle')}</p>
      </motion.div>
      
      {/* Filters and actions */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="flex flex-wrap justify-between items-center gap-4"
      >
        <div className="flex flex-wrap gap-2">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <input
              type="text"
              placeholder={t('inventory.search')}
              className="pl-10 pr-4 py-2 w-full border rounded-md"
            />
          </div>
          
          <Select
            value={selectedCategory}
            onValueChange={setSelectedCategory}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder={t('inventory.filter.allCategories')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('inventory.filter.allCategories')}</SelectItem>
              <SelectItem value="furniture">{t('inventory.filter.furniture')}</SelectItem>
              <SelectItem value="technology">{t('inventory.filter.technology')}</SelectItem>
              <SelectItem value="supplies">{t('inventory.filter.supplies')}</SelectItem>
              <SelectItem value="books">{t('inventory.filter.books')}</SelectItem>
              <SelectItem value="sports">{t('inventory.filter.sports')}</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <FileDown className="mr-2 h-4 w-4" />
            {t('common.export')}
          </Button>
          <Button variant="outline" size="sm">
            <Printer className="mr-2 h-4 w-4" />
            {t('common.print')}
          </Button>
          <Dialog open={addItemOpen} onOpenChange={setAddItemOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" />
                {t('inventory.addItem')}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t('inventory.addNewItem')}</DialogTitle>
                <DialogDescription>
                  {t('inventory.addItemDescription')}
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Item Name */}
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('inventory.form.name')}</FormLabel>
                          <FormControl>
                            <Input placeholder={t('inventory.form.namePlaceholder')} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Serial Number */}
                    <FormField
                      control={form.control}
                      name="serialNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('inventory.form.serialNumber')}</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input 
                                placeholder={t('inventory.form.serialNumberPlaceholder')} 
                                {...field} 
                              />
                              <Barcode className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Inventory Number */}
                    <FormField
                      control={form.control}
                      name="inventoryNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('inventory.form.inventoryNumber')}</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input 
                                placeholder={t('inventory.form.inventoryNumberPlaceholder')} 
                                {...field} 
                              />
                              <QrCode className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Classification */}
                    <FormField
                      control={form.control}
                      name="classification"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('inventory.form.classification')}</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t('inventory.form.selectClassification')} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="A">{t('inventory.classification.A')}</SelectItem>
                              <SelectItem value="B">{t('inventory.classification.B')}</SelectItem>
                              <SelectItem value="C">{t('inventory.classification.C')}</SelectItem>
                              <SelectItem value="D">{t('inventory.classification.D')}</SelectItem>
                              <SelectItem value="E">{t('inventory.classification.E')}</SelectItem>
                              <SelectItem value="I">{t('inventory.classification.I')}</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Category */}
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('inventory.form.category')}</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t('inventory.form.selectCategory')} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="furniture">{t('inventory.filter.furniture')}</SelectItem>
                              <SelectItem value="technology">{t('inventory.filter.technology')}</SelectItem>
                              <SelectItem value="supplies">{t('inventory.filter.supplies')}</SelectItem>
                              <SelectItem value="books">{t('inventory.filter.books')}</SelectItem>
                              <SelectItem value="sports">{t('inventory.filter.sports')}</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Location */}
                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('inventory.form.location')}</FormLabel>
                          <FormControl>
                            <Input placeholder={t('inventory.form.locationPlaceholder')} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Status */}
                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('inventory.form.status')}</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={t('inventory.form.selectStatus')} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="new">{t('inventory.status.new')}</SelectItem>
                              <SelectItem value="fair">{t('inventory.status.fair')}</SelectItem>
                              <SelectItem value="worn">{t('inventory.status.worn')}</SelectItem>
                              <SelectItem value="maintenance">{t('inventory.status.maintenance')}</SelectItem>
                              <SelectItem value="low-stock">{t('inventory.status.lowStock')}</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Quantity */}
                    <FormField
                      control={form.control}
                      name="quantity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('inventory.form.quantity')}</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="1"
                              placeholder="1" 
                              {...field}
                              onChange={(e) => {
                                field.onChange(parseInt(e.target.value) || 1);
                              }}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setAddItemOpen(false)} type="button">
                      {t('common.cancel')}
                    </Button>
                    <Button type="submit" disabled={addItemMutation.isPending}>
                      {addItemMutation.isPending ? (
                        <div className="flex items-center">
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          {t('common.saving')}
                        </div>
                      ) : (
                        t('common.save')
                      )}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </motion.div>
      
      {/* Inventory table */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-96 w-full" />
          </div>
        ) : (
          <DataTable
            data={filteredData || []}
            columns={columns}
            searchPlaceholder={t('inventory.search')}
            searchKey="name"
            pagination
            rowsPerPage={10}
          />
        )}
      </motion.div>
    </div>
  );
}
