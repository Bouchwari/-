import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { useQuery } from '@tanstack/react-query';
import { getQueryFn, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { CalendarIcon, Plus } from 'lucide-react';
import { MaintenanceTask, MaintenanceStatus } from '@/types';

// Define schema for maintenance task form
const maintenanceFormSchema = z.object({
  itemId: z.string().min(1, { message: "Item is required" }),
  description: z.string().min(5, { message: "Description must be at least 5 characters" }),
  date: z.date({ required_error: "Date is required" }),
  priority: z.enum(['low', 'medium', 'high'], { required_error: "Priority is required" }),
});

type MaintenanceFormValues = z.infer<typeof maintenanceFormSchema>;

interface MaintenanceTimelineItemProps {
  task: MaintenanceTask;
  index: number;
}

function MaintenanceTimelineItem({ task, index }: MaintenanceTimelineItemProps) {
  const { t } = useTranslation();
  
  const statusIconMap: Record<MaintenanceStatus, string> = {
    completed: 'ri-checkbox-circle-line',
    inprogress: 'ri-time-line',
    pending: 'ri-calendar-line',
    overdue: 'ri-error-warning-line',
  };
  
  const statusColorMap: Record<MaintenanceStatus, string> = {
    completed: 'bg-green-500 text-white',
    inprogress: 'bg-yellow-500 text-white',
    pending: 'bg-gray-300 text-gray-700',
    overdue: 'bg-red-500 text-white',
  };

  return (
    <motion.div
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.1 * index }}
      className="relative flex items-start mb-6"
    >
      <div className={`flex items-center justify-center h-8 w-8 rounded-full z-10 mr-4 ${statusColorMap[task.status]}`}>
        <i className={`${statusIconMap[task.status]} text-sm`}></i>
      </div>
      <div className="bg-muted rounded-lg p-3 w-full">
        <div className="flex justify-between">
          <h5 className="font-kufi font-medium text-sm">{task.title}</h5>
          <span className="text-xs text-muted-foreground">{task.date}</span>
        </div>
        <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
        <div className="mt-2">
          <Badge variant={task.status === 'completed' ? 'success' : 
                          task.status === 'overdue' ? 'destructive' :
                          task.status === 'inprogress' ? 'default' : 'outline'}>
            {t(`maintenance.status.${task.status}`)}
          </Badge>
        </div>
      </div>
    </motion.div>
  );
}

export default function Maintenance() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [addTaskOpen, setAddTaskOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  
  // Form setup
  const form = useForm<MaintenanceFormValues>({
    resolver: zodResolver(maintenanceFormSchema),
    defaultValues: {
      description: '',
      date: new Date(),
      priority: 'medium',
    },
  });
  
  // Fetch maintenance data
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/maintenance'],
    queryFn: getQueryFn({ on401: 'throw' }),
  });
  
  // Fetch inventory items for the maintenance form
  const { data: inventoryData } = useQuery({
    queryKey: ['/api/inventory'],
    queryFn: getQueryFn({ on401: 'throw' }),
  });
  
  // Handle errors in useEffect to avoid re-render loop
  useEffect(() => {
    if (error) {
      toast({
        title: t('errors.loadFailed'),
        description: error.message,
        variant: 'destructive',
      });
    }
  }, [error, toast, t]);
  
  // Handle form submission
  const onSubmit = async (formData: MaintenanceFormValues) => {
    try {
      await apiRequest('POST', '/api/maintenance', formData);
      
      form.reset({
        itemId: '',
        description: '',
        date: new Date(),
        priority: 'medium',
      });
      
      setAddTaskOpen(false);
      
      toast({
        title: t('maintenance.taskAdded'),
        description: t('maintenance.taskAddedDescription'),
      });
    } catch (error) {
      toast({
        title: t('errors.submissionFailed'),
        description: error instanceof Error ? error.message : String(error),
        variant: 'destructive',
      });
    }
  };
  
  // Prepare calendar data
  const calendarTasks = data?.tasks?.reduce((acc: Record<string, MaintenanceTask[]>, task: MaintenanceTask) => {
    const dateStr = new Date(task.dateRaw).toISOString().split('T')[0];
    if (!acc[dateStr]) {
      acc[dateStr] = [];
    }
    acc[dateStr].push(task);
    return acc;
  }, {});
  
  // Get tasks for selected date
  const selectedDateStr = selectedDate?.toISOString().split('T')[0];
  const tasksForSelectedDate = selectedDateStr && calendarTasks ? calendarTasks[selectedDateStr] || [] : [];
  
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="flex flex-wrap justify-between items-center"
      >
        <div>
          <h1 className="text-2xl font-bold font-kufi mb-2">{t('maintenance.title')}</h1>
          <p className="text-muted-foreground">{t('maintenance.subtitle')}</p>
        </div>
        <Dialog open={addTaskOpen} onOpenChange={setAddTaskOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              {t('maintenance.addTask')}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{t('maintenance.addNewTask')}</DialogTitle>
              <DialogDescription>
                {t('maintenance.addTaskDescription')}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="itemId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('maintenance.form.item')}</FormLabel>
                      <Select 
                        value={field.value} 
                        onValueChange={field.onChange}
                        disabled={isLoading}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder={t('maintenance.form.selectItem')} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {inventoryData?.items?.map((item: any) => (
                            <SelectItem key={item.id} value={item.id}>
                              {item.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('maintenance.form.description')}</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder={t('maintenance.form.descriptionPlaceholder')}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('maintenance.form.date')}</FormLabel>
                        <FormControl>
                          <div className="flex">
                            <Input 
                              type="date" 
                              value={field.value ? field.value.toISOString().split('T')[0] : ''}
                              onChange={(e) => {
                                const date = e.target.value ? new Date(e.target.value) : undefined;
                                if (date) {
                                  field.onChange(date);
                                }
                              }}
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="icon"
                              className="ml-2"
                            >
                              <CalendarIcon className="h-4 w-4" />
                            </Button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="priority"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('maintenance.form.priority')}</FormLabel>
                        <Select 
                          value={field.value} 
                          onValueChange={field.onChange}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder={t('maintenance.form.selectPriority')} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="low">{t('maintenance.form.priorities.low')}</SelectItem>
                            <SelectItem value="medium">{t('maintenance.form.priorities.medium')}</SelectItem>
                            <SelectItem value="high">{t('maintenance.form.priorities.high')}</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <DialogFooter>
                  <Button 
                    variant="outline" 
                    type="button" 
                    onClick={() => setAddTaskOpen(false)}
                  >
                    {t('common.cancel')}
                  </Button>
                  <Button type="submit">{t('maintenance.form.saveTask')}</Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </motion.div>
      
      {/* Calendar and timeline grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="lg:col-span-2"
        >
          <Card>
            <CardHeader className="flex-row justify-between items-center pb-2">
              <CardTitle>{t('maintenance.schedule')}</CardTitle>
              <div className="text-sm text-muted-foreground">
                {selectedDate?.toLocaleString(undefined, { month: 'long', year: 'numeric' })}
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-96 w-full" />
              ) : (
                <>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    className="rounded-md border"
                    components={{
                      DayContent: (props) => {
                        const dateStr = props.date.toISOString().split('T')[0];
                        const hasTasks = calendarTasks && calendarTasks[dateStr];
                        
                        return (
                          <div className="relative w-full h-full flex items-center justify-center">
                            {props.day}
                            {hasTasks && (
                              <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2">
                                <div className="flex space-x-0.5">
                                  {hasTasks.length > 0 && (
                                    <div 
                                      className={`h-1.5 w-1.5 rounded-full ${
                                        hasTasks.some(t => t.status === 'overdue') ? 'bg-red-500' :
                                        hasTasks.some(t => t.status === 'inprogress') ? 'bg-yellow-500' :
                                        hasTasks.some(t => t.status === 'pending') ? 'bg-blue-500' : 'bg-green-500'
                                      }`}
                                    ></div>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      }
                    }}
                  />
                  
                  {tasksForSelectedDate.length > 0 && (
                    <div className="mt-4 space-y-3">
                      <h3 className="font-medium">{t('maintenance.tasksForDate')}</h3>
                      {tasksForSelectedDate.map((task, i) => (
                        <div 
                          key={i} 
                          className={`p-3 rounded-md border-l-4 ${
                            task.status === 'completed' ? 'border-green-500 bg-green-50' :
                            task.status === 'overdue' ? 'border-red-500 bg-red-50' :
                            task.status === 'inprogress' ? 'border-yellow-500 bg-yellow-50' :
                            'border-blue-500 bg-blue-50'
                          }`}
                        >
                          <div className="flex justify-between">
                            <h4 className="font-medium">{task.title}</h4>
                            <Badge variant={
                              task.status === 'completed' ? 'success' : 
                              task.status === 'overdue' ? 'destructive' :
                              task.status === 'inprogress' ? 'default' : 'outline'
                            }>
                              {t(`maintenance.status.${task.status}`)}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>
        
        {/* Maintenance Timeline */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="h-[calc(100vh-14rem)] flex flex-col">
            <CardHeader className="pb-2">
              <CardTitle>{t('maintenance.timeline')}</CardTitle>
            </CardHeader>
            <CardContent className="overflow-y-auto flex-1 relative">
              <div className="absolute inset-y-0 right-5 w-0.5 bg-muted"></div>
              
              {isLoading ? (
                <div className="space-y-6">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="relative flex items-start mb-6">
                      <Skeleton className="h-8 w-8 rounded-full mr-4" />
                      <div className="w-full">
                        <Skeleton className="h-24 w-full rounded-md" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                data?.timeline?.map((task: MaintenanceTask, index: number) => (
                  <MaintenanceTimelineItem key={task.id} task={task} index={index} />
                ))
              )}
            </CardContent>
            <div className="p-4 border-t">
              <Button 
                className="w-full"
                onClick={() => setAddTaskOpen(true)}
              >
                <Plus className="mr-2 h-4 w-4" />
                {t('maintenance.addNewTask')}
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
