import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { DataTable } from '@/components/ui/data-table';
import { useQuery } from '@tanstack/react-query';
import { getQueryFn, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { MaterialRequest, RequestStatus } from '@/types';
import { FileDown, Printer, Plus } from 'lucide-react';

// Form schema
const requestFormSchema = z.object({
  teacherId: z.string().min(1, { message: "Teacher is required" }),
  department: z.string().min(1, { message: "Department is required" }),
  date: z.string().min(1, { message: "Date is required" }),
  source: z.string().min(1, { message: "Source is required" }),
  items: z.array(z.object({
    itemId: z.string().min(1, { message: "Item is required" }),
    quantity: z.number().min(1, { message: "Quantity must be at least 1" }),
    notes: z.string().optional(),
  })).min(1, { message: "At least one item is required" }),
});

type RequestFormValues = z.infer<typeof requestFormSchema>;

export default function Requests() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('new');
  
  // Form setup
  const form = useForm<RequestFormValues>({
    resolver: zodResolver(requestFormSchema),
    defaultValues: {
      teacherId: '',
      department: '',
      date: new Date().toISOString().substring(0, 10),
      source: '',
      items: [{ itemId: '', quantity: 1, notes: '' }],
    },
  });
  
  // Fetch request data and options
  const { data: requestsData, isLoading: loadingRequests } = useQuery({
    queryKey: ['/api/requests'],
    queryFn: getQueryFn({ on401: 'throw' }),
  });
  
  const { data: optionsData, isLoading: loadingOptions } = useQuery({
    queryKey: ['/api/request-options'],
    queryFn: getQueryFn({ on401: 'throw' }),
  });
  
  // Add new item to form
  const addItem = () => {
    const items = form.getValues('items');
    form.setValue('items', [...items, { itemId: '', quantity: 1, notes: '' }]);
  };
  
  // Remove item from form
  const removeItem = (index: number) => {
    const items = form.getValues('items');
    if (items.length > 1) {
      form.setValue('items', items.filter((_, i) => i !== index));
    }
  };
  
  // Handle form submission
  const onSubmit = async (data: RequestFormValues) => {
    try {
      await apiRequest('POST', '/api/requests', data);
      
      // Reset form and show success message
      form.reset({
        teacherId: '',
        department: '',
        date: new Date().toISOString().substring(0, 10),
        source: '',
        items: [{ itemId: '', quantity: 1, notes: '' }],
      });
      
      toast({
        title: t('requests.requestSubmitted'),
        description: t('requests.requestSubmittedDescription'),
      });
      
      // Switch to history tab
      setActiveTab('history');
    } catch (error) {
      toast({
        title: t('errors.submissionFailed'),
        description: error instanceof Error ? error.message : String(error),
        variant: 'destructive',
      });
    }
  };
  
  // Status badge styling
  const getStatusBadge = (status: RequestStatus) => {
    const statusMap: Record<RequestStatus, { variant: "default" | "destructive" | "outline" | "secondary" | "success", label: string }> = {
      pending: { variant: "default", label: t('requests.status.pending') },
      approved: { variant: "success", label: t('requests.status.approved') },
      delivered: { variant: "success", label: t('requests.status.delivered') },
      rejected: { variant: "destructive", label: t('requests.status.rejected') },
      processing: { variant: "secondary", label: t('requests.status.processing') },
    };
    
    const config = statusMap[status] || { variant: "outline", label: status };
    
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };
  
  // Table columns
  const columns = [
    {
      header: t('requests.table.requestId'),
      accessorKey: 'id',
      cell: (request: MaterialRequest) => (
        <span className="font-medium">REQ-{request.id}</span>
      ),
    },
    {
      header: t('requests.table.teacher'),
      accessorKey: 'teacherName',
    },
    {
      header: t('requests.table.department'),
      accessorKey: 'department',
    },
    {
      header: t('requests.table.date'),
      accessorKey: 'date',
    },
    {
      header: t('requests.table.items'),
      accessorKey: 'items',
      cell: (request: MaterialRequest) => (
        <div className="flex flex-wrap gap-1">
          {request.items.map((item, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {item.name} ({item.quantity})
            </Badge>
          ))}
        </div>
      ),
    },
    {
      header: t('requests.table.status'),
      accessorKey: 'status',
      cell: (request: MaterialRequest) => getStatusBadge(request.status),
    },
    {
      header: t('requests.table.actions'),
      accessorKey: 'actions',
      cell: (request: MaterialRequest) => (
        <div className="flex space-x-2 rtl:space-x-reverse">
          <Button size="icon" variant="ghost">
            <i className="ri-eye-line text-primary"></i>
          </Button>
          <Button size="icon" variant="ghost">
            <i className="ri-printer-line text-gray-500"></i>
          </Button>
        </div>
      ),
    },
  ];
  
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-2xl font-bold font-kufi mb-2">{t('requests.title')}</h1>
        <p className="text-muted-foreground">{t('requests.subtitle')}</p>
      </motion.div>
      
      <Tabs defaultValue="new" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-2 w-[400px]">
          <TabsTrigger value="new">{t('requests.tabs.newRequest')}</TabsTrigger>
          <TabsTrigger value="history">{t('requests.tabs.requestHistory')}</TabsTrigger>
        </TabsList>
        
        <TabsContent value="new" className="mt-6">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>{t('requests.newRequestForm')}</CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Teacher selection */}
                      <FormField
                        control={form.control}
                        name="teacherId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t('requests.form.teacher')}</FormLabel>
                            <Select
                              value={field.value}
                              onValueChange={field.onChange}
                              disabled={loadingOptions}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder={t('requests.form.selectTeacher')} />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {loadingOptions ? (
                                  <SelectItem value="loading" disabled>
                                    {t('common.loading')}
                                  </SelectItem>
                                ) : (
                                  optionsData?.teachers?.map((teacher: any) => (
                                    <SelectItem key={teacher.id} value={teacher.id}>
                                      {teacher.name}
                                    </SelectItem>
                                  ))
                                )}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {/* Department selection */}
                      <FormField
                        control={form.control}
                        name="department"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t('requests.form.department')}</FormLabel>
                            <Select
                              value={field.value}
                              onValueChange={field.onChange}
                              disabled={loadingOptions}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder={t('requests.form.selectDepartment')} />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {loadingOptions ? (
                                  <SelectItem value="loading" disabled>
                                    {t('common.loading')}
                                  </SelectItem>
                                ) : (
                                  optionsData?.departments?.map((department: any) => (
                                    <SelectItem key={department.id} value={department.id}>
                                      {department.name}
                                    </SelectItem>
                                  ))
                                )}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {/* Date selection */}
                      <FormField
                        control={form.control}
                        name="date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t('requests.form.date')}</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {/* Source selection */}
                      <FormField
                        control={form.control}
                        name="source"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t('requests.form.source')}</FormLabel>
                            <Select
                              value={field.value}
                              onValueChange={field.onChange}
                              disabled={loadingOptions}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder={t('requests.form.selectSource')} />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="academy">{t('requests.form.sources.academy')}</SelectItem>
                                <SelectItem value="local">{t('requests.form.sources.local')}</SelectItem>
                                <SelectItem value="parents">{t('requests.form.sources.parents')}</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    {/* Requested items */}
                    <div>
                      <h3 className="font-medium mb-2">{t('requests.form.requestedItems')}</h3>
                      <div className="border rounded-md p-4">
                        <div className="grid grid-cols-8 gap-4 mb-2 text-sm font-medium">
                          <div className="col-span-3">{t('requests.form.itemName')}</div>
                          <div className="col-span-1">{t('requests.form.quantity')}</div>
                          <div className="col-span-3">{t('requests.form.notes')}</div>
                          <div className="col-span-1"></div>
                        </div>
                        
                        {form.getValues('items').map((_, index) => (
                          <div key={index} className="grid grid-cols-8 gap-4 mb-4 items-center">
                            <div className="col-span-3">
                              <Controller
                                control={form.control}
                                name={`items.${index}.itemId`}
                                render={({ field }) => (
                                  <Select
                                    value={field.value}
                                    onValueChange={field.onChange}
                                    disabled={loadingOptions}
                                  >
                                    <SelectTrigger>
                                      <SelectValue placeholder={t('requests.form.selectItem')} />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {loadingOptions ? (
                                        <SelectItem value="loading" disabled>
                                          {t('common.loading')}
                                        </SelectItem>
                                      ) : (
                                        optionsData?.items?.map((item: any) => (
                                          <SelectItem key={item.id} value={item.id}>
                                            {item.name}
                                          </SelectItem>
                                        ))
                                      )}
                                    </SelectContent>
                                  </Select>
                                )}
                              />
                            </div>
                            <div className="col-span-1">
                              <Controller
                                control={form.control}
                                name={`items.${index}.quantity`}
                                render={({ field }) => (
                                  <Input
                                    type="number"
                                    min="1"
                                    {...field}
                                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                                  />
                                )}
                              />
                            </div>
                            <div className="col-span-3">
                              <Controller
                                control={form.control}
                                name={`items.${index}.notes`}
                                render={({ field }) => (
                                  <Input
                                    placeholder={t('requests.form.notesPlaceholder')}
                                    {...field}
                                  />
                                )}
                              />
                            </div>
                            <div className="col-span-1 text-center">
                              <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm"
                                onClick={() => removeItem(index)}
                                disabled={form.getValues('items').length <= 1}
                              >
                                <i className="ri-delete-bin-line text-destructive"></i>
                              </Button>
                            </div>
                          </div>
                        ))}
                        
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={addItem}
                          className="mt-2"
                        >
                          <Plus className="mr-2 h-4 w-4" />
                          {t('requests.form.addItem')}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex justify-end space-x-2 rtl:space-x-reverse">
                      <Button variant="outline" type="button" onClick={() => form.reset()}>
                        {t('common.cancel')}
                      </Button>
                      <Button type="submit">
                        {t('requests.form.saveRequest')}
                      </Button>
                      <Button type="button" variant="secondary">
                        <Printer className="mr-2 h-4 w-4" />
                        {t('requests.form.print')}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
        
        <TabsContent value="history" className="mt-6">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex justify-end mb-4 space-x-2 rtl:space-x-reverse">
              <Button variant="outline" size="sm">
                <FileDown className="mr-2 h-4 w-4" />
                {t('common.export')}
              </Button>
              <Button variant="outline" size="sm">
                <Printer className="mr-2 h-4 w-4" />
                {t('common.print')}
              </Button>
            </div>
            
            {loadingRequests ? (
              <div className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-96 w-full" />
              </div>
            ) : (
              <DataTable
                data={requestsData?.requests || []}
                columns={columns}
                searchPlaceholder={t('requests.search')}
                searchKey="teacherName"
                pagination
                rowsPerPage={10}
              />
            )}
          </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
