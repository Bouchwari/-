import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileDown, Printer, Plus } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { getQueryFn, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { useAnimation } from '@/hooks/use-animation';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Teacher, DistributedItem } from '@/types';

interface TeacherCardProps {
  teacher: Teacher;
  index: number;
  onAddItems: (teacherId: string) => void;
  onPrintReceipt: (teacherId: string) => void;
}

function TeacherCard({ teacher, index, onAddItems, onPrintReceipt }: TeacherCardProps) {
  const { t } = useTranslation();
  const animation = useAnimation({
    animation: 'scaleUp',
    delay: 0.1 * index,
    duration: 500
  });
  
  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.1 * index }}
    >
      <Card className="h-full">
        <CardHeader className="pb-2 border-b">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium mr-3">
                <span>{teacher.name.substring(0, 2)}</span>
              </div>
              <div>
                <h3 className="font-kufi font-semibold">{teacher.name}</h3>
                <p className="text-sm text-muted-foreground">{teacher.department}</p>
              </div>
            </div>
            <div className="flex">
              <i className="ri-truck-line text-secondary"></i>
              <Badge className="ml-1 -mt-1 bg-primary/20 text-primary">
                {teacher.items.length}
              </Badge>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="pt-4">
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <h4 className="font-kufi font-medium text-sm">{t('distribution.suppliesGiven')}</h4>
              <Button variant="link" size="sm" className="h-auto p-0">
                {t('common.viewAll')}
              </Button>
            </div>
            
            <div className="space-y-2">
              {teacher.items.length === 0 ? (
                <p className="text-sm text-muted-foreground py-2">
                  {t('distribution.noItems')}
                </p>
              ) : (
                teacher.items.map((item, idx) => (
                  <div 
                    key={idx} 
                    className="flex justify-between items-center p-2 bg-muted rounded-md"
                  >
                    <div className="flex items-center">
                      <i className="ri-archive-line text-muted-foreground mr-2 text-sm"></i>
                      <span className="text-sm">{item.name}</span>
                    </div>
                    <span className="text-sm font-medium">{item.quantity}</span>
                  </div>
                ))
              )}
            </div>
          </div>
          
          <div className="flex justify-between">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => onAddItems(teacher.id)}
              className="flex items-center"
            >
              <i className="ri-add-line mr-1 text-sm"></i>
              <span>{t('distribution.addSupplies')}</span>
            </Button>
            
            <Button 
              variant="secondary" 
              size="sm"
              onClick={() => onPrintReceipt(teacher.id)}
              className="flex items-center"
              disabled={teacher.items.length === 0}
            >
              <i className="ri-receipt-line mr-1 text-sm"></i>
              <span>{t('distribution.printReceipt')}</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function Distribution() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [selectedDepartment, setSelectedDepartment] = useState<string>('all');
  const [selectedTeacherId, setSelectedTeacherId] = useState<string>('');
  const [isAddItemsOpen, setIsAddItemsOpen] = useState(false);
  
  type DistributionData = {
    teachers: Teacher[];
    departments: { id: string; name: string }[];
    summary: {
      teacherCount: number;
      totalItems: number;
      emptyTeacherCount: number;
    };
  };
  
  type InventoryData = {
    items: {
      id: string;
      name: string;
      quantity: number;
      category: string;
      status: string;
    }[];
  };
  
  // Fetch distribution data
  const { data, isLoading, error } = useQuery<DistributionData>({
    queryKey: ['/api/distribution'],
    queryFn: getQueryFn({ on401: 'throw' }),
  });
  
  // Fetch inventory items for distribution dialog
  const { data: inventoryData } = useQuery<InventoryData>({
    queryKey: ['/api/inventory/available'],
    queryFn: getQueryFn({ on401: 'throw' }),
  });
  
  // Filter teachers based on selected department
  const filteredTeachers = selectedDepartment === 'all'
    ? data?.teachers
    : data?.teachers.filter((teacher: Teacher) => teacher.departmentId === selectedDepartment);
    
  // Handle adding items to a teacher
  const handleAddItems = (teacherId: string) => {
    setSelectedTeacherId(teacherId);
    setIsAddItemsOpen(true);
  };
  
  // Handle printing receipt
  const handlePrintReceipt = async (teacherId: string) => {
    try {
      await apiRequest('GET', `/api/distribution/${teacherId}/receipt`, undefined);
      
      toast({
        title: t('distribution.receiptGenerated'),
        description: t('distribution.receiptGeneratedDescription'),
      });
    } catch (error) {
      toast({
        title: t('errors.printFailed'),
        description: error instanceof Error ? error.message : String(error),
        variant: 'destructive',
      });
    }
  };
  
  // Handle distributing items to teacher
  const distributeItems = async (itemId: string, quantity: number) => {
    if (!selectedTeacherId || !itemId || quantity <= 0) return;
    
    try {
      await apiRequest('POST', '/api/distribution', {
        teacherId: selectedTeacherId,
        itemId,
        quantity
      });
      
      setIsAddItemsOpen(false);
      
      toast({
        title: t('distribution.itemsDistributed'),
        description: t('distribution.itemsDistributedDescription'),
      });
    } catch (error) {
      toast({
        title: t('errors.distributionFailed'),
        description: error instanceof Error ? error.message : String(error),
        variant: 'destructive',
      });
    }
  };
  
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-2xl font-bold font-kufi mb-2">{t('distribution.title')}</h1>
        <p className="text-muted-foreground">{t('distribution.subtitle')}</p>
      </motion.div>
      
      {/* Department filter tabs */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="flex flex-wrap gap-2 overflow-x-auto pb-2"
      >
        <Button
          variant={selectedDepartment === 'all' ? 'default' : 'outline'}
          onClick={() => setSelectedDepartment('all')}
          className="rounded-full"
        >
          {t('distribution.allDepartments')}
        </Button>
        
        {data?.departments?.map((department: any) => (
          <Button
            key={department.id}
            variant={selectedDepartment === department.id ? 'default' : 'outline'}
            onClick={() => setSelectedDepartment(department.id)}
            className="rounded-full whitespace-nowrap"
          >
            {department.name}
          </Button>
        ))}
      </motion.div>
      
      {/* Teachers grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="h-full">
              <CardHeader className="pb-3 border-b">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Skeleton className="w-10 h-10 rounded-full mr-3" />
                    <div>
                      <Skeleton className="h-5 w-32 mb-1" />
                      <Skeleton className="h-4 w-20" />
                    </div>
                  </div>
                  <Skeleton className="h-6 w-6 rounded-full" />
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="space-y-2 mb-4">
                  <Skeleton className="h-5 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
                <div className="flex justify-between">
                  <Skeleton className="h-9 w-28" />
                  <Skeleton className="h-9 w-28" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          filteredTeachers?.map((teacher: Teacher, index: number) => (
            <TeacherCard
              key={teacher.id}
              teacher={teacher}
              index={index}
              onAddItems={handleAddItems}
              onPrintReceipt={handlePrintReceipt}
            />
          ))
        )}
      </div>
      
      {/* Distribution summary */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>{t('distribution.summary')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-muted rounded-lg p-4 flex items-center">
                <div className="h-12 w-12 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-user-line text-primary"></i>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{t('distribution.totalTeachers')}</p>
                  <p className="text-2xl font-semibold">{data?.summary?.teacherCount || 0}</p>
                </div>
              </div>
              
              <div className="bg-muted rounded-lg p-4 flex items-center">
                <div className="h-12 w-12 bg-secondary/10 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-archive-line text-secondary"></i>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{t('distribution.itemsDistributed')}</p>
                  <p className="text-2xl font-semibold">{data?.summary?.totalItems || 0}</p>
                </div>
              </div>
              
              <div className="bg-muted rounded-lg p-4 flex items-center">
                <div className="h-12 w-12 bg-yellow-100 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-time-line text-yellow-500"></i>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{t('distribution.teachersWithoutItems')}</p>
                  <p className="text-2xl font-semibold">{data?.summary?.emptyTeacherCount || 0}</p>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline">
                <FileDown className="mr-2 h-4 w-4" />
                {t('distribution.exportData')}
              </Button>
              
              <Button variant="secondary">
                <Printer className="mr-2 h-4 w-4" />
                {t('distribution.printReport')}
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
      
      {/* Add items dialog */}
      <Dialog open={isAddItemsOpen} onOpenChange={setIsAddItemsOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{t('distribution.addItems')}</DialogTitle>
            <DialogDescription>{t('distribution.addItemsDescription')}</DialogDescription>
          </DialogHeader>
          
          {/* Add useStates for form at the top of component */}
          {(() => {
            const [selectedItemId, setSelectedItemId] = useState("");
            const [selectedQuantity, setSelectedQuantity] = useState("1");
            
            return (
              <>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <span className="text-right font-medium text-sm">{t('distribution.item')}</span>
                    <div className="col-span-3">
                      <Select value={selectedItemId} onValueChange={setSelectedItemId}>
                        <SelectTrigger className="bg-white border-gray-200 hover:bg-gray-50 focus:ring-2 focus:ring-primary/20">
                          <SelectValue placeholder={t('distribution.selectItem')} />
                        </SelectTrigger>
                        <SelectContent className="max-h-[300px]">
                          {inventoryData?.items?.map((item: any) => (
                            <SelectItem key={item.id} value={item.id.toString()}>
                              <span className="font-medium">{item.name}</span>
                              <span className="text-gray-500 ml-2 text-xs">
                                ({t('distribution.available')}: {item.quantity})
                              </span>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <span className="text-right font-medium text-sm">{t('distribution.quantity')}</span>
                    <div className="col-span-3">
                      <Select value={selectedQuantity} onValueChange={setSelectedQuantity}>
                        <SelectTrigger className="bg-white border-gray-200 hover:bg-gray-50 focus:ring-2 focus:ring-primary/20">
                          <SelectValue placeholder="1" />
                        </SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3, 4, 5, 10, 15, 20, 25, 30].map((num) => (
                            <SelectItem key={num} value={num.toString()}>
                              {num}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
                
                <DialogFooter className="flex-col gap-2 sm:flex-row sm:justify-end">
                  <Button 
                    variant="outline" 
                    onClick={() => setIsAddItemsOpen(false)} 
                    className="w-full sm:w-auto border-gray-200 hover:bg-gray-50"
                  >
                    {t('common.cancel')}
                  </Button>
                  <Button 
                    onClick={() => distributeItems(selectedItemId, parseInt(selectedQuantity))}
                    disabled={!selectedItemId}
                    className={`w-full sm:w-auto relative overflow-hidden transition-all duration-200 ${!selectedItemId ? 'opacity-70' : 'hover:shadow-lg'}`}
                    variant="default"
                  >
                    <motion.span 
                      className="absolute inset-0 bg-gradient-to-r from-primary/50 to-primary/0"
                      initial={{ x: '-100%' }}
                      animate={{ x: selectedItemId ? '100%' : '-100%' }}
                      transition={{ duration: 1, repeat: Infinity, repeatType: 'loop', ease: 'linear' }}
                    />
                    <motion.span 
                      className="relative flex items-center"
                      animate={selectedItemId ? { scale: [0.97, 1.03, 0.97] } : {}}
                      transition={{ duration: 2, repeat: Infinity, repeatType: 'loop', ease: 'easeInOut' }}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      {t('distribution.addToTeacher')}
                    </motion.span>
                  </Button>
                </DialogFooter>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}
