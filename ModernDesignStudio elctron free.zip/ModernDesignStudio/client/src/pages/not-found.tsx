import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Home, Search } from "lucide-react";
import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import { Link } from "wouter";

export default function NotFound() {
  const { t } = useTranslation();
  
  return (
    <div className="relative h-full w-full flex flex-col items-center justify-center">
      {/* Decorative background elements */}
      <div className="absolute inset-0 bg-dot-pattern opacity-[0.05] pointer-events-none" />
      
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-primary/5 to-transparent" />
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-primary/5 to-transparent" />
      
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="z-10 w-full max-w-lg px-4"
      >
        <Card className="overflow-hidden border border-border/30 shadow-lg">
          <CardContent className="p-8">
            <div className="flex flex-col items-center text-center">
              <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="mb-6 relative"
              >
                <div className="absolute -inset-4 rounded-full bg-red-500/10 animate-pulse-custom"></div>
                <div className="relative bg-red-500/20 text-red-600 rounded-full p-4">
                  <Search className="h-10 w-10" />
                </div>
              </motion.div>
              
              <motion.h1 
                className="text-3xl font-bold mb-3"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4, duration: 0.5 }}
              >
                {t('notFound.title', '404 - Page Not Found')}
              </motion.h1>
              
              <motion.p 
                className="text-muted-foreground mb-8 max-w-md"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6, duration: 0.5 }}
              >
                {t('notFound.message', 'The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.')}
              </motion.p>
              
              <motion.div 
                className="flex flex-col sm:flex-row gap-3 w-full"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8, duration: 0.5 }}
              >
                <Button 
                  variant="outline" 
                  className="w-full sm:w-auto group"
                  onClick={() => window.history.back()}
                >
                  <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                  {t('notFound.goBack', 'Go Back')}
                </Button>
                
                <Link href="/">
                  <Button className="w-full sm:w-auto group">
                    <Home className="mr-2 h-4 w-4 group-hover:scale-110 transition-transform" />
                    {t('notFound.goHome', 'Return to Dashboard')}
                  </Button>
                </Link>
              </motion.div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
