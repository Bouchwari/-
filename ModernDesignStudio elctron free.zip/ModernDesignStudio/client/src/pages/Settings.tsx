import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DataTable } from '@/components/ui/data-table';
import { useQuery } from '@tanstack/react-query';
import { getQueryFn, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { useLanguageDirection } from '@/hooks/use-language-direction';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Plus, Trash, Edit, Download, Database, Save } from 'lucide-react';
import { User, Role } from '@/types';

// Define schema for user form
const userFormSchema = z.object({
  username: z.string().min(3, { message: "Username must be at least 3 characters" }),
  email: z.string().email({ message: "Invalid email address" }),
  fullName: z.string().min(3, { message: "Full name must be at least 3 characters" }),
  roleId: z.string().min(1, { message: "Role is required" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }).optional(),
  confirmPassword: z.string().optional(),
}).refine((data) => {
  // If password is provided, confirm password must match
  if (data.password && data.password !== data.confirmPassword) {
    return false;
  }
  return true;
}, { message: "Passwords don't match", path: ["confirmPassword"] });

type UserFormValues = z.infer<typeof userFormSchema>;

export default function Settings() {
  const { t, i18n } = useTranslation();
  const { direction } = useLanguageDirection();
  const { toast } = useToast();
  const [fontSizeClass, setFontSizeClass] = useState<string>("text-base");
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [selectedTab, setSelectedTab] = useState<string>("accounts");
  const [addUserOpen, setAddUserOpen] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  
  // Form setup
  const form = useForm<UserFormValues>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      username: '',
      email: '',
      fullName: '',
      roleId: '',
      password: '',
      confirmPassword: '',
    },
  });
  
  // Fetch users data
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/users'],
    queryFn: getQueryFn({ on401: 'throw' }),
  });
  
  // Fetch roles data
  const { data: rolesData } = useQuery({
    queryKey: ['/api/roles'],
    queryFn: getQueryFn({ on401: 'throw' }),
  });
  
  if (error) {
    toast({
      title: t('errors.loadFailed'),
      description: error.message,
      variant: 'destructive',
    });
  }
  
  // Handle form submission
  const onSubmit = async (formData: UserFormValues) => {
    try {
      if (isEditing && selectedUserId) {
        await apiRequest('PATCH', `/api/users/${selectedUserId}`, formData);
        toast({
          title: t('settings.users.userUpdated'),
          description: t('settings.users.userUpdatedDescription'),
        });
      } else {
        await apiRequest('POST', '/api/users', formData);
        toast({
          title: t('settings.users.userAdded'),
          description: t('settings.users.userAddedDescription'),
        });
      }
      
      form.reset();
      setAddUserOpen(false);
      setIsEditing(false);
      setSelectedUserId(null);
    } catch (error) {
      toast({
        title: t('errors.submissionFailed'),
        description: error instanceof Error ? error.message : String(error),
        variant: 'destructive',
      });
    }
  };
  
  // Handle edit user
  const handleEditUser = (user: User) => {
    setIsEditing(true);
    setSelectedUserId(user.id);
    
    form.reset({
      username: user.username,
      email: user.email,
      fullName: user.fullName,
      roleId: user.roleId,
      password: '',
      confirmPassword: '',
    });
    
    setAddUserOpen(true);
  };
  
  // Handle delete user
  const handleDeleteUser = async (userId: string) => {
    try {
      await apiRequest('DELETE', `/api/users/${userId}`, undefined);
      
      toast({
        title: t('settings.users.userDeleted'),
        description: t('settings.users.userDeletedDescription'),
      });
    } catch (error) {
      toast({
        title: t('errors.deleteFailed'),
        description: error instanceof Error ? error.message : String(error),
        variant: 'destructive',
      });
    }
  };
  
  // Users table columns
  const userColumns = [
    {
      header: t('settings.users.table.user'),
      accessorKey: 'fullName',
      cell: (user: User) => (
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium mr-3">
            <span>{user.fullName.substring(0, 2)}</span>
          </div>
          <div>
            <div className="font-medium">{user.fullName}</div>
            <div className="text-xs text-muted-foreground">@{user.username}</div>
          </div>
        </div>
      ),
    },
    {
      header: t('settings.users.table.email'),
      accessorKey: 'email',
    },
    {
      header: t('settings.users.table.role'),
      accessorKey: 'roleName',
      cell: (user: User) => (
        <Badge variant={
          user.roleName === 'Admin' ? 'default' :
          user.roleName === 'Manager' ? 'secondary' : 'outline'
        }>
          {user.roleName}
        </Badge>
      ),
    },
    {
      header: t('settings.users.table.status'),
      accessorKey: 'status',
      cell: (user: User) => (
        <Badge variant={user.status === 'active' ? 'success' : 'outline'}>
          {t(`settings.users.status.${user.status}`)}
        </Badge>
      ),
    },
    {
      header: t('settings.users.table.lastLogin'),
      accessorKey: 'lastLogin',
    },
    {
      header: t('settings.users.table.actions'),
      accessorKey: 'actions',
      cell: (user: User) => (
        <div className="flex space-x-2 rtl:space-x-reverse">
          <Button 
            size="icon" 
            variant="ghost"
            onClick={() => handleEditUser(user)}
          >
            <Edit className="h-4 w-4 text-primary" />
          </Button>
          <Button 
            size="icon" 
            variant="ghost"
            onClick={() => handleDeleteUser(user.id)}
          >
            <Trash className="h-4 w-4 text-destructive" />
          </Button>
        </div>
      ),
    },
  ];
  
  // Change language
  const changeLanguage = (lang: string) => {
    i18n.changeLanguage(lang);
  };
  
  // Change font size
  const changeFontSize = (size: string) => {
    setFontSizeClass(size);
    document.documentElement.classList.remove('text-sm', 'text-base', 'text-lg', 'text-xl');
    document.documentElement.classList.add(size);
  };
  
  // Toggle dark mode
  const toggleDarkMode = (checked: boolean) => {
    setDarkMode(checked);
    if (checked) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };
  
  // Create backup
  const createBackup = async () => {
    try {
      await apiRequest('POST', '/api/backup', undefined);
      
      toast({
        title: t('settings.data.backupCreated'),
        description: t('settings.data.backupCreatedDescription'),
      });
    } catch (error) {
      toast({
        title: t('errors.backupFailed'),
        description: error instanceof Error ? error.message : String(error),
        variant: 'destructive',
      });
    }
  };
  
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-2xl font-bold font-kufi mb-2">{t('settings.title')}</h1>
        <p className="text-muted-foreground">{t('settings.subtitle')}</p>
      </motion.div>
      
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList>
          <TabsTrigger value="accounts">{t('settings.tabs.accounts')}</TabsTrigger>
          <TabsTrigger value="language">{t('settings.tabs.language')}</TabsTrigger>
          <TabsTrigger value="backup">{t('settings.tabs.backup')}</TabsTrigger>
          <TabsTrigger value="about">{t('settings.tabs.about')}</TabsTrigger>
        </TabsList>
        
        {/* Accounts Tab */}
        <TabsContent value="accounts" className="mt-6">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>{t('settings.users.manageAccounts')}</CardTitle>
                <Dialog open={addUserOpen} onOpenChange={setAddUserOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={() => {
                      setIsEditing(false);
                      setSelectedUserId(null);
                      form.reset({
                        username: '',
                        email: '',
                        fullName: '',
                        roleId: '',
                        password: '',
                        confirmPassword: '',
                      });
                    }}>
                      <Plus className="mr-2 h-4 w-4" />
                      {t('settings.users.addUser')}
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>
                        {isEditing ? t('settings.users.editUser') : t('settings.users.addNewUser')}
                      </DialogTitle>
                      <DialogDescription>
                        {isEditing ? t('settings.users.editUserDescription') : t('settings.users.addUserDescription')}
                      </DialogDescription>
                    </DialogHeader>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="fullName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('settings.users.form.fullName')}</FormLabel>
                              <FormControl>
                                <Input placeholder={t('settings.users.form.fullNamePlaceholder')} {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={form.control}
                            name="username"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>{t('settings.users.form.username')}</FormLabel>
                                <FormControl>
                                  <Input placeholder={t('settings.users.form.usernamePlaceholder')} {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>{t('settings.users.form.email')}</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="email" 
                                    placeholder={t('settings.users.form.emailPlaceholder')} 
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="roleId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t('settings.users.form.role')}</FormLabel>
                              <Select 
                                value={field.value} 
                                onValueChange={field.onChange}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder={t('settings.users.form.selectRole')} />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {rolesData?.roles?.map((role: Role) => (
                                    <SelectItem key={role.id} value={role.id}>
                                      {role.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={form.control}
                            name="password"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>{t('settings.users.form.password')}</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="password" 
                                    placeholder={isEditing ? '••••••••' : t('settings.users.form.passwordPlaceholder')} 
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="confirmPassword"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>{t('settings.users.form.confirmPassword')}</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="password" 
                                    placeholder={isEditing ? '••••••••' : t('settings.users.form.confirmPasswordPlaceholder')} 
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <DialogFooter>
                          <Button 
                            variant="outline" 
                            type="button" 
                            onClick={() => setAddUserOpen(false)}
                          >
                            {t('common.cancel')}
                          </Button>
                          <Button type="submit">
                            {isEditing ? t('settings.users.updateUser') : t('settings.users.addUser')}
                          </Button>
                        </DialogFooter>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-96 w-full" />
                  </div>
                ) : (
                  <DataTable
                    data={data?.users || []}
                    columns={userColumns}
                    searchPlaceholder={t('settings.users.searchUsers')}
                    searchKey="fullName"
                    pagination
                    rowsPerPage={10}
                  />
                )}
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
        
        {/* Language & Display Tab */}
        <TabsContent value="language" className="mt-6">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>{t('settings.language.displaySettings')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="border border-border rounded-lg p-4">
                    <h3 className="font-medium mb-3 font-kufi">{t('settings.language.defaultLanguage')}</h3>
                    
                    <RadioGroup 
                      defaultValue={i18n.language} 
                      onValueChange={changeLanguage}
                      className="space-y-2"
                    >
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <RadioGroupItem value="ar" id="lang-ar" />
                        <Label htmlFor="lang-ar">{t('settings.language.arabic')}</Label>
                      </div>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <RadioGroupItem value="fr" id="lang-fr" />
                        <Label htmlFor="lang-fr">{t('settings.language.french')}</Label>
                      </div>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <RadioGroupItem value="en" id="lang-en" />
                        <Label htmlFor="lang-en">{t('settings.language.english')}</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div className="border border-border rounded-lg p-4">
                    <h3 className="font-medium mb-3 font-kufi">{t('settings.language.fontSize')}</h3>
                    
                    <div className="flex flex-wrap gap-2">
                      <Button 
                        variant={fontSizeClass === "text-sm" ? "default" : "outline"}
                        size="sm"
                        onClick={() => changeFontSize("text-sm")}
                      >
                        {t('settings.language.small')}
                      </Button>
                      <Button 
                        variant={fontSizeClass === "text-base" ? "default" : "outline"}
                        size="sm"
                        onClick={() => changeFontSize("text-base")}
                      >
                        {t('settings.language.medium')}
                      </Button>
                      <Button 
                        variant={fontSizeClass === "text-lg" ? "default" : "outline"}
                        size="sm"
                        onClick={() => changeFontSize("text-lg")}
                      >
                        {t('settings.language.large')}
                      </Button>
                      <Button 
                        variant={fontSizeClass === "text-xl" ? "default" : "outline"}
                        size="sm"
                        onClick={() => changeFontSize("text-xl")}
                      >
                        {t('settings.language.extraLarge')}
                      </Button>
                    </div>
                    
                    <div className="mt-4">
                      <h3 className="font-medium mb-2 font-kufi">{t('settings.language.darkMode')}</h3>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <Switch
                          checked={darkMode}
                          onCheckedChange={toggleDarkMode}
                          id="dark-mode"
                        />
                        <Label htmlFor="dark-mode">{t('settings.language.enableDarkMode')}</Label>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border border-border rounded-lg p-4 md:col-span-2">
                    <h3 className="font-medium mb-3 font-kufi">{t('settings.language.preview')}</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="border border-border rounded-lg p-3">
                        <h4 className="font-kufi font-medium mb-2 text-sm">{t('settings.language.arabic')} (RTL)</h4>
                        <div className="bg-muted p-2 rounded">
                          <p className="text-sm">نظام إدارة الموارد والأصول المدرسية</p>
                          <p className="text-xs text-muted-foreground mt-1">تم تصميم هذا النظام خصيصًا للمدارس المغربية.</p>
                        </div>
                      </div>
                      
                      <div className="border border-border rounded-lg p-3">
                        <h4 className="font-kufi font-medium mb-2 text-sm">{t('settings.language.french')} (LTR)</h4>
                        <div className="bg-muted p-2 rounded">
                          <p className="text-sm">Système de gestion des ressources scolaires</p>
                          <p className="text-xs text-muted-foreground mt-1">Conçu spécifiquement pour les écoles marocaines.</p>
                        </div>
                      </div>
                      
                      <div className="border border-border rounded-lg p-3">
                        <h4 className="font-kufi font-medium mb-2 text-sm">{t('settings.language.english')} (LTR)</h4>
                        <div className="bg-muted p-2 rounded">
                          <p className="text-sm">School Resource Management System</p>
                          <p className="text-xs text-muted-foreground mt-1">Specifically designed for Moroccan schools.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end">
                  <Button>
                    <Save className="mr-2 h-4 w-4" />
                    {t('settings.language.saveChanges')}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
        
        {/* Backup Tab */}
        <TabsContent value="backup" className="mt-6">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>{t('settings.data.backupRestore')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="border border-border rounded-lg p-6">
                    <div className="flex items-center mb-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                        <Database className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium">{t('settings.data.createBackup')}</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {t('settings.data.createBackupDescription')}
                        </p>
                      </div>
                    </div>
                    <Button 
                      className="w-full"
                      onClick={createBackup}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      {t('settings.data.downloadBackup')}
                    </Button>
                  </div>
                  
                  <div className="border border-border rounded-lg p-6">
                    <div className="flex items-center mb-4">
                      <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center mr-4">
                        <i className="ri-upload-2-line text-xl text-secondary"></i>
                      </div>
                      <div>
                        <h3 className="font-medium">{t('settings.data.restoreBackup')}</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {t('settings.data.restoreBackupDescription')}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-center w-full">
                      <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-muted/50 hover:bg-muted">
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <i className="ri-upload-cloud-line text-3xl text-muted-foreground mb-2"></i>
                          <p className="mb-2 text-sm text-center">
                            <span className="font-medium">{t('settings.data.clickToUpload')}</span> {t('settings.data.dragDrop')}
                          </p>
                          <p className="text-xs text-muted-foreground">(JSON {t('settings.data.fileFormat')})</p>
                        </div>
                        <input id="dropzone-file" type="file" className="hidden" />
                      </label>
                    </div>
                  </div>
                </div>
                
                <Separator className="my-6" />
                
                <div className="space-y-4">
                  <h3 className="font-medium font-kufi">{t('settings.data.dataExport')}</h3>
                  <p className="text-sm text-muted-foreground">
                    {t('settings.data.dataExportDescription')}
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Button variant="outline" className="flex items-center">
                      <i className="ri-file-excel-line text-green-600 mr-2"></i>
                      {t('settings.data.exportInventory')}
                    </Button>
                    <Button variant="outline" className="flex items-center">
                      <i className="ri-file-excel-line text-green-600 mr-2"></i>
                      {t('settings.data.exportRequests')}
                    </Button>
                    <Button variant="outline" className="flex items-center">
                      <i className="ri-file-excel-line text-green-600 mr-2"></i>
                      {t('settings.data.exportBudget')}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
        
        {/* About Tab */}
        <TabsContent value="about" className="mt-6">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>{t('settings.about.aboutSystem')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-6">
                  <div className="mx-auto w-16 h-16 bg-primary rounded-lg flex items-center justify-center mb-2">
                    <i className="ri-building-4-line text-2xl text-white"></i>
                  </div>
                  <h2 className="text-xl font-bold font-kufi">{t('app.title')}</h2>
                  <p className="text-muted-foreground">{t('app.subtitle')}</p>
                  <p className="mt-2 text-sm">v1.0.0</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-medium mb-2 font-kufi">{t('settings.about.systemInfo')}</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between py-1 border-b">
                        <span className="font-medium">{t('settings.about.version')}</span>
                        <span>1.0.0</span>
                      </div>
                      <div className="flex justify-between py-1 border-b">
                        <span className="font-medium">{t('settings.about.releaseDate')}</span>
                        <span>2023-08-01</span>
                      </div>
                      <div className="flex justify-between py-1 border-b">
                        <span className="font-medium">{t('settings.about.licensedTo')}</span>
                        <span>Moroccan Ministry of Education</span>
                      </div>
                      <div className="flex justify-between py-1 border-b">
                        <span className="font-medium">{t('settings.about.supportUntil')}</span>
                        <span>2024-08-01</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-2 font-kufi">{t('settings.about.support')}</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between py-1 border-b">
                        <span className="font-medium">{t('settings.about.supportEmail')}</span>
                        <span>support@schoolassets.ma</span>
                      </div>
                      <div className="flex justify-between py-1 border-b">
                        <span className="font-medium">{t('settings.about.supportPhone')}</span>
                        <span>+212 5XX-XXXXXX</span>
                      </div>
                      <div className="flex justify-between py-1 border-b">
                        <span className="font-medium">{t('settings.about.documentation')}</span>
                        <span className="text-primary">
                          <a href="#" className="flex items-center">
                            {t('settings.about.viewDocs')}
                            <i className="ri-external-link-line ml-1"></i>
                          </a>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h3 className="font-medium mb-2 font-kufi">{t('settings.about.systemFeatures')}</h3>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>{t('settings.about.features.inventory')}</li>
                    <li>{t('settings.about.features.requests')}</li>
                    <li>{t('settings.about.features.distribution')}</li>
                    <li>{t('settings.about.features.maintenance')}</li>
                    <li>{t('settings.about.features.reporting')}</li>
                    <li>{t('settings.about.features.multilingual')}</li>
                  </ul>
                </div>
                
                <Separator className="my-6" />
                
                <div className="text-center text-sm text-muted-foreground">
                  <p>© 2023 School Asset Management System. {t('settings.about.allRightsReserved')}</p>
                  <p className="mt-1">{t('settings.about.developedBy')} Moroccan Educational Technology Solutions</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
