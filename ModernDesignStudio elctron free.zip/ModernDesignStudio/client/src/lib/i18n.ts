import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

import arTranslation from '../locales/ar.json';
import frTranslation from '../locales/fr.json';
import enTranslation from '../locales/en.json';

// Helper function to set RTL direction for Arabic language
const setDirectionForLanguage = (language: string) => {
  const isRTL = language === 'ar';
  document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
  document.documentElement.lang = language;
  
  // Apply RTL-specific font and size adjustments
  if (isRTL) {
    document.documentElement.classList.add('font-arabic');
  } else {
    document.documentElement.classList.remove('font-arabic');
  }
};

// Initialize i18n
i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      ar: {
        translation: arTranslation
      },
      fr: {
        translation: frTranslation
      },
      en: {
        translation: enTranslation
      }
    },
    fallbackLng: 'ar',
    debug: process.env.NODE_ENV === 'development',
    
    interpolation: {
      escapeValue: false, // not needed for react as it escapes by default
    },
    
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage']
    }
  });

// Set direction on language change
i18n.on('languageChanged', setDirectionForLanguage);

// Set direction for initial language
setDirectionForLanguage(i18n.language);

export default i18n;
