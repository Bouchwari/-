// Common Types
export type ItemStatus = 'new' | 'fair' | 'worn' | 'maintenance' | 'low-stock';
export type RequestStatus = 'pending' | 'approved' | 'delivered' | 'rejected' | 'processing';
export type TransactionType = 'income' | 'expense';
export type TransactionStatus = 'completed' | 'pending' | 'processing';
export type MaintenanceStatus = 'completed' | 'inprogress' | 'pending' | 'overdue';
export type MaintenancePriority = 'low' | 'medium' | 'high';
export type UserStatus = 'active' | 'inactive';

// Inventory Types
export type ItemClassification = 'A' | 'B' | 'C' | 'D' | 'E' | 'I';

export interface InventoryItem {
  id: string;
  name: string;
  serialNumber: string;
  inventoryNumber: string;
  classification: ItemClassification;
  category: string;
  location: string;
  status: ItemStatus;
  quantity: number;
  lastUpdated: string;
  sku?: string;
  icon?: string;
}

// Request Types
export interface RequestItem {
  id: string;
  name: string;
  quantity: number;
  notes?: string;
}

export interface MaterialRequest {
  id: string;
  teacherId: string;
  teacherName: string;
  department: string;
  departmentId: string;
  date: string;
  status: RequestStatus;
  items: RequestItem[];
  source: string;
  reference?: string;
}

// Distribution Types
export interface DistributedItem {
  id: string;
  name: string;
  quantity: number;
  date: string;
}

export interface Teacher {
  id: string;
  name: string;
  department: string;
  departmentId: string;
  items: DistributedItem[];
}

export interface Department {
  id: string;
  name: string;
}

// Maintenance Types
export interface MaintenanceTask {
  id: string;
  title: string;
  description: string;
  date: string;
  dateRaw: string;
  status: MaintenanceStatus;
  priority: MaintenancePriority;
  itemId: string;
  itemName?: string;
}

// Budget Types
export interface Transaction {
  id: string;
  title: string;
  reference: string;
  category: string;
  date: string;
  amount: number;
  type: TransactionType;
  status: TransactionStatus;
  description?: string;
}

export interface BudgetSummary {
  total: number;
  expenses: number;
  remaining: number;
  usedPercentage: number;
  remainingPercentage: number;
  expenseChangePercentage: number;
}

export interface ChartData {
  monthlyExpenses: {
    stationery: number[];
    technology: number[];
    maintenance: number[];
  };
  budgetDistribution: number[];
}

// User Management Types
export interface User {
  id: string;
  username: string;
  fullName: string;
  email: string;
  roleId: string;
  roleName: string;
  status: UserStatus;
  lastLogin: string;
}

export interface Role {
  id: string;
  name: string;
  permissions?: string[];
}

// Dashboard Types
export interface DashboardData {
  inventory: {
    total: number;
    change: {
      value: number;
      isPositive: boolean;
    };
  };
  requests: {
    pending: number;
    change: {
      value: number;
      isPositive: boolean;
    };
  };
  budget: {
    remaining: number;
    total: number;
    percentage: number;
    change: {
      value: number;
      isPositive: boolean;
    };
  };
  maintenance: {
    total: number;
    overdue: number;
  };
  alerts: {
    low_stock: Array<{
      id: string;
      name: string;
      quantity: number;
    }>;
    maintenance: Array<{
      id: string;
      task: string;
      due: string;
    }>;
    others: Array<{
      id: string;
      type: string;
      message: string;
    }>;
  };
  recentActivity: Array<{
    id: string;
    type: string;
    user: string;
    action: string;
    timestamp: string;
    details?: string;
  }>;
}
