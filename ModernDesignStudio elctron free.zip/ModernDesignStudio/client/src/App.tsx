import { useEffect, useState } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Inventory from "@/pages/Inventory";
import Requests from "@/pages/Requests";
import Distribution from "@/pages/Distribution";
import Maintenance from "@/pages/Maintenance";
import Reports from "@/pages/Reports";
import Settings from "@/pages/Settings";
import AuthPage from "@/pages/auth-page";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import { useTranslation } from "react-i18next";
import { useLanguageDirection } from "@/hooks/use-language-direction";

function MainLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  
  return (
    <div className="flex h-screen overflow-hidden bg-gray-50/30 dark:bg-gray-950/30">
      <div className="w-full flex">
        <Sidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header currentPath={location} />
          
          {/* Premium main content with increased padding for negative space */}
          <main className="flex-1 overflow-y-auto p-8 md:p-10 relative">
            {/* Background subtle pattern for visual interest */}
            <div className="absolute inset-0 bg-grid-pattern opacity-[0.02] dark:opacity-[0.03] pointer-events-none" />
            
            {/* Main content container with max-width for readability and centered layout */}
            <div className="relative z-10 max-w-screen-2xl mx-auto">
              {children}
            </div>
            
            {/* Subtle gradient at bottom for depth */}
            <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background/20 to-transparent pointer-events-none" />
          </main>
        </div>
      </div>
    </div>
  );
}

function Router() {
  // For now, use a simple state to track auth status
  // In a real app, this would come from your auth provider
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <Route path="/inventory">
        <MainLayout>
          <Inventory />
        </MainLayout>
      </Route>
      <Route path="/requests">
        <MainLayout>
          <Requests />
        </MainLayout>
      </Route>
      <Route path="/distribution">
        <MainLayout>
          <Distribution />
        </MainLayout>
      </Route>
      <Route path="/maintenance">
        <MainLayout>
          <Maintenance />
        </MainLayout>
      </Route>
      <Route path="/reports">
        <MainLayout>
          <Reports />
        </MainLayout>
      </Route>
      {/* Budget route removed as requested */}
      <Route path="/settings">
        <MainLayout>
          <Settings />
        </MainLayout>
      </Route>
      <Route path="/">
        <MainLayout>
          <Dashboard />
        </MainLayout>
      </Route>
      <Route>
        <MainLayout>
          <NotFound />
        </MainLayout>
      </Route>
    </Switch>
  );
}

function App() {
  const { i18n } = useTranslation();
  const { direction } = useLanguageDirection();
  const [isClient, setIsClient] = useState(false);
  
  useEffect(() => {
    setIsClient(true);
  }, []);
  
  useEffect(() => {
    // Set the dir attribute on the html element
    document.documentElement.dir = direction;
    document.documentElement.lang = i18n.language;
  }, [i18n.language, direction]);

  if (!isClient) {
    return <div className="h-screen w-full flex items-center justify-center">Loading...</div>;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
