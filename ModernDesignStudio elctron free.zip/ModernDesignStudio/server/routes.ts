import express, { Router, type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertInventoryItemSchema, 
  insertMaterialRequestSchema, 
  insertDistributionSchema, 
  insertMaintenanceTaskSchema
} from "@shared/schema";

const apiRouter = Router();

// Helper function to handle async route handlers
const asyncHandler = (fn: (req: Request, res: Response) => Promise<any>) => {
  return async (req: Request, res: Response) => {
    try {
      await fn(req, res);
    } catch (error) {
      console.error(error);
      if (error instanceof Error) {
        res.status(500).json({ message: error.message });
      } else {
        res.status(500).json({ message: "An unknown error occurred" });
      }
    }
  };
};

// Dashboard routes
apiRouter.get("/dashboard", asyncHandler(async (req, res) => {
  const dashboardData = await storage.getDashboardData();
  res.json(dashboardData);
}));

// User and role routes
apiRouter.get("/users", asyncHandler(async (req, res) => {
  const users = await storage.getAllUsers();
  res.json({ users });
}));

apiRouter.get("/users/:id", asyncHandler(async (req, res) => {
  const user = await storage.getUser(parseInt(req.params.id));
  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }
  res.json(user);
}));

apiRouter.post("/users", asyncHandler(async (req, res) => {
  const data = insertUserSchema.parse(req.body);
  const newUser = await storage.createUser(data);
  res.status(201).json(newUser);
}));

apiRouter.patch("/users/:id", asyncHandler(async (req, res) => {
  const id = parseInt(req.params.id);
  const data = insertUserSchema.partial().parse(req.body);
  const updatedUser = await storage.updateUser(id, data);
  if (!updatedUser) {
    return res.status(404).json({ message: "User not found" });
  }
  res.json(updatedUser);
}));

apiRouter.delete("/users/:id", asyncHandler(async (req, res) => {
  const id = parseInt(req.params.id);
  const result = await storage.deleteUser(id);
  if (!result) {
    return res.status(404).json({ message: "User not found" });
  }
  res.json({ message: "User deleted successfully" });
}));

apiRouter.get("/roles", asyncHandler(async (req, res) => {
  const roles = await storage.getAllRoles();
  res.json({ roles });
}));

// Inventory routes
apiRouter.get("/inventory", asyncHandler(async (req, res) => {
  const items = await storage.getAllInventoryItems();
  res.json({ items });
}));

apiRouter.get("/inventory/available", asyncHandler(async (req, res) => {
  const items = await storage.getAvailableInventoryItems();
  res.json({ items });
}));

apiRouter.get("/inventory/:id", asyncHandler(async (req, res) => {
  const item = await storage.getInventoryItem(parseInt(req.params.id));
  if (!item) {
    return res.status(404).json({ message: "Item not found" });
  }
  res.json(item);
}));

apiRouter.post("/inventory", asyncHandler(async (req, res) => {
  const data = insertInventoryItemSchema.parse(req.body);
  const newItem = await storage.createInventoryItem(data);
  res.status(201).json(newItem);
}));

apiRouter.patch("/inventory/:id", asyncHandler(async (req, res) => {
  const id = parseInt(req.params.id);
  const data = insertInventoryItemSchema.partial().parse(req.body);
  const updatedItem = await storage.updateInventoryItem(id, data);
  if (!updatedItem) {
    return res.status(404).json({ message: "Item not found" });
  }
  res.json(updatedItem);
}));

apiRouter.delete("/inventory/:id", asyncHandler(async (req, res) => {
  const id = parseInt(req.params.id);
  const result = await storage.deleteInventoryItem(id);
  if (!result) {
    return res.status(404).json({ message: "Item not found" });
  }
  res.json({ message: "Item deleted successfully" });
}));

// Material request routes
apiRouter.get("/requests", asyncHandler(async (req, res) => {
  const requests = await storage.getAllMaterialRequests();
  res.json({ requests });
}));

apiRouter.get("/request-options", asyncHandler(async (req, res) => {
  const teachers = await storage.getAllTeachers();
  const departments = await storage.getAllDepartments();
  const items = await storage.getAllInventoryItems();
  res.json({ teachers, departments, items });
}));

apiRouter.post("/requests", asyncHandler(async (req, res) => {
  const requestData = z.object({
    teacherId: z.string(),
    department: z.string(),
    date: z.string(),
    source: z.string(),
    items: z.array(z.object({
      itemId: z.string(),
      quantity: z.number(),
      notes: z.string().optional(),
    }))
  }).parse(req.body);

  const newRequest = await storage.createMaterialRequestWithItems(requestData);
  res.status(201).json(newRequest);
}));

// Distribution routes
apiRouter.get("/distribution", asyncHandler(async (req, res) => {
  const teachers = await storage.getTeachersWithDistributions();
  const departments = await storage.getAllDepartments();
  const summary = await storage.getDistributionSummary();
  res.json({ teachers, departments, summary });
}));

apiRouter.post("/distribution", asyncHandler(async (req, res) => {
  const data = insertDistributionSchema.parse(req.body);
  const newDistribution = await storage.createDistribution(data);
  res.status(201).json(newDistribution);
}));

apiRouter.get("/distribution/:teacherId/receipt", asyncHandler(async (req, res) => {
  const teacherId = parseInt(req.params.teacherId);
  const receipt = await storage.generateDistributionReceipt(teacherId);
  res.json(receipt);
}));

// Maintenance routes
apiRouter.get("/maintenance", asyncHandler(async (req, res) => {
  const tasks = await storage.getAllMaintenanceTasks();
  const timeline = await storage.getMaintenanceTimeline();
  res.json({ tasks, timeline });
}));

apiRouter.post("/maintenance", asyncHandler(async (req, res) => {
  const data = insertMaintenanceTaskSchema.parse(req.body);
  const newTask = await storage.createMaintenanceTask(data);
  res.status(201).json(newTask);
}));

// Budget routes removed as requested

// Reports routes
apiRouter.get("/reports", asyncHandler(async (req, res) => {
  const { tab, timeRange, category, department } = req.query;
  
  // For now, let's return sample data to display in the UI
  // This will be replaced with actual data from storage in a real implementation
  const reports = {
    inventory: {
      chartData: [
        { name: "كتب دراسية", value: 120, usage: 100 },
        { name: "قرطاسية", value: 85, usage: 60 },
        { name: "مواد مخبرية", value: 45, usage: 25 },
        { name: "معدات", value: 35, usage: 20 },
        { name: "أثاث", value: 25, usage: 15 },
        { name: "إلكترونيات", value: 18, usage: 10 },
      ],
      pieData: [
        { name: "كتب دراسية", value: 120 },
        { name: "قرطاسية", value: 85 },
        { name: "مواد مخبرية", value: 45 },
        { name: "معدات", value: 35 },
        { name: "أثاث", value: 25 },
        { name: "إلكترونيات", value: 18 },
      ],
      trendData: [
        { name: "يناير", value: 110, demand: 90 },
        { name: "فبراير", value: 118, demand: 95 },
        { name: "مارس", value: 125, demand: 100 },
        { name: "أبريل", value: 132, demand: 110 },
        { name: "مايو", value: 145, demand: 125 },
        { name: "يونيو", value: 152, demand: 135 },
        { name: "يوليو", value: 159, demand: 140 },
        { name: "أغسطس", value: 175, demand: 150 },
        { name: "سبتمبر", value: 190, demand: 165 },
        { name: "أكتوبر", value: 205, demand: 175 },
        { name: "نوفمبر", value: 220, demand: 185 },
        { name: "ديسمبر", value: 228, demand: 195 },
      ],
      summary: [
        { label: "totalItems", value: 328 },
        { label: "newItems", value: 45 },
        { label: "lowStock", value: 12 },
        { label: "totalValue", value: "123,450.00 درهم" },
        { label: "avgLifespan", value: "4.5 سنة" },
      ],
      topItems: [
        { name: "كتاب الرياضيات", value: 50 },
        { name: "كتاب العلوم", value: 45 },
        { name: "دفاتر مدرسية", value: 40 },
        { name: "أقلام رصاص", value: 35 },
        { name: "حواسيب محمولة", value: 12 },
      ],
      insights: [
        "معدل استهلاك القرطاسية ارتفع بنسبة 15% مقارنة بالعام الماضي",
        "المخزون الحالي من الكتب الدراسية يكفي لتغطية احتياجات العام الحالي",
        "5 أصناف من المعدات الإلكترونية بحاجة إلى صيانة عاجلة",
        "التوقعات تشير إلى ارتفاع الطلب على مستلزمات المختبر خلال الفصل القادم"
      ]
    },
    distribution: {
      chartData: [
        { name: "قسم العلوم", value: 85 },
        { name: "قسم الرياضيات", value: 75 },
        { name: "قسم اللغة العربية", value: 65 },
        { name: "قسم اللغة الفرنسية", value: 60 },
        { name: "قسم اللغة الإنجليزية", value: 55 },
        { name: "قسم الاجتماعيات", value: 50 },
        { name: "قسم الإعلاميات", value: 40 },
      ],
      pieData: [
        { name: "قسم العلوم", value: 85 },
        { name: "قسم الرياضيات", value: 75 },
        { name: "قسم اللغة العربية", value: 65 },
        { name: "قسم اللغة الفرنسية", value: 60 },
        { name: "قسم اللغة الإنجليزية", value: 55 },
        { name: "قسم الاجتماعيات", value: 50 },
        { name: "قسم الإعلاميات", value: 40 },
      ],
      trendData: [
        { name: "سبتمبر", value: 45 },
        { name: "أكتوبر", value: 65 },
        { name: "نوفمبر", value: 85 },
        { name: "ديسمبر", value: 60 },
        { name: "يناير", value: 50 },
        { name: "فبراير", value: 55 },
        { name: "مارس", value: 70 },
        { name: "أبريل", value: 90 },
        { name: "مايو", value: 110 },
        { name: "يونيو", value: 130 },
      ],
      summary: [
        { label: "totalDistributed", value: 430 },
        { label: "teachersReceived", value: 28 },
        { label: "pendingRequests", value: 5 },
        { label: "avgItemsPerTeacher", value: "15.4" },
      ],
      topItems: [
        { name: "محمد علوي", value: 25 },
        { name: "فاطمة بنعيسى", value: 22 },
        { name: "أحمد سلام", value: 20 },
        { name: "عائشة المراكشي", value: 18 },
        { name: "عبد الله المزواري", value: 15 },
      ],
      insights: [
        "قسم العلوم لديه أعلى معدل استهلاك للمواد خلال العام الحالي",
        "90% من المدرسين استلموا المواد المخصصة لهم في الوقت المحدد",
        "الكتب والقرطاسية تشكل 65% من إجمالي المواد الموزعة على المدرسين",
        "تم توزيع المواد الإلكترونية بنسبة 100% مقارنة بالعام الماضي (85%)"
      ]
    },
    maintenance: {
      chartData: [
        { name: "أجهزة الحاسوب", value: 18 },
        { name: "المعدات المخبرية", value: 15 },
        { name: "أنظمة التكييف", value: 12 },
        { name: "الأثاث المدرسي", value: 10 },
        { name: "مرافق المدرسة", value: 8 },
        { name: "المعدات الرياضية", value: 5 },
      ],
      pieData: [
        { name: "قيد الإنجاز", value: 12 },
        { name: "مكتملة", value: 25 },
        { name: "متأخرة", value: 8 },
        { name: "مجدولة", value: 15 },
        { name: "ملغاة", value: 3 },
      ],
      trendData: [
        { name: "يناير", value: 10 },
        { name: "فبراير", value: 12 },
        { name: "مارس", value: 15 },
        { name: "أبريل", value: 13 },
        { name: "مايو", value: 16 },
        { name: "يونيو", value: 18 },
        { name: "يوليو", value: 10 },
        { name: "أغسطس", value: 8 },
        { name: "سبتمبر", value: 14 },
        { name: "أكتوبر", value: 16 },
        { name: "نوفمبر", value: 18 },
        { name: "ديسمبر", value: 13 },
      ],
      summary: [
        { label: "totalTasks", value: 65 },
        { label: "completedTasks", value: 25 },
        { label: "pendingTasks", value: 12 },
        { label: "overdueTasks", value: 8 },
        { label: "avgCompletionTime", value: "4.2 يوم" },
      ],
      topItems: [
        { name: "صيانة أجهزة الحاسوب", value: 18 },
        { name: "إصلاح معدات المختبر", value: 15 },
        { name: "صيانة التكييف", value: 12 },
        { name: "إصلاح الأثاث", value: 10 },
        { name: "صيانة مرافق المدرسة", value: 8 },
      ],
      insights: [
        "متوسط وقت إكمال مهام الصيانة انخفض بنسبة 15% مقارنة بالعام الماضي",
        "معدل صيانة أجهزة الحاسوب هو الأعلى، ويمثل 28% من إجمالي مهام الصيانة",
        "8 مهام صيانة متأخرة عن موعدها المحدد، معظمها متعلقة بالمعدات المخبرية",
        "تمت إضافة 15 مهمة صيانة جديدة خلال الشهر الماضي"
      ]
    },
    requests: {
      chartData: [
        { name: "قسم العلوم", value: 28 },
        { name: "قسم الرياضيات", value: 25 },
        { name: "قسم اللغة العربية", value: 20 },
        { name: "قسم اللغة الفرنسية", value: 18 },
        { name: "قسم اللغة الإنجليزية", value: 15 },
        { name: "قسم الاجتماعيات", value: 12 },
        { name: "قسم الإعلاميات", value: 10 },
      ],
      pieData: [
        { name: "مكتملة", value: 45 },
        { name: "قيد المعالجة", value: 25 },
        { name: "متأخرة", value: 10 },
        { name: "ملغاة", value: 5 },
      ],
      trendData: [
        { name: "يناير", value: 18 },
        { name: "فبراير", value: 20 },
        { name: "مارس", value: 25 },
        { name: "أبريل", value: 22 },
        { name: "مايو", value: 28 },
        { name: "يونيو", value: 30 },
        { name: "يوليو", value: 15 },
        { name: "أغسطس", value: 12 },
        { name: "سبتمبر", value: 22 },
        { name: "أكتوبر", value: 26 },
        { name: "نوفمبر", value: 30 },
        { name: "ديسمبر", value: 25 },
      ],
      summary: [
        { label: "totalRequests", value: 128 },
        { label: "pendingRequests", value: 25 },
        { label: "completedRequests", value: 85 },
        { label: "avgResponseTime", value: "2.5 يوم" },
        { label: "completionRate", value: "88%" },
      ],
      topItems: [
        { name: "قسم العلوم", value: 28 },
        { name: "قسم الرياضيات", value: 25 },
        { name: "قسم اللغة العربية", value: 20 },
        { name: "قسم اللغة الفرنسية", value: 18 },
        { name: "قسم اللغة الإنجليزية", value: 15 },
      ],
      insights: [
        "85% من طلبات المواد تم إكمالها بنجاح خلال العام الدراسي الحالي",
        "قسم العلوم قدم أكبر عدد من الطلبات، تليه أقسام الرياضيات واللغة العربية",
        "متوسط وقت الاستجابة للطلبات انخفض من 3.8 يوم إلى 2.5 يوم مقارنة بالعام الماضي",
        "الكتب والمواد المخبرية هي الأكثر طلبًا، تمثل 45% من إجمالي الطلبات"
      ]
    }
  };
  
  res.json(reports);
}));

apiRouter.get("/departments", asyncHandler(async (req, res) => {
  const departments = await storage.getAllDepartments();
  res.json({ departments });
}));

// Backup route
apiRouter.post("/backup", asyncHandler(async (req, res) => {
  const backup = await storage.createBackup();
  res.json(backup);
}));

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up the API routes prefixed with /api
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
