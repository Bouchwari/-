import { 
  User, InsertUser, 
  Role, InsertRole,
  InventoryItem, InsertInventoryItem,
  Department, InsertDepartment,
  Teacher, InsertTeacher,
  MaterialRequest, InsertMaterialRequest,
  RequestItem, InsertRequestItem,
  Distribution, InsertDistribution,
  MaintenanceTask, InsertMaintenanceTask,
  users, roles, inventoryItems, departments, teachers, materialRequests,
  requestItems, distributions, maintenanceTasks
} from "@shared/schema";
import { db, pool } from './db';
import { eq, and, desc, sql } from 'drizzle-orm';
import session from 'express-session';
import createMemoryStore from 'memorystore';
import connectPgSimple from 'connect-pg-simple';

// Export interface for the storage operations
export interface IStorage {
  // Users and roles
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;
  getAllRoles(): Promise<Role[]>;
  
  // Inventory
  getInventoryItem(id: number): Promise<InventoryItem | undefined>;
  getAllInventoryItems(): Promise<InventoryItem[]>;
  getAvailableInventoryItems(): Promise<InventoryItem[]>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined>;
  deleteInventoryItem(id: number): Promise<boolean>;
  
  // Departments and Teachers
  getAllDepartments(): Promise<Department[]>;
  getAllTeachers(): Promise<Teacher[]>;
  getTeachersWithDistributions(): Promise<any[]>;
  
  // Material Requests
  getAllMaterialRequests(): Promise<any[]>;
  createMaterialRequestWithItems(requestData: any): Promise<any>;
  
  // Distribution
  createDistribution(distribution: InsertDistribution): Promise<Distribution>;
  getDistributionSummary(): Promise<any>;
  generateDistributionReceipt(teacherId: number): Promise<any>;
  
  // Maintenance
  getAllMaintenanceTasks(): Promise<any[]>;
  getMaintenanceTimeline(): Promise<any[]>;
  createMaintenanceTask(task: InsertMaintenanceTask): Promise<MaintenanceTask>;
  
  // Dashboard
  getDashboardData(): Promise<any>;
  
  // Backup
  createBackup(): Promise<any>;
  
  // Session store for auth
  sessionStore: any;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private roles: Map<number, Role>;
  private inventoryItems: Map<number, InventoryItem>;
  private departments: Map<number, Department>;
  private teachers: Map<number, Teacher>;
  private materialRequests: Map<number, MaterialRequest>;
  private requestItems: Map<number, RequestItem>;
  private distributions: Map<number, Distribution>;
  private maintenanceTasks: Map<number, MaintenanceTask>;
  
  // Session store for auth
  public sessionStore: any;
  
  // Current ID counters for each entity
  private userIdCounter: number;
  private roleIdCounter: number;
  private inventoryItemIdCounter: number;
  private departmentIdCounter: number;
  private teacherIdCounter: number;
  private materialRequestIdCounter: number;
  private requestItemIdCounter: number;
  private distributionIdCounter: number;
  private maintenanceTaskIdCounter: number;


  constructor() {
    // Initialize maps for each entity
    this.users = new Map();
    this.roles = new Map();
    this.inventoryItems = new Map();
    this.departments = new Map();
    this.teachers = new Map();
    this.materialRequests = new Map();
    this.requestItems = new Map();
    this.distributions = new Map();
    this.maintenanceTasks = new Map();
    
    // Initialize ID counters
    this.userIdCounter = 1;
    this.roleIdCounter = 1;
    this.inventoryItemIdCounter = 1;
    this.departmentIdCounter = 1;
    this.teacherIdCounter = 1;
    this.materialRequestIdCounter = 1;
    this.requestItemIdCounter = 1;
    this.distributionIdCounter = 1;
    this.maintenanceTaskIdCounter = 1;
    
    // Initialize session store
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24 hours
    });
    
    // Initialize with some sample data
    this.initializeData();
  }

  // Initialize with sample data
  private initializeData() {
    // Create roles
    const adminRole = this.createRole({
      name: "Admin",
      permissions: ["all"]
    });
    
    const teacherRole = this.createRole({
      name: "Teacher",
      permissions: ["view"]
    });
    
    const managerRole = this.createRole({
      name: "Manager",
      permissions: ["manage", "view", "edit"]
    });
    
    // Create users
    this.createUser({
      username: "admin",
      password: "admin123",
      fullName: "محمد المغربي",
      email: "admin@school.ma",
      roleId: adminRole.id,
      status: "active"
    });
    
    this.createUser({
      username: "manager",
      password: "manager123",
      fullName: "نادية العلوي",
      email: "manager@school.ma",
      roleId: managerRole.id,
      status: "active"
    });
    
    this.createUser({
      username: "user",
      password: "user123",
      fullName: "سمير الفاسي",
      email: "user@school.ma",
      roleId: teacherRole.id,
      status: "active"
    });
    
    // Create departments
    const arabicDept = this.createDepartment({ name: "اللغة العربية" });
    const scienceDept = this.createDepartment({ name: "العلوم" });
    const mathDept = this.createDepartment({ name: "الرياضيات" });
    const frenchDept = this.createDepartment({ name: "اللغة الفرنسية" });
    const peDept = this.createDepartment({ name: "التربية البدنية" });
    const artDept = this.createDepartment({ name: "الفنون" });
    const englishDept = this.createDepartment({ name: "اللغة الإنجليزية" });
    const islamicDept = this.createDepartment({ name: "التربية الإسلامية" });
    
    // Create teachers
    const teacher1 = this.createTeacher({
      name: "فاطمة المغربي",
      departmentId: arabicDept.id,
      email: "fatima@school.ma",
      phone: "+212600000000"
    });
    
    const teacher2 = this.createTeacher({
      name: "أحمد العلوي",
      departmentId: scienceDept.id,
      email: "ahmed@school.ma",
      phone: "+212600000001"
    });
    
    const teacher3 = this.createTeacher({
      name: "مريم الفاسي",
      departmentId: mathDept.id,
      email: "mariam@school.ma",
      phone: "+212600000002"
    });
    
    const teacher4 = this.createTeacher({
      name: "يوسف الرباطي",
      departmentId: frenchDept.id,
      email: "youssef@school.ma",
      phone: "+212600000003"
    });
    
    const teacher5 = this.createTeacher({
      name: "ليلى البيضاوي",
      departmentId: englishDept.id,
      email: "layla@school.ma",
      phone: "+212600000004"
    });
    
    const teacher6 = this.createTeacher({
      name: "عمر الزموري",
      departmentId: peDept.id,
      email: "omar@school.ma",
      phone: "+212600000005"
    });
    
    const teacher7 = this.createTeacher({
      name: "سلمى الحسني",
      departmentId: artDept.id,
      email: "salma@school.ma",
      phone: "+212600000006"
    });
    
    const teacher8 = this.createTeacher({
      name: "خالد المرابطي",
      departmentId: islamicDept.id,
      email: "khalid@school.ma",
      phone: "+212600000007"
    });
    
    // Create inventory items - Furniture
    this.createInventoryItem({
      name: "طاولات مدرسية مغربية",
      sku: "SKU-MF2401",
      category: "furniture",
      location: "المبنى المركزي، الطابق 1",
      status: "new",
      quantity: 35,
      description: "طاولات مدرسية مصنوعة محلياً في فاس",
      icon: "desk",
      serialNumber: "MF-2023-0012",
      inventoryNumber: "INV-FUR-035",
      classification: "C"
    });
    
    this.createInventoryItem({
      name: "كراسي طلاب بنية اللون",
      sku: "SKU-MF2402",
      category: "furniture",
      location: "المبنى المركزي، الطابق 1",
      status: "fair",
      quantity: 45,
      description: "كراسي مدرسية للطلاب مصنوعة من الخشب المتين",
      icon: "armchair",
      serialNumber: "MF-2023-0013",
      inventoryNumber: "INV-FUR-045",
      classification: "C"
    });
    
    this.createInventoryItem({
      name: "مكاتب للمعلمين",
      sku: "SKU-MF2403",
      category: "furniture",
      location: "غرف المعلمين",
      status: "new",
      quantity: 15,
      description: "مكاتب كبيرة للمعلمين مع أدراج تخزين",
      icon: "table-2",
      serialNumber: "MF-2023-0014",
      inventoryNumber: "INV-FUR-015",
      classification: "B"
    });
    
    this.createInventoryItem({
      name: "خزانات حفظ الملفات",
      sku: "SKU-MF2404",
      category: "furniture",
      location: "الإدارة، الطابق الأرضي",
      status: "new",
      quantity: 8,
      description: "خزانات معدنية لحفظ الملفات والوثائق المدرسية",
      icon: "file-cabinet",
      serialNumber: "MF-2023-0015",
      inventoryNumber: "INV-FUR-008",
      classification: "B"
    });
    
    // Books and Educational Materials
    this.createInventoryItem({
      name: "طقم كتب المقرر الوطني",
      sku: "SKU-BK5823",
      category: "books",
      location: "مكتبة المدرسة، رف 7",
      status: "fair",
      quantity: 120,
      description: "كتب المنهج الرسمي للمرحلة الابتدائية",
      icon: "book-2",
      serialNumber: "BK-2023-0541",
      inventoryNumber: "INV-BOK-120",
      classification: "D"
    });
    
    this.createInventoryItem({
      name: "قواميس اللغة العربية",
      sku: "SKU-BK5824",
      category: "books",
      location: "مكتبة المدرسة، رف 3",
      status: "new",
      quantity: 25,
      description: "قواميس لغوية عربية للطلاب والمعلمين",
      icon: "book-open",
      serialNumber: "BK-2023-0542",
      inventoryNumber: "INV-BOK-025",
      classification: "C"
    });
    
    this.createInventoryItem({
      name: "كتب القراءة الإضافية",
      sku: "SKU-BK5825",
      category: "books",
      location: "مكتبة المدرسة، رف 9",
      status: "fair",
      quantity: 85,
      description: "مجموعة كتب قراءة متنوعة لتشجيع القراءة لدى الطلاب",
      icon: "book-open",
      serialNumber: "BK-2023-0543",
      inventoryNumber: "INV-BOK-085",
      classification: "D"
    });
    
    this.createInventoryItem({
      name: "أطالس جغرافية",
      sku: "SKU-BK5826",
      category: "books",
      location: "مكتبة المدرسة، رف 5",
      status: "worn",
      quantity: 18,
      description: "أطالس عالمية ومحلية للدراسات الاجتماعية",
      icon: "globe",
      serialNumber: "BK-2023-0544",
      inventoryNumber: "INV-BOK-018",
      classification: "C"
    });
    
    // Technology Items
    this.createInventoryItem({
      name: "سبورات تفاعلية",
      sku: "SKU-T6742",
      category: "technology",
      location: "قاعات الطابق الثاني",
      status: "maintenance",
      quantity: 5,
      description: "سبورات ذكية تفاعلية مع برمجيات تعليمية",
      icon: "monitor",
      serialNumber: "T-2022-0083",
      inventoryNumber: "INV-TECH-028",
      classification: "B"
    });
    
    this.createInventoryItem({
      name: "أجهزة حاسوب محمولة",
      sku: "SKU-T6743",
      category: "technology",
      location: "معمل الحاسوب",
      status: "fair",
      quantity: 20,
      description: "حواسيب محمولة للاستخدام في الفصول الدراسية",
      icon: "laptop",
      serialNumber: "T-2022-0084",
      inventoryNumber: "INV-TECH-020",
      classification: "B"
    });
    
    this.createInventoryItem({
      name: "أجهزة عرض (بروجكتور)",
      sku: "SKU-T6744",
      category: "technology",
      location: "مخزن التقنيات، الطابق الأول",
      status: "new",
      quantity: 10,
      description: "أجهزة عرض عالية الجودة للفصول الدراسية",
      icon: "projector",
      serialNumber: "T-2022-0085",
      inventoryNumber: "INV-TECH-010",
      classification: "A"
    });
    
    this.createInventoryItem({
      name: "شاشات عرض كبيرة",
      sku: "SKU-T6745",
      category: "technology",
      location: "مخزن التقنيات، الطابق الأول",
      status: "new",
      quantity: 6,
      description: "شاشات LED كبيرة للاستخدام في القاعات الكبيرة",
      icon: "tv",
      serialNumber: "T-2022-0086",
      inventoryNumber: "INV-TECH-006",
      classification: "A"
    });
    
    // Educational Supplies
    this.createInventoryItem({
      name: "طقم أدوات هندسية للرياضيات",
      sku: "SKU-S8901",
      category: "supplies",
      location: "مخزن المواد التعليمية، خزانة 3",
      status: "new",
      quantity: 48,
      description: "أدوات هندسية للاستخدام في دروس الرياضيات",
      icon: "ruler",
      serialNumber: "S-2023-0215",
      inventoryNumber: "INV-SUP-048",
      classification: "D"
    });
    
    this.createInventoryItem({
      name: "أقلام سبورة ملونة",
      sku: "SKU-S3298",
      category: "supplies",
      location: "المخزن الرئيسي، رف 3",
      status: "low-stock",
      quantity: 8,
      description: "أقلام سبورة بيضاء متعددة الألوان",
      icon: "pen",
      serialNumber: "S-2023-0128",
      inventoryNumber: "INV-SUP-008",
      classification: "E"
    });
    
    this.createInventoryItem({
      name: "نماذج تشريحية للعلوم",
      sku: "SKU-S3299",
      category: "supplies",
      location: "مختبر العلوم",
      status: "fair",
      quantity: 15,
      description: "نماذج تشريحية لجسم الإنسان والحيوانات للدراسات العلمية",
      icon: "flask-round",
      serialNumber: "S-2023-0129",
      inventoryNumber: "INV-SUP-015",
      classification: "C"
    });
    
    this.createInventoryItem({
      name: "مواد فنية وألوان",
      sku: "SKU-S3300",
      category: "supplies",
      location: "قاعة الفنون",
      status: "fair",
      quantity: 40,
      description: "مجموعة متنوعة من المواد الفنية والألوان للأنشطة الفنية",
      icon: "palette",
      serialNumber: "S-2023-0130",
      inventoryNumber: "INV-SUP-040",
      classification: "D"
    });
    
    // Sports Equipment
    this.createInventoryItem({
      name: "كرات قدم مدرسية",
      sku: "SKU-SP7421",
      category: "sports",
      location: "مخزن الصالة الرياضية",
      status: "worn",
      quantity: 12,
      description: "كرات قدم للأنشطة الرياضية المدرسية",
      icon: "ball-football",
      serialNumber: "SP-2022-0032",
      inventoryNumber: "INV-SPT-012",
      classification: "E"
    });
    
    this.createInventoryItem({
      name: "معدات جمباز",
      sku: "SKU-SP7422",
      category: "sports",
      location: "الصالة الرياضية",
      status: "fair",
      quantity: 8,
      description: "معدات جمباز متنوعة للتربية البدنية",
      icon: "gymnastics",
      serialNumber: "SP-2022-0033",
      inventoryNumber: "INV-SPT-008",
      classification: "C"
    });
    
    this.createInventoryItem({
      name: "شبكات كرة طائرة",
      sku: "SKU-SP7423",
      category: "sports",
      location: "الملعب الخارجي",
      status: "new",
      quantity: 3,
      description: "شبكات كرة طائرة كاملة مع الأعمدة",
      icon: "volleyball",
      serialNumber: "SP-2022-0034",
      inventoryNumber: "INV-SPT-003",
      classification: "C"
    });
    
    this.createInventoryItem({
      name: "أقماع تدريب",
      sku: "SKU-SP7424",
      category: "sports",
      location: "مخزن الصالة الرياضية",
      status: "fair",
      quantity: 32,
      description: "أقماع بلاستيكية ملونة للتدريبات الرياضية",
      icon: "cone",
      serialNumber: "SP-2022-0035",
      inventoryNumber: "INV-SPT-032",
      classification: "E"
    });
    

    
    // Create maintenance tasks
    this.createMaintenanceTask({
      title: "فحص أجهزة الكمبيوتر",
      description: "تم فحص وتحديث 15 جهاز كمبيوتر في معمل الحاسوب",
      itemId: 1,
      date: new Date("2023-04-02"),
      status: "completed",
      priority: "medium",
      assignedTo: 1
    });
    
    this.createMaintenanceTask({
      title: "صيانة تكييف الهواء",
      description: "فحص وتنظيف نظام التكييف المركزي",
      itemId: 2,
      date: new Date("2023-04-05"),
      status: "inprogress",
      priority: "medium",
      assignedTo: 1
    });
    
    this.createMaintenanceTask({
      title: "إصلاح أجهزة العرض",
      description: "إصلاح وصيانة جهازي العرض في قاعة المحاضرات",
      itemId: 3,
      date: new Date("2023-04-10"),
      status: "overdue",
      priority: "high",
      assignedTo: 1
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const currentTime = new Date();
    const user: User = { ...insertUser, id, lastLogin: null, createdAt: currentTime, updatedAt: currentTime };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      ...userData,
      updatedAt: new Date()
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Role methods
  async createRole(insertRole: any): Promise<Role> {
    const id = this.roleIdCounter++;
    const currentTime = new Date();
    const role: Role = { ...insertRole, id, createdAt: currentTime, updatedAt: currentTime };
    this.roles.set(id, role);
    return role;
  }

  async getAllRoles(): Promise<Role[]> {
    return Array.from(this.roles.values());
  }

  // Inventory methods
  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    return this.inventoryItems.get(id);
  }

  async getAllInventoryItems(): Promise<InventoryItem[]> {
    return Array.from(this.inventoryItems.values());
  }

  async getAvailableInventoryItems(): Promise<InventoryItem[]> {
    return Array.from(this.inventoryItems.values())
      .filter(item => item.quantity > 0);
  }

  async createInventoryItem(insertItem: InsertInventoryItem): Promise<InventoryItem> {
    const id = this.inventoryItemIdCounter++;
    const currentTime = new Date();
    const item: InventoryItem = { ...insertItem, id, createdAt: currentTime, updatedAt: currentTime };
    this.inventoryItems.set(id, item);
    return item;
  }

  async updateInventoryItem(id: number, itemData: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const item = this.inventoryItems.get(id);
    if (!item) return undefined;
    
    const updatedItem: InventoryItem = {
      ...item,
      ...itemData,
      updatedAt: new Date()
    };
    
    this.inventoryItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    return this.inventoryItems.delete(id);
  }

  // Department methods
  async createDepartment(insertDepartment: any): Promise<Department> {
    const id = this.departmentIdCounter++;
    const currentTime = new Date();
    const department: Department = { ...insertDepartment, id, createdAt: currentTime, updatedAt: currentTime };
    this.departments.set(id, department);
    return department;
  }

  async getAllDepartments(): Promise<Department[]> {
    return Array.from(this.departments.values());
  }

  // Teacher methods
  async createTeacher(insertTeacher: any): Promise<Teacher> {
    const id = this.teacherIdCounter++;
    const currentTime = new Date();
    const teacher: Teacher = { ...insertTeacher, id, createdAt: currentTime, updatedAt: currentTime };
    this.teachers.set(id, teacher);
    return teacher;
  }

  async getAllTeachers(): Promise<Teacher[]> {
    return Array.from(this.teachers.values());
  }

  async getTeachersWithDistributions(): Promise<any[]> {
    const teachers = Array.from(this.teachers.values());
    const departments = Array.from(this.departments.values());
    const distributions = Array.from(this.distributions.values());
    const items = Array.from(this.inventoryItems.values());
    
    return teachers.map(teacher => {
      const department = departments.find(d => d.id === teacher.departmentId);
      const teacherDistributions = distributions.filter(d => d.teacherId === teacher.id);
      
      const distributedItems = teacherDistributions.map(dist => {
        const item = items.find(i => i.id === dist.itemId);
        return {
          id: dist.id,
          name: item?.name || "Unknown Item",
          quantity: dist.quantity,
          date: dist.date.toLocaleDateString()
        };
      });
      
      return {
        id: teacher.id.toString(),
        name: teacher.name,
        department: department?.name || "Unknown Department",
        departmentId: teacher.departmentId.toString(),
        items: distributedItems
      };
    });
  }

  // Material Request methods
  async getAllMaterialRequests(): Promise<any[]> {
    const requests = Array.from(this.materialRequests.values());
    const teachers = Array.from(this.teachers.values());
    const departments = Array.from(this.departments.values());
    const requestItems = Array.from(this.requestItems.values());
    const items = Array.from(this.inventoryItems.values());
    
    return requests.map(request => {
      const teacher = teachers.find(t => t.id === request.teacherId);
      const department = departments.find(d => d.id === request.departmentId);
      const requestItemsList = requestItems.filter(ri => ri.requestId === request.id);
      
      const itemsList = requestItemsList.map(ri => {
        const item = items.find(i => i.id === ri.itemId);
        return {
          id: ri.id,
          name: item?.name || "Unknown Item",
          quantity: ri.quantity,
          notes: ri.notes
        };
      });
      
      return {
        id: request.id.toString(),
        teacherId: request.teacherId.toString(),
        teacherName: teacher?.name || "Unknown Teacher",
        department: department?.name || "Unknown Department",
        departmentId: request.departmentId.toString(),
        date: request.date.toLocaleDateString(),
        status: request.status,
        items: itemsList,
        source: request.source,
        reference: request.reference
      };
    });
  }

  async createMaterialRequestWithItems(requestData: any): Promise<any> {
    // First create the material request
    const { teacherId, department, date, source, items } = requestData;
    
    // Get department ID
    const departmentObj = Array.from(this.departments.values()).find(
      dept => dept.id.toString() === department || dept.name === department
    );
    
    if (!departmentObj) {
      throw new Error("Department not found");
    }
    
    const materialRequest = await this.createMaterialRequest({
      teacherId: parseInt(teacherId),
      departmentId: departmentObj.id,
      date: new Date(date),
      status: "pending",
      source: source,
      reference: `REQ-${new Date().getFullYear()}-${this.materialRequestIdCounter.toString().padStart(3, '0')}`
    });
    
    // Then create each request item
    const requestItems = await Promise.all(items.map(async (item: any) => {
      return await this.createRequestItem({
        requestId: materialRequest.id,
        itemId: parseInt(item.itemId),
        quantity: item.quantity,
        notes: item.notes
      });
    }));
    
    // Return the created request with items
    const teacher = await this.getTeacher(parseInt(teacherId));
    
    return {
      id: materialRequest.id.toString(),
      teacherId: materialRequest.teacherId.toString(),
      teacherName: teacher?.name || "Unknown Teacher",
      department: departmentObj.name,
      departmentId: materialRequest.departmentId.toString(),
      date: materialRequest.date.toLocaleDateString(),
      status: materialRequest.status,
      items: await Promise.all(requestItems.map(async (ri) => {
        const item = await this.getInventoryItem(ri.itemId);
        return {
          id: ri.id,
          name: item?.name || "Unknown Item",
          quantity: ri.quantity,
          notes: ri.notes
        };
      })),
      source: materialRequest.source,
      reference: materialRequest.reference
    };
  }

  async createMaterialRequest(insertRequest: InsertMaterialRequest): Promise<MaterialRequest> {
    const id = this.materialRequestIdCounter++;
    const currentTime = new Date();
    const request: MaterialRequest = { ...insertRequest, id, createdAt: currentTime, updatedAt: currentTime };
    this.materialRequests.set(id, request);
    return request;
  }

  async createRequestItem(insertRequestItem: InsertRequestItem): Promise<RequestItem> {
    const id = this.requestItemIdCounter++;
    const currentTime = new Date();
    const requestItem: RequestItem = { ...insertRequestItem, id, createdAt: currentTime, updatedAt: currentTime };
    this.requestItems.set(id, requestItem);
    return requestItem;
  }

  async getTeacher(id: number): Promise<Teacher | undefined> {
    return this.teachers.get(id);
  }

  // Distribution methods
  async createDistribution(insertDistribution: InsertDistribution): Promise<Distribution> {
    const id = this.distributionIdCounter++;
    const currentTime = new Date();
    
    // Generate receipt number
    const receiptNumber = `DIST-${new Date().getFullYear()}-${id.toString().padStart(3, '0')}`;
    
    const distribution: Distribution = { 
      ...insertDistribution, 
      id, 
      receiptNumber,
      createdAt: currentTime, 
      updatedAt: currentTime 
    };
    
    this.distributions.set(id, distribution);
    
    // Update inventory quantity
    const item = await this.getInventoryItem(insertDistribution.itemId);
    if (item) {
      const newQuantity = Math.max(0, item.quantity - insertDistribution.quantity);
      await this.updateInventoryItem(item.id, { quantity: newQuantity });
      
      // If quantity is low, update status
      if (newQuantity <= 5 && item.status !== 'low-stock') {
        await this.updateInventoryItem(item.id, { status: 'low-stock' });
      }
    }
    
    return distribution;
  }

  async getDistributionSummary(): Promise<any> {
    const teachers = Array.from(this.teachers.values());
    const distributions = Array.from(this.distributions.values());
    
    // Get total number of teachers
    const teacherCount = teachers.length;
    
    // Get total number of distributed items
    const totalItems = distributions.reduce((sum, dist) => sum + dist.quantity, 0);
    
    // Get number of teachers without items
    const teachersWithItems = new Set(distributions.map(dist => dist.teacherId));
    const emptyTeacherCount = teacherCount - teachersWithItems.size;
    
    return {
      teacherCount,
      totalItems,
      emptyTeacherCount
    };
  }

  async generateDistributionReceipt(teacherId: number): Promise<any> {
    const teacher = await this.getTeacher(teacherId);
    if (!teacher) {
      throw new Error("Teacher not found");
    }
    
    const department = await this.getDepartment(teacher.departmentId);
    const distributions = Array.from(this.distributions.values())
      .filter(dist => dist.teacherId === teacherId);
    
    const items = await Promise.all(distributions.map(async (dist) => {
      const item = await this.getInventoryItem(dist.itemId);
      return {
        name: item?.name || "Unknown Item",
        quantity: dist.quantity,
        date: dist.date.toLocaleDateString()
      };
    }));
    
    return {
      teacherName: teacher.name,
      department: department?.name || "Unknown Department",
      items,
      date: new Date().toLocaleDateString(),
      receiptNumber: `RCPT-${teacherId}-${Date.now()}`
    };
  }

  async getDepartment(id: number): Promise<Department | undefined> {
    return this.departments.get(id);
  }

  // Maintenance methods
  async getAllMaintenanceTasks(): Promise<any[]> {
    const tasks = Array.from(this.maintenanceTasks.values());
    const items = Array.from(this.inventoryItems.values());
    
    return tasks.map(task => {
      const item = items.find(i => i.id === task.itemId);
      
      return {
        id: task.id.toString(),
        title: task.title,
        description: task.description,
        itemId: task.itemId.toString(),
        itemName: item?.name || "Unknown Item",
        date: task.date.toLocaleDateString(),
        dateRaw: task.date.toISOString(),
        status: task.status,
        priority: task.priority
      };
    });
  }

  async getMaintenanceTimeline(): Promise<any[]> {
    const tasks = Array.from(this.maintenanceTasks.values())
      .sort((a, b) => {
        // Sort by date and then by status priority
        if (a.date.getTime() !== b.date.getTime()) {
          return b.date.getTime() - a.date.getTime(); // Newest first
        }
        
        // Status priority: overdue > inprogress > pending > completed
        const statusPriority: Record<string, number> = {
          'overdue': 0,
          'inprogress': 1,
          'pending': 2,
          'completed': 3
        };
        
        return statusPriority[a.status] - statusPriority[b.status];
      });
    
    const items = Array.from(this.inventoryItems.values());
    
    return tasks.map(task => {
      const item = items.find(i => i.id === task.itemId);
      
      return {
        id: task.id.toString(),
        title: task.title,
        description: task.description,
        itemName: item?.name || "Unknown Item",
        date: task.date.toLocaleDateString(),
        dateRaw: task.date.toISOString(),
        status: task.status,
        priority: task.priority
      };
    });
  }

  async createMaintenanceTask(insertTask: InsertMaintenanceTask): Promise<MaintenanceTask> {
    const id = this.maintenanceTaskIdCounter++;
    const currentTime = new Date();
    const task: MaintenanceTask = { 
      ...insertTask, 
      id, 
      completedAt: null,
      createdAt: currentTime, 
      updatedAt: currentTime 
    };
    
    this.maintenanceTasks.set(id, task);
    
    // If the item is being maintained, update its status
    if (task.status === 'inprogress') {
      const item = await this.getInventoryItem(task.itemId);
      if (item) {
        await this.updateInventoryItem(item.id, { status: 'maintenance' });
      }
    }
    
    return task;
  }

  // Budget and Transaction methods
  async getAllTransactions(): Promise<any[]> {
    return Array.from(this.transactions.values())
      .sort((a, b) => b.date.getTime() - a.date.getTime()) // Newest first
      .map(trans => ({
        id: trans.id.toString(),
        title: trans.title,
        reference: trans.reference || `TRX-${trans.id}`,
        type: trans.type,
        amount: trans.amount,
        category: trans.category,
        date: trans.date.toLocaleDateString(),
        status: trans.status,
        description: trans.description
      }));
  }

  async getBudgetSummary(): Promise<any> {
    const currentYear = new Date().getFullYear();
    const budget = Array.from(this.budgets.values())
      .find(b => b.year === currentYear);
    
    if (!budget) {
      return {
        total: 0,
        expenses: 0,
        remaining: 0,
        usedPercentage: 0,
        remainingPercentage: 100,
        expenseChangePercentage: 0
      };
    }
    
    const transactions = Array.from(this.transactions.values());
    
    // Calculate total expenses
    const expenses = transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    
    // Calculate total income
    const income = transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    
    // Calculate total budget (initial + income)
    const totalBudget = budget.totalAmount + income;
    
    // Calculate remaining budget
    const remaining = totalBudget - expenses;
    
    // Calculate percentages
    const usedPercentage = Math.round((expenses / totalBudget) * 100);
    const remainingPercentage = Math.round((remaining / totalBudget) * 100);
    
    // Calculate expense change percentage (compared to previous month)
    const currentMonth = new Date().getMonth();
    const previousMonth = currentMonth === 0 ? 11 : currentMonth - 1;
    
    const currentMonthExpenses = transactions
      .filter(t => t.type === 'expense' && t.date.getMonth() === currentMonth)
      .reduce((sum, t) => sum + t.amount, 0);
    
    const previousMonthExpenses = transactions
      .filter(t => t.type === 'expense' && t.date.getMonth() === previousMonth)
      .reduce((sum, t) => sum + t.amount, 0);
    
    const expenseChangePercentage = previousMonthExpenses === 0 
      ? 0 
      : Math.round(((currentMonthExpenses - previousMonthExpenses) / previousMonthExpenses) * 100);
    
    return {
      total: totalBudget,
      expenses,
      remaining,
      usedPercentage,
      remainingPercentage,
      expenseChangePercentage
    };
  }

  async getBudgetCharts(): Promise<any> {
    const transactions = Array.from(this.transactions.values());
    
    // Data for monthly expenses by category
    const categories = ['stationery', 'technology', 'maintenance', 'furniture', 'books'];
    const months = [0, 1, 2, 3, 4, 5]; // First 6 months
    
    const monthlyExpenses: Record<string, number[]> = {};
    
    // Initialize with zeros
    categories.forEach(category => {
      monthlyExpenses[category] = months.map(() => 0);
    });
    
    // Fill with actual data
    transactions
      .filter(t => t.type === 'expense')
      .forEach(t => {
        const month = t.date.getMonth();
        if (months.includes(month) && categories.includes(t.category)) {
          monthlyExpenses[t.category][month] += t.amount;
        }
      });
    
    // Data for budget distribution by category
    const budgetDistribution = categories.map(category => {
      return transactions
        .filter(t => t.type === 'expense' && t.category === category)
        .reduce((sum, t) => sum + t.amount, 0);
    });
    
    return {
      monthlyExpenses,
      budgetDistribution
    };
  }

  async createBudget(insertBudget: InsertBudget): Promise<Budget> {
    const id = this.budgetIdCounter++;
    const currentTime = new Date();
    const budget: Budget = { ...insertBudget, id, createdAt: currentTime, updatedAt: currentTime };
    this.budgets.set(id, budget);
    return budget;
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionIdCounter++;
    const currentTime = new Date();
    const transaction: Transaction = { ...insertTransaction, id, createdAt: currentTime, updatedAt: currentTime };
    this.transactions.set(id, transaction);
    return transaction;
  }

  // Dashboard data
  async getDashboardData(): Promise<any> {
    const inventoryItems = await this.getAllInventoryItems();
    const requests = await this.getAllMaterialRequests();
    const maintenanceTasks = await this.getAllMaintenanceTasks();
    
    // Get low stock items for alerts
    const lowStockItems = inventoryItems
      .filter(item => item.status === 'low-stock')
      .map(item => ({
        id: item.id.toString(),
        name: item.name,
        quantity: item.quantity
      }));
    
    // Get overdue maintenance tasks for alerts
    const overdueTasks = maintenanceTasks
      .filter(task => task.status === 'overdue')
      .map(task => ({
        id: task.id,
        task: task.title,
        due: task.date
      }));
    
    // Generate sample recent activity based on real school data
    const recentActivity = [
      {
        id: '1',
        type: 'distribution',
        user: 'أحمد العلوي',
        action: 'قام بتوزيع كتب الرياضيات على الصف الثاني',
        timestamp: 'منذ ساعتين'
      },
      {
        id: '2',
        type: 'request',
        user: 'فاطمة المغربي',
        action: 'قدمت طلباً للحصول على مواد علمية للمختبر',
        timestamp: 'أمس، 15:45'
      },
      {
        id: '3',
        type: 'maintenance',
        user: 'مريم الفاسي',
        action: 'أجهزة العرض في قاعة الاجتماعات',
        timestamp: 'منذ يومين'
      }
    ];
    
    return {
      inventory: {
        total: inventoryItems.reduce((sum, item) => sum + item.quantity, 0),
        change: {
          value: 5.2,
          isPositive: true
        }
      },
      requests: {
        pending: requests.filter(req => req.status === 'pending').length,
        change: {
          value: 12.3,
          isPositive: false
        }
      },
      maintenance: {
        total: maintenanceTasks.length,
        overdue: maintenanceTasks.filter(task => task.status === 'overdue').length
      },
      alerts: {
        low_stock: lowStockItems,
        maintenance: overdueTasks,
        others: []
      },
      recentActivity,
      // Add school data from the provided information
      school: {
        name: "ثانوية الوحدة الإعدادية",
        code: "87000S11",
        foundedYear: "1985",
        location: "تطريكت، سلا المدينة",
        region: "جهة الرباط-سلا-القنيطرة",
        type: "مدرسة إعدادية عمومية"
      }
    };
  }

  // Backup functionality
  async createBackup(): Promise<any> {
    const backup = {
      timestamp: new Date().toISOString(),
      data: {
        users: Array.from(this.users.values()),
        roles: Array.from(this.roles.values()),
        inventoryItems: Array.from(this.inventoryItems.values()),
        departments: Array.from(this.departments.values()),
        teachers: Array.from(this.teachers.values()),
        materialRequests: Array.from(this.materialRequests.values()),
        requestItems: Array.from(this.requestItems.values()),
        distributions: Array.from(this.distributions.values()),
        maintenanceTasks: Array.from(this.maintenanceTasks.values())
      },
      school: {
        name: "ثانوية الوحدة الإعدادية",
        code: "87000S11",
        foundedYear: "1985",
        location: "تطريكت، سلا المدينة",
        region: "جهة الرباط-سلا-القنيطرة",
        type: "مدرسة إعدادية عمومية"
      }
    };
    
    return {
      success: true,
      message: "Backup created successfully",
      timestamp: backup.timestamp,
      size: JSON.stringify(backup).length
    };
  }
}

// Set up Memory store for sessions
const MemoryStore = createMemoryStore(session);

// Database storage implementation
export class DatabaseStorage implements IStorage {
  public sessionStore: any;

  constructor() {
    // Initialize session store with PostgreSQL
    const PostgresSessionStore = connectPgSimple(session);
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...userData, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return !!result;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getAllRoles(): Promise<Role[]> {
    return await db.select().from(roles);
  }

  // Inventory methods
  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    const [item] = await db.select().from(inventoryItems).where(eq(inventoryItems.id, id));
    return item || undefined;
  }

  async getAllInventoryItems(): Promise<InventoryItem[]> {
    return await db.select().from(inventoryItems);
  }

  async getAvailableInventoryItems(): Promise<InventoryItem[]> {
    return await db
      .select()
      .from(inventoryItems)
      .where(sql`${inventoryItems.quantity} > 0`);
  }

  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const [createdItem] = await db.insert(inventoryItems).values(item).returning();
    return createdItem;
  }

  async updateInventoryItem(id: number, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const [updatedItem] = await db
      .update(inventoryItems)
      .set({ ...item, updatedAt: new Date() })
      .where(eq(inventoryItems.id, id))
      .returning();
    return updatedItem || undefined;
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    const result = await db.delete(inventoryItems).where(eq(inventoryItems.id, id));
    return !!result;
  }

  // Department methods
  async getAllDepartments(): Promise<Department[]> {
    return await db.select().from(departments);
  }

  // Teacher methods
  async getAllTeachers(): Promise<Teacher[]> {
    return await db.select().from(teachers);
  }

  async getTeachersWithDistributions(): Promise<any[]> {
    const allTeachers = await db.select().from(teachers);
    const allDepartments = await db.select().from(departments);
    const allDistributions = await db.select().from(distributions);
    const allItems = await db.select().from(inventoryItems);
    
    return allTeachers.map(teacher => {
      const department = allDepartments.find(d => d.id === teacher.departmentId);
      const teacherDistributions = allDistributions.filter(d => d.teacherId === teacher.id);
      
      const distributedItems = teacherDistributions.map(dist => {
        const item = allItems.find(i => i.id === dist.itemId);
        return {
          id: dist.id,
          name: item?.name || "Unknown Item",
          quantity: dist.quantity,
          date: dist.date instanceof Date ? dist.date.toLocaleDateString() : String(dist.date)
        };
      });
      
      return {
        id: teacher.id.toString(),
        name: teacher.name,
        department: department?.name || "Unknown Department",
        departmentId: teacher.departmentId.toString(),
        items: distributedItems
      };
    });
  }

  // Material Request methods
  async getAllMaterialRequests(): Promise<any[]> {
    const allRequests = await db.select().from(materialRequests);
    const allTeachers = await db.select().from(teachers);
    const allDepartments = await db.select().from(departments);
    const allRequestItems = await db.select().from(requestItems);
    const allItems = await db.select().from(inventoryItems);
    
    return allRequests.map(request => {
      const teacher = allTeachers.find(t => t.id === request.teacherId);
      const department = allDepartments.find(d => d.id === request.departmentId);
      const requestItemsList = allRequestItems.filter(ri => ri.requestId === request.id);
      
      const itemsList = requestItemsList.map(ri => {
        const item = allItems.find(i => i.id === ri.itemId);
        return {
          id: ri.id,
          name: item?.name || "Unknown Item",
          quantity: ri.quantity,
          notes: ri.notes
        };
      });
      
      return {
        id: request.id.toString(),
        teacherId: request.teacherId.toString(),
        teacherName: teacher?.name || "Unknown Teacher",
        department: department?.name || "Unknown Department",
        departmentId: request.departmentId.toString(),
        date: request.date instanceof Date ? request.date.toLocaleDateString() : String(request.date),
        status: request.status,
        items: itemsList,
        source: request.source,
        reference: request.reference
      };
    });
  }

  async createMaterialRequestWithItems(requestData: any): Promise<any> {
    // Start transaction for atomic operation
    return await db.transaction(async (tx) => {
      const { teacherId, department, date, source, items } = requestData;
      
      // Get department
      const [departmentObj] = await tx
        .select()
        .from(departments)
        .where(
          sql`${departments.id}::text = ${department} OR ${departments.name} = ${department}`
        );
      
      if (!departmentObj) {
        throw new Error("Department not found");
      }
      
      // Create material request
      const [materialRequest] = await tx
        .insert(materialRequests)
        .values({
          teacherId: parseInt(teacherId),
          departmentId: departmentObj.id,
          date: new Date(date),
          status: "pending",
          source: source,
          reference: `REQ-${new Date().getFullYear()}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`
        })
        .returning();
      
      // Create request items
      const requestItemsPromises = items.map(async (item: any) => {
        const [requestItem] = await tx
          .insert(requestItems)
          .values({
            requestId: materialRequest.id,
            itemId: parseInt(item.itemId),
            quantity: item.quantity,
            notes: item.notes
          })
          .returning();
        return requestItem;
      });
      
      const requestItemsCreated = await Promise.all(requestItemsPromises);
      
      // Get teacher info
      const [teacher] = await tx
        .select()
        .from(teachers)
        .where(eq(teachers.id, parseInt(teacherId)));
      
      return {
        id: materialRequest.id.toString(),
        teacherId: materialRequest.teacherId.toString(),
        teacherName: teacher?.name || "Unknown Teacher",
        department: departmentObj.name,
        departmentId: departmentObj.id.toString(),
        date: materialRequest.date instanceof Date ? materialRequest.date.toLocaleDateString() : String(materialRequest.date),
        status: materialRequest.status,
        items: requestItemsCreated.map(ri => ({
          id: ri.id,
          itemId: ri.itemId,
          quantity: ri.quantity,
          notes: ri.notes
        })),
        source: materialRequest.source,
        reference: materialRequest.reference
      };
    });
  }

  // Distribution methods
  async createDistribution(distribution: InsertDistribution): Promise<Distribution> {
    const [createdDistribution] = await db
      .insert(distributions)
      .values(distribution)
      .returning();
    return createdDistribution;
  }

  async getDistributionSummary(): Promise<any> {
    const allTeachers = await db.select().from(teachers);
    const allDistributions = await db.select().from(distributions);
    const allItems = await db.select().from(inventoryItems);
    
    const teachersWithItems = allTeachers.reduce((acc, teacher) => {
      const teacherDistributions = allDistributions.filter(d => d.teacherId === teacher.id);
      const itemsCount = teacherDistributions.reduce((sum, dist) => sum + dist.quantity, 0);
      
      if (itemsCount > 0) {
        acc.teachersWithItems++;
      } else {
        acc.teachersWithoutItems++;
      }
      
      acc.totalItemsDistributed += itemsCount;
      return acc;
    }, { teachersWithItems: 0, teachersWithoutItems: 0, totalItemsDistributed: 0 });
    
    // Top items by distribution
    const itemDistribution = allDistributions.reduce((acc, dist) => {
      const itemId = dist.itemId;
      if (!acc[itemId]) {
        acc[itemId] = 0;
      }
      acc[itemId] += dist.quantity;
      return acc;
    }, {} as Record<number, number>);
    
    const topItems = Object.entries(itemDistribution)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([itemId, quantity]) => {
        const item = allItems.find(i => i.id === Number(itemId));
        return {
          name: item?.name || "Unknown Item",
          quantity
        };
      });
    
    return {
      summary: {
        teachersWithItems: teachersWithItems.teachersWithItems,
        teachersWithoutItems: teachersWithItems.teachersWithoutItems,
        totalItemsDistributed: teachersWithItems.totalItemsDistributed
      },
      topItems
    };
  }

  async generateDistributionReceipt(teacherId: number): Promise<any> {
    const [teacher] = await db
      .select()
      .from(teachers)
      .where(eq(teachers.id, teacherId));
    
    if (!teacher) {
      throw new Error("Teacher not found");
    }
    
    const [department] = await db
      .select()
      .from(departments)
      .where(eq(departments.id, teacher.departmentId));
    
    const teacherDistributions = await db
      .select()
      .from(distributions)
      .where(eq(distributions.teacherId, teacherId));
    
    const distributedItems = await Promise.all(
      teacherDistributions.map(async (dist) => {
        const [item] = await db
          .select()
          .from(inventoryItems)
          .where(eq(inventoryItems.id, dist.itemId));
        
        return {
          name: item?.name || "Unknown Item",
          quantity: dist.quantity,
          category: item?.category || "Unknown",
          date: dist.date instanceof Date ? dist.date.toLocaleDateString() : String(dist.date)
        };
      })
    );
    
    return {
      teacher: {
        name: teacher.name,
        department: department?.name || "Unknown Department",
        email: teacher.email,
        phone: teacher.phone
      },
      items: distributedItems,
      receiptDate: new Date().toLocaleDateString(),
      receiptNumber: `RCP-${new Date().getFullYear()}-${teacherId}-${Date.now().toString().slice(-4)}`
    };
  }

  // Maintenance methods
  async getAllMaintenanceTasks(): Promise<any[]> {
    const allTasks = await db.select().from(maintenanceTasks);
    const allItems = await db.select().from(inventoryItems);
    const allUsers = await db.select().from(users);
    
    return allTasks.map(task => {
      const item = allItems.find(i => i.id === task.itemId);
      const user = allUsers.find(u => u.id === task.assignedTo);
      
      return {
        id: task.id,
        title: task.title,
        description: task.description,
        item: item?.name || "Unknown Item",
        itemId: task.itemId,
        date: task.date instanceof Date ? task.date.toLocaleDateString() : String(task.date),
        status: task.status,
        priority: task.priority,
        assignedTo: task.assignedTo,
        assignedName: user?.fullName || "Unknown User"
      };
    });
  }

  async getMaintenanceTimeline(): Promise<any[]> {
    const today = new Date();
    const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    
    const tasks = await db
      .select()
      .from(maintenanceTasks)
      .orderBy(maintenanceTasks.date);
    
    const overdueTasks = tasks.filter(task => {
      const taskDate = task.date instanceof Date ? task.date : new Date(task.date);
      return taskDate < today && task.status !== "completed";
    });
    
    const upcomingTasks = tasks.filter(task => {
      const taskDate = task.date instanceof Date ? task.date : new Date(task.date);
      return taskDate >= today && taskDate <= endOfMonth;
    });
    
    // Combine tasks in chronological order
    const timeline = [...overdueTasks, ...upcomingTasks];
    
    // Get related data for each task
    const allItems = await db.select().from(inventoryItems);
    const allUsers = await db.select().from(users);
    
    return timeline.map(task => {
      const item = allItems.find(i => i.id === task.itemId);
      const user = allUsers.find(u => u.id === task.assignedTo);
      
      return {
        id: task.id,
        title: task.title,
        description: task.description,
        item: item?.name || "Unknown Item",
        itemId: task.itemId,
        date: task.date instanceof Date ? task.date.toLocaleDateString() : String(task.date),
        status: task.status,
        priority: task.priority,
        isOverdue: task.date < today && task.status !== "completed",
        assignedTo: task.assignedTo,
        assignedName: user?.fullName || "Unknown User"
      };
    });
  }

  async createMaintenanceTask(task: InsertMaintenanceTask): Promise<MaintenanceTask> {
    const [createdTask] = await db
      .insert(maintenanceTasks)
      .values(task)
      .returning();
    return createdTask;
  }

  // Dashboard methods
  async getDashboardData(): Promise<any> {
    // Get inventory statistics
    const inventoryItemsList = await db.select().from(inventoryItems);
    const totalInventory = inventoryItemsList.length;
    const lowStockItems = inventoryItemsList.filter(item => item.status === "low-stock").length;
    const maintenanceItems = inventoryItemsList.filter(item => item.status === "maintenance").length;
    
    // Get material requests statistics
    const requestsList = await db.select().from(materialRequests);
    const pendingRequests = requestsList.filter(req => req.status === "pending").length;
    
    // Get maintenance tasks statistics
    const tasksList = await db.select().from(maintenanceTasks);
    const overdueTasks = tasksList.filter(task => {
      const taskDate = task.date instanceof Date ? task.date : new Date(task.date);
      return taskDate < new Date() && task.status !== "completed";
    }).length;
    
    // Get distribution statistics
    const distributionsList = await db.select().from(distributions);
    const totalDistributed = distributionsList.reduce((sum, dist) => sum + dist.quantity, 0);
    
    // Get teachers statistics
    const teachersList = await db.select().from(teachers);
    const totalTeachers = teachersList.length;
    const teachersWithItems = new Set(distributionsList.map(d => d.teacherId)).size;
    
    // Get departments statistics
    const departmentsList = await db.select().from(departments);
    
    // Calculate items by category
    const categoryDistribution = inventoryItemsList.reduce((acc: Record<string, number>, item) => {
      if (!acc[item.category]) {
        acc[item.category] = 0;
      }
      acc[item.category] += item.quantity;
      return acc;
    }, {});
    
    // Calculate items by status
    const statusDistribution = inventoryItemsList.reduce((acc: Record<string, number>, item) => {
      if (!acc[item.status]) {
        acc[item.status] = 0;
      }
      acc[item.status] += item.quantity;
      return acc;
    }, {});
    
    return {
      inventory: {
        total: totalInventory,
        change: {
          value: 0, // No historical data in database yet
          isPositive: true
        }
      },
      requests: {
        pending: pendingRequests,
        total: requestsList.length
      },
      maintenance: {
        total: tasksList.length,
        overdue: overdueTasks
      },
      distribution: {
        total: totalDistributed,
        teachers: {
          total: totalTeachers,
          withItems: teachersWithItems,
          withoutItems: totalTeachers - teachersWithItems
        }
      },
      departments: departmentsList.map(dept => ({
        id: dept.id,
        name: dept.name
      })),
      charts: {
        categoryDistribution: Object.entries(categoryDistribution).map(([category, count]) => ({
          name: category,
          value: count
        })),
        statusDistribution: Object.entries(statusDistribution).map(([status, count]) => ({
          name: status,
          value: count
        }))
      }
    };
  }

  // Backup
  async createBackup(): Promise<any> {
    const allUsers = await db.select().from(users);
    const allRoles = await db.select().from(roles);
    const allInventoryItems = await db.select().from(inventoryItems);
    const allDepartments = await db.select().from(departments);
    const allTeachers = await db.select().from(teachers);
    const allMaterialRequests = await db.select().from(materialRequests);
    const allRequestItems = await db.select().from(requestItems);
    const allDistributions = await db.select().from(distributions);
    const allMaintenanceTasks = await db.select().from(maintenanceTasks);
    
    return {
      timestamp: new Date().toISOString(),
      data: {
        users: allUsers,
        roles: allRoles,
        inventoryItems: allInventoryItems,
        departments: allDepartments,
        teachers: allTeachers,
        materialRequests: allMaterialRequests,
        requestItems: allRequestItems,
        distributions: allDistributions,
        maintenanceTasks: allMaintenanceTasks
      }
    };
  }
}

// Use DatabaseStorage instead of MemStorage for persistence
// Using MemStorage for offline functionality
export const storage = new MemStorage();
