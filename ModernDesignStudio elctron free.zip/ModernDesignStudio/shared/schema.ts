import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar, doublePrecision, date, customType } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Custom enums for specific status types
const itemStatusEnum = customType<{
  data: 'new' | 'fair' | 'worn' | 'maintenance' | 'low-stock';
}>({
  dataType() {
    return 'text';
  },
});

const requestStatusEnum = customType<{
  data: 'pending' | 'approved' | 'delivered' | 'rejected' | 'processing';
}>({
  dataType() {
    return 'text';
  },
});

const transactionTypeEnum = customType<{
  data: 'income' | 'expense';
}>({
  dataType() {
    return 'text';
  },
});

const transactionStatusEnum = customType<{
  data: 'completed' | 'pending' | 'processing';
}>({
  dataType() {
    return 'text';
  },
});

const maintenanceStatusEnum = customType<{
  data: 'completed' | 'inprogress' | 'pending' | 'overdue';
}>({
  dataType() {
    return 'text';
  },
});

const maintenancePriorityEnum = customType<{
  data: 'low' | 'medium' | 'high';
}>({
  dataType() {
    return 'text';
  },
});

const userStatusEnum = customType<{
  data: 'active' | 'inactive';
}>({
  dataType() {
    return 'text';
  },
});

// Users and auth
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  roleId: integer("role_id").notNull(),
  status: userStatusEnum("status").notNull().default('active'),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const roles = pgTable("roles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  permissions: jsonb("permissions"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Inventory
export const inventoryItems = pgTable("inventory_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  sku: text("sku").unique(),
  serialNumber: text("serial_number"),
  inventoryNumber: text("inventory_number"),
  classification: text("classification"),
  category: text("category").notNull(),
  location: text("location"),
  status: itemStatusEnum("status").notNull().default('new'),
  quantity: integer("quantity").notNull().default(0),
  description: text("description"),
  icon: text("icon"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Departments
export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Teachers
export const teachers = pgTable("teachers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  departmentId: integer("department_id").notNull(),
  email: text("email"),
  phone: text("phone"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Material requests
export const materialRequests = pgTable("material_requests", {
  id: serial("id").primaryKey(),
  teacherId: integer("teacher_id").notNull(),
  departmentId: integer("department_id").notNull(),
  date: date("date").notNull(),
  status: requestStatusEnum("status").notNull().default('pending'),
  source: text("source"),
  reference: text("reference"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const requestItems = pgTable("request_items", {
  id: serial("id").primaryKey(),
  requestId: integer("request_id").notNull(),
  itemId: integer("item_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Distribution
export const distributions = pgTable("distributions", {
  id: serial("id").primaryKey(),
  teacherId: integer("teacher_id").notNull(),
  itemId: integer("item_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  date: date("date").notNull(),
  notes: text("notes"),
  receiptNumber: text("receipt_number"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Maintenance
export const maintenanceTasks = pgTable("maintenance_tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  itemId: integer("item_id").notNull(),
  date: date("date").notNull(),
  status: maintenanceStatusEnum("status").notNull().default('pending'),
  priority: maintenancePriorityEnum("priority").notNull().default('medium'),
  assignedTo: integer("assigned_to"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Budget and transactions
export const budget = pgTable("budget", {
  id: serial("id").primaryKey(),
  year: integer("year").notNull(),
  totalAmount: doublePrecision("total_amount").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  reference: text("reference"),
  type: transactionTypeEnum("type").notNull(),
  amount: doublePrecision("amount").notNull(),
  category: text("category").notNull(),
  date: date("date").notNull(),
  status: transactionStatusEnum("status").notNull().default('completed'),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Zod schemas for insert operations
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  lastLogin: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRoleSchema = createInsertSchema(roles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInventoryItemSchema = createInsertSchema(inventoryItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDepartmentSchema = createInsertSchema(departments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTeacherSchema = createInsertSchema(teachers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMaterialRequestSchema = createInsertSchema(materialRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRequestItemSchema = createInsertSchema(requestItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDistributionSchema = createInsertSchema(distributions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMaintenanceTaskSchema = createInsertSchema(maintenanceTasks).omit({
  id: true,
  completedAt: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBudgetSchema = createInsertSchema(budget).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Role = typeof roles.$inferSelect;
export type InsertRole = z.infer<typeof insertRoleSchema>;

export type InventoryItem = typeof inventoryItems.$inferSelect;
export type InsertInventoryItem = z.infer<typeof insertInventoryItemSchema>;

export type Department = typeof departments.$inferSelect;
export type InsertDepartment = z.infer<typeof insertDepartmentSchema>;

export type Teacher = typeof teachers.$inferSelect;
export type InsertTeacher = z.infer<typeof insertTeacherSchema>;

export type MaterialRequest = typeof materialRequests.$inferSelect;
export type InsertMaterialRequest = z.infer<typeof insertMaterialRequestSchema>;

export type RequestItem = typeof requestItems.$inferSelect;
export type InsertRequestItem = z.infer<typeof insertRequestItemSchema>;

export type Distribution = typeof distributions.$inferSelect;
export type InsertDistribution = z.infer<typeof insertDistributionSchema>;

export type MaintenanceTask = typeof maintenanceTasks.$inferSelect;
export type InsertMaintenanceTask = z.infer<typeof insertMaintenanceTaskSchema>;

export type Budget = typeof budget.$inferSelect;
export type InsertBudget = z.infer<typeof insertBudgetSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
